//
//  UIView+Property.h
//  JellyRole
//
//  Created by BoHuang on 3/24/17.
//  Copyright © 2017 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Property)

@property (nonatomic, strong) UIView* xo;
@end
