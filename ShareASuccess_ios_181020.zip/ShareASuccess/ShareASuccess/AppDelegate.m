//
//  AppDelegate.m
//  Fit
//
//  Created by Denis on 10/7/15.
//
//

#import "AppDelegate.h"
//#import "Utils.h"
#import "CGlobal.h"
#import "TblHealthData.h"
#import "NetworkParser.h"
#import "BaseModel.h"
#import "ResponseLogin.h"
#import "MHCustomTabBarController.h"
#import "IQKeyboardManager.h"
#import "UIView+Animation.h"

//#import <KSCrash/KSCrash.h> // TODO: Remove this
//#import <KSCrash/KSCrashInstallation+Alert.h>
//#import <KSCrash/KSCrashInstallationStandard.h>
//#import <KSCrash/KSCrashInstallationQuincyHockey.h>
//#import <KSCrash/KSCrashInstallationEmail.h>
//#import <KSCrash/KSCrashInstallationVictory.h>
#import "MyNavViewController.h"
#import "ChallengeDetailViewController.h"
#import <objc/runtime.h>

@interface AppDelegate ()

@property (nonatomic,strong) UIViewController* splashScreenViewController;
@property (nonatomic,assign) int step;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    _willShowChatWindow = false;
    NSDictionary *data = [launchOptions
                          objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if (data) {
        self.appIsStarting = YES;
        _launchData = data;
        _willShowChatWindow = true;
    }
    
    [self initService];
    [self initData];
    
    
    self.reachability = [Reachability
                         reachabilityForInternetConnection];
    
    [self.reachability startNotifier];
    
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(checkNetworkStatus:)
     name:kReachabilityChangedNotification
     object:nil];
    
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
//    [self installCrashHandler];
    self.healthStore = [[HKHealthStore alloc] init];
    
    
    [self showSplashScreen];
    
    [self performSelector:@selector(removeSplashScreen) withObject:nil afterDelay:1.4];
    [self.window makeKeyAndVisible];
    
//    application.applicationIconBadgeNumber = 0;
    
    // check launchOptions
    
    
    
    return YES;
}
/**
 Configure Crash Report Handler
 **/
//- (void) installCrashHandler
//{
//    KSCrashInstallation* installation = [self makeEmailInstallation];
//    [installation install];
//    [KSCrash sharedInstance].deleteBehaviorAfterSendAll = KSCDeleteNever; // TODO: Remove this
//
//
//    // Send all outstanding reports. You can do this any time; it doesn't need
//    // to happen right as the app launches. Advanced-Example shows how to defer
//    // displaying the main view controller until crash reporting completes.
//    [installation sendAllReportsWithCompletion:^(NSArray* reports, BOOL completed, NSError* error)
//     {
//         if(completed)
//         {
//             NSLog(@"Sent %d reports", (int)[reports count]);
//         }
//         else
//         {
//             NSLog(@"Failed to send reports: %@", error);
//         }
//     }];
//}
//- (KSCrashInstallation*) makeEmailInstallation
//{
//    NSString* emailAddress = @"huangbo1117@gmail.com";
//
//    KSCrashInstallationEmail* email = [KSCrashInstallationEmail sharedInstance];
//    email.recipients = @[emailAddress];
//    email.subject = @"Crash Report";
//    email.message = @"This is a crash report";
//    email.filenameFmt = @"crash-report-%d.txt.gz";
//
//    [email addConditionalAlertWithTitle:@"Crash Detected"
//                                message:@"The app crashed last time it was launched. Send a crash report?"
//                              yesAnswer:@"Sure!"
//                               noAnswer:@"No thanks"];
//
//    // Uncomment to send Apple style reports instead of JSON.
//    [email setReportStyle:KSCrashEmailReportStyleApple useDefaultFilenameFormat:YES];
//
//    return email;
//}
/**
 At the first Run the application, Show splash image to the Screen.
 **/
-(void) showSplashScreen
{
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    _splashScreenViewController = (UIViewController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"SplashScreenController"];
    
    UIImageView*imgview = [[UIImageView alloc] init];
    UIImage *image = [UIImage imageNamed:@"sss"];
    imgview.image = image;

    [self.window addSubview:self.splashScreenViewController.view];
}

-(void) removeSplashScreen
{
    [_splashScreenViewController.view removeFromSuperview];
    [self doInitialController];
}
-(void)doInitialController{
    if ([HKHealthStore isHealthDataAvailable]) {
        NSSet *shareObjectTypes;
        if (([[[UIDevice currentDevice] systemVersion] compare:@"10.0" options:NSNumericSearch] != NSOrderedAscending)) {
            // greater than equal
            shareObjectTypes = [NSSet setWithObjects:
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount],
                                [HKObjectType categoryTypeForIdentifier:HKCategoryTypeIdentifierAppleStandHour],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierActiveEnergyBurned],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceCycling],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceSwimming],
                                nil];
        }else if (([[[UIDevice currentDevice] systemVersion] compare:@"9.0" options:NSNumericSearch] != NSOrderedAscending)) {
            // greater than equal
            shareObjectTypes = [NSSet setWithObjects:
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount],
                                       [HKObjectType categoryTypeForIdentifier:HKCategoryTypeIdentifierAppleStandHour],
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierActiveEnergyBurned],
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass],
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning],
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceCycling],
                                       [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed],
                                       nil];
        }else{
            shareObjectTypes = [NSSet setWithObjects:
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierActiveEnergyBurned],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierBodyMass],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceCycling],
                                [HKObjectType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed],
                                nil];
        }
        [self.healthStore requestAuthorizationToShareTypes:nil
                                                 readTypes:shareObjectTypes
                                                completion:
         ^(BOOL success, NSError *error) {
             if (!success) {
                 //                 NSLog(@"Failed request HealthKit.");
             } else {
                 //                 NSLog(@"Success request HealthKit.");
             }
             EnvVar*env = [CGlobal sharedId].env;
             switch (-1) {
                 default:{
                     if (env.lastLogin > 0) {
                         [self gotoChallengeScreen];
                         
                     }else{
                         [self showLoginScreen];
                     }
                 }
             }
         }];
    }else{
        if (g_fakeDevice) {
            EnvVar*env = [CGlobal sharedId].env;
            switch (-1) {
                default:{
                    if (env.lastLogin > 0) {
                        [self gotoChallengeScreen];
                        
                    }else{
                        [self showLoginScreen];
                    }
                }
            }
            return;
        }
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"Sorry" message:@"Your device does not support healthstore data. Close the app by pressing home button." delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
        [alertview show];
    }
}

-(void)gotoChallengeScreen{
    dispatch_async(dispatch_get_main_queue(), ^{
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        MHCustomTabBarController*navigationController = (MHCustomTabBarController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"MHCustomTabBarController"];
        
        
        [UIView transitionFromView:self.window.rootViewController.view
                            toView:navigationController.view
                          duration:0.65f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        completion:^(BOOL finished){
                            self.window.rootViewController = navigationController;
                            
                            [self.window makeKeyAndVisible];
                        }];
    });
    
    
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
/**
 Configure Initial Data to be used in the app.
 **/
-(void)initService{
    
    UIUserNotificationType types = UIUserNotificationTypeBadge |
    
    UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
    
    UIUserNotificationSettings *mySettings =
    
    [UIUserNotificationSettings settingsForTypes:types categories:nil];
    
    [[UIApplication sharedApplication] registerUserNotificationSettings:mySettings];
    
    
    
    // Register for remote notifications.
    
    [[UIApplication sharedApplication] registerForRemoteNotifications];
}
-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString* newToken = [deviceToken description];
    newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    //    [GlobalVars sharedInstance].g_userInfo.token = [NSString stringWithFormat:@"%@", newToken];
    NSLog(@"My token is: %@", newToken);
    
    [CGlobal sharedId].uuid = newToken;
    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_RECEIVEUUID object:nil];
    
    G_DEVICETOKEN = newToken;
    [self registerDeviceUUID];
    
}
-(void)registerDeviceUUID{
    EnvVar*env = [CGlobal sharedId].env;
    if (env.lastLogin>0) {
        NSString* userid = [NSString stringWithFormat:@"%ld",env.lastLogin];
        if (userid!=nil && [userid length]>0 && G_DEVICETOKEN!=nil && [G_DEVICETOKEN length]>10)
        {
            
            NSMutableDictionary*data = [[NSMutableDictionary alloc] init];
            data[@"id"] = userid;
            data[@"ios_token"] = G_DEVICETOKEN;
            data[@"action"] = @"update";
            
            NetworkParser *manager = [NetworkParser sharedManager];
            
            NSString* path = [g_primaryUrl stringByAppendingString:ACTION_IOSPUSH];
            [manager generalNetwork:path Data:data withCompletionBlock:^(NSDictionary *dict, NSError *error) {
                if (error == nil) {
                    NSLog(@"Tokensaved :%@",[CGlobal sharedId].uuid);
                }else{
                    NSLog(@"Fail to SaveToken");
                }
            } method:@"post"];
            
        }
    }
    
}
-(void)unregisterUUID{
    EnvVar*env = [CGlobal sharedId].env;
    if (env.lastLogin>0) {
        NSString* userid = [NSString stringWithFormat:@"%ld",env.lastLogin];
        if (userid!=nil && [userid length]>0 && G_DEVICETOKEN!=nil && [G_DEVICETOKEN length]>10)
        {
            
            NSMutableDictionary*data = [[NSMutableDictionary alloc] init];
            data[@"id"] = userid;
            data[@"ios_token"] = @"1111";
            data[@"action"] = @"update";
            
            NetworkParser *manager = [NetworkParser sharedManager];
            
            NSString* path = [g_primaryUrl stringByAppendingString:ACTION_IOSPUSH];
            [manager generalNetwork:path Data:data withCompletionBlock:^(NSDictionary *dict, NSError *error) {
                if (error == nil) {
                    NSLog(@"Tokenremoved :%@",userid);
                }else{
                    NSLog(@"Fail to Remove Token");
                }
            } method:@"post"];
            
        }
    }
    
}
-(void) initData{
    // -38 is default for sort window
    // -38+12 = -26
    appDidBecomeActive_Status = 1;
    status_leading = 12;
    status_trailing = 12;
    default_textfield_radius = 4;
    statusbar_gap1 = 6;
    top_space = 19;
    bottom_space = 15.5;
    top_space_toolbar_title = 18;
    defaultFont = [UIFont fontWithName:@"abcAlenaAmagoo-Regular" size:15];
    defaultFont_Italic = [UIFont fontWithName:@"abcAlenaAmagoo-RegularItalic" size:15];
    defaultFont_Headline = [UIFont fontWithName:@"abcAlenaAmagoo-Regular" size:15];
    defaultFont_Headline_Bold = [UIFont fontWithName:@"abcAlenaAmagoo-Bold" size:15];
    
    abcAlena_bold = [UIFont fontWithName:@"abcAlenaAmagoo-Bold" size:15];
    abcAlena_lightitalic = [UIFont fontWithName:@"abcAlenaAmagoo-LightItalic" size:15];
    abcAlena_semibold = [UIFont fontWithName:@"abcAlenaAmagoo-Semibold" size:15];
    abcAlena_light = [UIFont fontWithName:@"abcAlenaAmagoo-Light" size:15];
    abcAlena_medium = [UIFont fontWithName:@"abcAlenaAmagoo-Medium" size:15];
    abcAlena_regular = [UIFont fontWithName:@"abcAlenaAmagoo-Regular" size:15];
    abcAlena_regularitalic = [UIFont fontWithName:@"abcAlenaAmagoo-RegularItalic" size:15];
    
    UIFont* font = [UIFont fontWithName:@"abcAlenaAmagoo-Bold" size:15]; // GoodTimesRg-Regular
    if (font!=nil) {
        NSLog(@"load font success");
    }
    
    defaultColor = [CGlobal colorWithHexString:@"aaaaaa" Alpha:1.0f];
    defaultColor1 = [CGlobal colorWithHexString:@"000000" Alpha:1.0f];
    defaultColor_blue = [CGlobal colorWithHexString:@"5C719C" Alpha:1.0f];
    
    APP_COLOR_DOT_RED_OLD = [CGlobal colorWithHexString:@"#811817" Alpha:1.0f];
    
    APP_COLOR_DOT_RED = [CGlobal colorWithHexString:@"#d8002c" Alpha:1.0f];
    APP_COLOR_DOT_GREEN = [CGlobal colorWithHexString:@"#29af00" Alpha:1.0f];
    
    APP_COLOR_RED = APP_COLOR_DOT_RED;
    APP_COLOR_GREEN = APP_COLOR_DOT_GREEN;
    APP_COLOR_BLUE =[CGlobal colorWithHexString:@"#5C6E9D" Alpha:1.0f];
//    APP_COLOR_YELLOW =[CGlobal colorWithHexString:@"#FECD00" Alpha:1.0f];
    APP_COLOR_YELLOW =[CGlobal colorWithHexString:@"#c89600" Alpha:1.0f];
    APP_COLOR_NOCOLOR =[CGlobal colorWithHexString:@"#656565" Alpha:1.0f];
    
    APP_COLOR_DETAIL1 =[CGlobal colorWithHexString:@"#95A5BF" Alpha:1.0f];
    APP_COLOR_DETAIL2 =[CGlobal colorWithHexString:@"#B9C3D3" Alpha:1.0f];
    APP_COLOR_DETAIL3 =[CGlobal colorWithHexString:@"#C8D2DD" Alpha:1.0f];
    
    APP_COLOR_COLOREDVIEW = APP_COLOR_DOT_RED;
    
    APP_COLOR_DETAIL_BACKGREEN =[CGlobal colorWithHexString:@"#ecf4ea" Alpha:1.0f];
    APP_COLOR_DETAIL_BACKRED =[CGlobal colorWithHexString:@"#eee1e1" Alpha:1.0f];
    APP_COLOR_DETAIL_BACKYELLOW =[CGlobal colorWithHexString:@"#f9f0e3" Alpha:1.0f];
    
    APP_COLOR_PRIMARY =[CGlobal colorWithHexString:@"#1B4B71" Alpha:1.0f];
    APP_COLOR_PRIMARY_SECONDARY =[CGlobal colorWithHexString:@"#0D1A2A" Alpha:1.0f];
    APP_COLOR_CELL_GRAY =[CGlobal colorWithHexString:@"#536070" Alpha:1.0f];
    APP_COLOR_BUTTON_PRIMARY =[CGlobal colorWithHexString:@"#0093A0" Alpha:1.0f];
  
    
    NSString*sourceName = @"myfit.sqlite";
    
    _dbManager = [[DBManager alloc] initWithDatabaseFilename:sourceName SourceName:sourceName];
    EnvVar* env = [CGlobal sharedId].env;
    switch (env.lastSyncStatus) {
        case GLOBAL_SYNC_INITIAL:{
            
            break;
        }
        case GLOBAL_SYNC_FIRSTTIME:{
            break;
        }
        default:{
            env.lastSyncStatus =GLOBAL_SYNC_INITIAL;
            break;
        }
    }
    
    
    g_listColor = [[NSArray alloc] initWithObjects:@"dot_red",@"dot_green",@"dot_blue",@"dot_yellow",@"dot_null", nil];
    UIColor*bk_red = [CGlobal colorWithHexString:@"eee1e1" Alpha:1.0];
    UIColor*bk_green = [CGlobal colorWithHexString:@"ecf4ea" Alpha:1.0];
    UIColor*bk_blue = [CGlobal colorWithHexString:@"eee1e1" Alpha:1.0];
    UIColor*bk_yellow = [CGlobal colorWithHexString:@"f9f0e3" Alpha:1.0];
    UIColor*bk_none = [CGlobal colorWithHexString:@"f8f9f8" Alpha:1.0];
    g_listColor_BK  = @[bk_red,bk_green,bk_blue,bk_yellow,bk_none];
    
    self.recoverMode = false;
    g_fakeDevice = false;
}
-(void)getUserInformationFromServer{
    NetworkStatus internetStatus = [self.reachability currentReachabilityStatus];
    if (internetStatus == NotReachable) {
        return;
    }
    EnvVar* env = [CGlobal sharedId].env;
    if (env.lastLogin<=0) {
        return;
    }
    NetworkParser* manager = [NetworkParser sharedManager];
    BaseModel* model = [BaseModel alloc];
    model.custId = env.custId;
    model.action = @"getmyinfo";
    NSString* winnerdate =[_dbManager getLastWinnerDate];
    model.lastwinnerdate =[CGlobal getDateStringAfterNDays:winnerdate isGmt:useGmt AfterTime:7*24*60*60];
    
    
    BOOL isFirst = false;
    if (env.lastSyncStatus == GLOBAL_SYNC_FIRSTTIME) {
        isFirst = true;
    }
    env.lastSyncStatus = GLOBAL_SYNC_GETTING_MYINFO;
    [manager ontemplateGeneralRequestWithRawUrl:model Path:@"https://share-a-success.com/tpw72betk/webservices.php" withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            ResponseMyInfo* info = [[ResponseMyInfo alloc] initWithDictionary:dict];
//            ResponseMyInfo* info = [[ResponseMyInfo alloc] initWithDictionary
            [self saveServerDataToLocalDb:info];
            
            if (isFirst) {
                g_indicator_mode = 1;
                env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
                [self importHealthFromServer];
            }else{
                env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
            }
        }else{
            env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
        }
        
    }];
}
-(void)importHealthFromServer{
    NetworkStatus internetStatus = [_reachability currentReachabilityStatus];
    if (internetStatus == NotReachable) {
        return;
    }
    
    EnvVar* env = [CGlobal sharedId].env;
    
    if (env.lastSyncStatus == GLOBAL_SYNC_INITIAL) {
        // START SYNC
        
        NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
        [dict setValue:env.custId forKey:@"custId"];
        [dict setValue:@"getallmyhealthdata" forKey:@"action"];
        [dict setValue:env.myUsers forKey:@"users"];
        
        env.lastSyncStatus = GLOBAL_SYNC_IMPORTING;
        
        NetworkParser* manager = [NetworkParser sharedManager];
        [manager generalNetwork:g_baseUrl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
            if (error == nil) {
                for (NSString* key in dict) {
                    NSString*prefix = @"user";
                    if (useEncode) {
                        prefix = @"u";
                    }
                    if ([key hasPrefix:prefix]) {
                        NSString*custId = [key substringFromIndex:prefix.length];
                        
                        NSDictionary*userx_data = dict[key];
                        for (NSString*date_key in userx_data) {
                            NSArray* array = userx_data[date_key];
                            
                            
                            TblHealthData* item = [[TblHealthData alloc] initWithArrayForBulk:array];
                            item.custId = custId;
                            item.date = date_key;
                            [_dbManager insertHealthData:item];
                        }
                        
                    }
                }
            }else{
                
            }
            sync_collect_start =nil;
            sync_collect_done =nil;
            sync_push_start =nil;
            sync_push_done =nil;
            sync_save_start =nil;
            sync_save_done =nil;
            env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
            [self collectHealthData];
        } method:@"GET"];
        
    }
}
-(void)showLoginScreen{
    EnvVar*env = [CGlobal sharedId].env;
    [env setLastLogin:0];
    //    g_searchTerm = nil;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        UINavigationController *navigationController = (UINavigationController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"CLoginNav"];
        
        self.window.rootViewController = navigationController;
        
        [self.window makeKeyAndVisible];
    });
}
-(void)pushLocalDbToServer{
    //return;
    
    NSLog(@"pushLocalDbToServer");
    // check network status
    NetworkStatus internetStatus = [self.reachability currentReachabilityStatus];
    if (internetStatus == NotReachable) {
        return;
    }
    EnvVar*env = [CGlobal sharedId].env;
    if (env.lastSyncStatus == GLOBAL_SYNC_COLLECTING_DONE || env.lastSyncStatus == GLOBAL_SYNC_INITIAL) {
        EnvVar* env = [CGlobal sharedId].env;
        NSString*lastSyncDay = env.lastMySyncDay;
        NSDate *pushTime =[CGlobal getDateFromDbString:lastSyncDay isGmt:useGmt];
        NSDate *date =[CGlobal getDateFromDbString:lastSyncDay isGmt:useGmt];
        if (pushTime == nil) {
            pushTime = [NSDate date];
            
            if(self.recoverMode){
                date = [NSDate date];
                date = [date dateByAddingTimeInterval:-60*60*24*40];
            }else{
                if(date == nil){
                    date = [NSDate date];
                }
                date = [CGlobal getFirstDay:date isGmt:useGmt];
            }
        }else{
            pushTime = [NSDate date];
            
            // 2016-10-20 NEED TO CONSIDER THIS WEEKS DATA.
//            date = [NSDate date];
            // 2016-10-20  sync only the current weeks data....
            
            date = [CGlobal getFirstDay:date isGmt:useGmt];
            
        }
        
        sync_push_start = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
        env.lastSyncStatus = GLOBAL_SYNC_PUSHING;
        
//        [self pushDataForDay:date AtTime:pushTime];
        
        NSDate*lastDay = date;
        NSString*lastSavedDay = [_dbManager getLastSavedDate];
        
        NSDate *today = [CGlobal getDateFromDbString:lastSavedDay isGmt:useGmt];
        
        NSString*env_lastMySyncDay = @"";
        NSMutableArray* dates_array = [[NSMutableArray alloc] init];
        while (true) {
            if (today == nil) {                
                [self getUserInformationFromServer];
                g_indicator_mode = 0;
                return;
            }
            
            NSTimeInterval interval = [lastDay timeIntervalSinceDate:today];
            
            if (interval >= 24*60*60) {     // [lastDay compare:today] == NSOrderedDescending
                NSTimeInterval subinterval = [lastDay timeIntervalSinceDate:pushTime];
                if (subinterval>0) {
                    env_lastMySyncDay = [CGlobal getTimeStringFromDate:pushTime isGmt:useGmt];
                }else{
                    env_lastMySyncDay = [CGlobal getTimeStringFromDate:lastDay isGmt:useGmt];
                }
                break;
            }else{
                [dates_array addObject:lastDay];
                lastDay = [lastDay dateByAddingTimeInterval:60*60*24];
                continue;
            }
        }
        
        if (dates_array.count == 0 || [env_lastMySyncDay length] == 0) {
            [env setLastSyncStatus:GLOBAL_SYNC_INITIAL];
            return;
        }else{
            NSString* req_dates = @"";
            NSString* req_healthdata = @"";
            for (int i=0; i< [dates_array count]; i++) {
                NSDate*idate = dates_array[i];
                TblHealthData* data =  [_dbManager getHealthData:idate CustId:env.custId];
                if (data == nil) {
                    continue;
                }
                NSString*term_dates = [NSString stringWithFormat:@"%@,",[CGlobal getDayPart1FromNSDate:idate isGmt:useGmt]];
                NSString*term_healthdata = [NSString stringWithFormat:@"%@,",[data getHealthDataRequestString]];
                
                req_dates = [req_dates stringByAppendingString:term_dates];
                req_healthdata = [req_healthdata stringByAppendingString:term_healthdata];
            }
            
            if ([req_dates length] == 0) {
                [env setLastSyncStatus:GLOBAL_SYNC_INITIAL];
                g_indicator_mode = 0;
                return;
            }
            req_dates       = [req_dates substringToIndex:[req_dates length]-1];
            req_healthdata  = [req_healthdata substringToIndex:[req_healthdata length]-1];
            
            NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
            [dict setValue:req_dates forKey:@"date"];
            [dict setValue:req_healthdata forKey:@"healthdata"];
            [dict setValue:env.myUsers forKey:@"users"];
            [dict setValue:@"savechallengebulk" forKey:@"action"];
            [dict setValue:env.custId forKey:@"custId"];
            
            NSString* winnerdate =[_dbManager getLastWinnerDate];
            NSString* temp1  =[CGlobal getDateStringAfterNDays:winnerdate isGmt:useGmt AfterTime:7*24*60*60];
            if (temp1!=nil) {
                [dict setValue:temp1 forKey:@"lastwinnerdate"];
            }
            
            
            NetworkParser* manager = [NetworkParser sharedManager];
            NSString*serverurl = @"https://share-a-success.com/tpw72betk/webservices.php";
//            NSLog(@"%@",dict);
            BOOL isFirst = false;
            if (env.lastSyncStatus == GLOBAL_SYNC_FIRSTTIME) {
                isFirst = true;
            }
            [manager generalNetwork:serverurl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
                if (error == nil) {
                    sync_push_done = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
                    env.lastMySyncDay = env_lastMySyncDay;
                    
                    sync_save_start = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
                    for (NSString* key in dict) {
                        NSString*prefix = @"user";
                        if (useEncode) {
                            prefix = @"u";
                        }
                        if ([key hasPrefix:prefix]) {
                            NSString*custId = [key substringFromIndex:prefix.length];
                            if ([custId isEqualToString:env.custId]) {
                                continue;
                            }
                            NSDictionary*userx_data = dict[key];
                            for (NSString*date_key in userx_data) {
                                NSArray* array = userx_data[date_key];
                                
                                
                                TblHealthData* item = [[TblHealthData alloc] initWithArrayForBulk:array];
                                item.custId = custId;
                                item.date = date_key;
                                [_dbManager insertHealthData:item];
                            }
                            
                        }
                    }
                    id obj = dict[@"getmyinfo"];
                    if (obj!=nil && obj!=[NSNull null]) {
                        ResponseMyInfo* info = [[ResponseMyInfo alloc] initWithDictionary:obj];
                        [self saveServerDataToLocalDb:info];
                        
                        if (isFirst) {
                            env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
                            [self collectHealthData];
                        }else{
                            env.lastSyncStatus = GLOBAL_SYNC_INITIAL;
                        }
                        sync_save_done = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
                        
                    }else{
                        [env setLastSyncStatus:GLOBAL_SYNC_INITIAL];
                        
                    }
                }else{
                    [env setLastSyncStatus:GLOBAL_SYNC_INITIAL];
                    
                }
                [self checkBackFetchPerform];
                g_indicator_mode = 0;
//                NSLog(@"PUSH DONE");
            } method:@"GET"];
        }
    }
}
-(void)checkBackFetchPerform{
    CGlobal* global = [CGlobal sharedId];
    EnvVar* env = global.env;
    if (env.backGroundStatus == GLOBAL_BACK_DOING) {
        if (global.fetchCallBack!=nil) {
            global.fetchCallBack(UIBackgroundFetchResultNewData);
            global.fetchCallBack = nil;
            NSLog(@"Fetch completed");
        }
        env.backGroundStatus = GLOBAL_BACK_INITIAL;
    }
    
}
-(void)collectHealthData{
//    return;
    
    NSLog(@"collectHealthData");
    EnvVar*env = [CGlobal sharedId].env;
    if (env.lastLogin<=0) {
        return;
    }
    if (env.lastSyncStatus == GLOBAL_SYNC_INITIAL || env.lastSyncStatus == GLOBAL_SYNC_PUSHING_DONE){
        NSString*lastSavedDay = [_dbManager getLastSavedDate];
        NSDate *date = [CGlobal getDateFromDbString:lastSavedDay isGmt:useGmt];
        if (date == nil) {
            date = [NSDate date];
            // for recover
            if(self.recoverMode){
                date = [date dateByAddingTimeInterval:-60*60*24*40];
            }
            date = [CGlobal getFirstDay:date isGmt:useGmt];
            
        }else{
            
            NSLog(@"LastDate Saved = %@",date);
            date = [CGlobal getLastTimeOfDay:date isGmt:useGmt];
            
            NSDate*nowtime = [NSDate date];
            NSTimeInterval interval = [nowtime timeIntervalSinceDate:date];
            
            date = [date dateByAddingTimeInterval:-60*60*24*1];
            NSLog(@"Date Initial = %@",date);

            if (interval>0 && interval <= 20) {
                date = [date dateByAddingTimeInterval:-60*60*24*1];
            }
        }
        sync_collect_start = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
        [env setLastSyncStatus:GLOBAL_SYNC_COLLECTING];
        
        NSDate*collectTime = [NSDate date];
        
        _step = 0;
        [self checkAndCollectPrevData:date CollectTime:collectTime];
        
    }
    
}
-(void)checkAndCollectPrevData:(NSDate*)lastDay CollectTime:(NSDate*)today{
    
    _step = _step+1;
    
    if(_step == 1){
        
        NSString*prompt1 = [NSString stringWithFormat:@"%@ ",lastDay];
        NSString*prompt2 = [NSString stringWithFormat:@"%@ ",today];
        
        NSString* str = [NSString stringWithFormat:@"%@  %@",prompt1,prompt2];
    }

    
    
    EnvVar*env = [CGlobal sharedId].env;
    
    NSTimeInterval interval = [lastDay timeIntervalSinceDate:today];
    
    if (g_fakeDevice){
        sync_collect_done = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
        
        env.lastSyncStatus = GLOBAL_SYNC_COLLECTING_DONE;
        
        // added 2016 09 08
        [self pushLocalDbToServer];
        return;
    }
    if (interval >= 24*60*60 ) {//[lastDay compare:today] == NSOrderedDescending
        
        sync_collect_done = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
        
        env.lastSyncStatus = GLOBAL_SYNC_COLLECTING_DONE;
        
        // added 2016 09 08
        [self pushLocalDbToServer];
        return;
    }else{
        [self getHealthDataForADay:lastDay CollectTime:today andUpdateUserdefault:true withCallback:^(BOOL success) {
            if (success) {
                NSDate* nextDay = [lastDay dateByAddingTimeInterval:60*60*24];
                [self checkAndCollectPrevData:nextDay CollectTime:today];
            }else{
                [CGlobal AlertMessage:@"Error While Collecting Data" Title:[Utils getJsonStringFromDate:lastDay]];
                
                sync_collect_done = [CGlobal getTimePartStringFromDate:[NSDate date] isGmt:useGmt];
                env.lastSyncStatus = GLOBAL_SYNC_COLLECTING_DONE;
                return;
            }
        }];
    }
}

-(void)getHealthDataForADay:(NSDate*)date CollectTime:(NSDate*)collectTime andUpdateUserdefault:(BOOL)saveLastSyncDate withCallback:(void (^)(BOOL success))callback{
    [self getMyHealthData :date completionHandler:^(SummaryInfo *info) {
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self saveHealthData:info :date CollectTime:collectTime andUpdateUserdefault:saveLastSyncDate withCallback:^(BOOL success) {
                if (callback) {
                    callback(success);
                }
            }];
        });
    }];
}

-(void)saveHealthData:(id)info :(NSDate*)date CollectTime:(NSDate*)collectTime andUpdateUserdefault:(BOOL)saveLastSyncDate withCallback:(void (^)(BOOL success))callback{
    
    SummaryInfo *summary = info;
    
    EnvVar* env = [CGlobal sharedId].env;
    TblHealthData* data = [[TblHealthData alloc] init];
    data.custId = [NSString stringWithFormat:@"%ld", env.lastLogin];
    data.date = [CGlobal getTimeStringFromDate:date isGmt:useGmt];
    
    data.steps = summary.steps;
    data.sleep = summary.sleep;
    data.active_cal = summary.activeCal;
    data.weight = summary.weight;
    data.calorieGoal = summary.calorieGoal;
    data.exercise = summary.exercise;
    data.standing = summary.standing;
    data.walking = summary.walking;
    data.cycling = summary.cycling;
    data.flights = summary.flights;
    data.swim = summary.swimming;
    
    
    [_dbManager insertHealthData:data];
    
    if (callback) {
        callback(true);
    }
    
}


- (void)getMyHealthData : (NSDate *)date
       completionHandler:(void (^)(SummaryInfo *info))completionHandler{
    SummaryInfo *summary = [[SummaryInfo alloc] init];
    summary.name = [[NSBundle mainBundle] localizedStringForKey:@"Myself" value:@"" table:nil];
    summary.date = [NSDate date];
    
    summary.calorieGoal = @"0";
    
    [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierStepCount] date:date completionHandler:^(HKStatistics *result, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                summary.steps = @"0";
            } else {
                HKQuantity *resultQuantity = result.sumQuantity; //result.averageQuantity;
                if (resultQuantity) {
                    HKUnit *unit = [HKUnit countUnit];
                    double value = [resultQuantity doubleValueForUnit:unit];
                    summary.steps = [NSString stringWithFormat:@"%i", (int)value];
                }else{
                    summary.steps = @"0";
                }
            }
            NSLog(@"sssttt %@ %@",date,summary.steps);
            
            [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierActiveEnergyBurned] date:date completionHandler:^(HKStatistics *result, NSError *error) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (error) {
                        summary.activeCal = @"0";
                    } else {
                        HKQuantity *resultQuantity = result.sumQuantity; //result.averageQuantity;
                        if (resultQuantity) {
                            HKUnit *unit = [HKUnit kilocalorieUnit];
                            double value = [resultQuantity doubleValueForUnit:unit];
                            summary.activeCal = [NSString stringWithFormat:@"%i", (int)value];
                        }else{
                            summary.activeCal = @"0";
                        }
                    }
                    
                    [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceWalkingRunning] date:date completionHandler:^(HKStatistics *result, NSError *error) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (error) {
                                summary.walking = @"0";
                            } else {
                                HKQuantity *resultQuantity = result.sumQuantity;
                                if (resultQuantity) {
                                    HKUnit *unit = [HKUnit meterUnit];
                                    double value = [resultQuantity doubleValueForUnit:unit];
                                    summary.walking = [NSString stringWithFormat:@"%.2f", value / 1000.0f];
                                }else{
                                    summary.walking = @"0";
                                }
                                
                            }
                            
                            [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceCycling] date:date completionHandler:^(HKStatistics *result, NSError *error) {
                                dispatch_async(dispatch_get_main_queue(), ^{
                                    if (error) {
                                        summary.cycling = @"0";
                                    } else {
                                        HKQuantity *resultQuantity = result.sumQuantity;
                                        if(resultQuantity){
                                            HKUnit *unit = [HKUnit meterUnit];
                                            double value = [resultQuantity doubleValueForUnit:unit];
                                            summary.cycling = [NSString stringWithFormat:@"%.2f", value / 1000.0f];
                                        }else{
                                            summary.cycling = @"0";
                                        }
                                        
                                    }
                                    
                                    [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierFlightsClimbed] date:date completionHandler:^(HKStatistics *result, NSError *error) {
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            if (error) {
                                                summary.flights = @"0";
                                            } else {
                                                HKQuantity *resultQuantity = result.sumQuantity;
                                                if (resultQuantity) {
                                                    HKUnit *unit = [HKUnit countUnit];
                                                    double value = [resultQuantity doubleValueForUnit:unit];
                                                    summary.flights = [NSString stringWithFormat:@"%i", (int)value];
                                                }else{
                                                    summary.flights = @"0";
                                                }
                                                
                                            }
                                            
                                            if (([[[UIDevice currentDevice] systemVersion] compare:@"9.0" options:NSNumericSearch] != NSOrderedAscending)) {
                                                [self fetchCategory:[HKCategoryType categoryTypeForIdentifier:HKCategoryTypeIdentifierAppleStandHour] date:date completionHandler:^(NSArray *result, NSError *error) {
                                                    dispatch_async(dispatch_get_main_queue(), ^{
                                                        if (error) {
                                                            summary.standing = @"0";
                                                        } else {
                                                            double minutesSleepAggr = 0;
                                                            for (HKCategorySample *sample in result) {
                                                                if (sample.value ==0) {
                                                                    NSTimeInterval distanceBetweenDates = [sample.endDate timeIntervalSinceDate:sample.startDate];
                                                                    double minutesInAnHour = 60;
                                                                    double minutesBetweenDates = distanceBetweenDates / minutesInAnHour;
                                                                    minutesSleepAggr += minutesBetweenDates;
                                                                }
                                                                
                                                            }
                                                            
                                                            summary.standing = [NSString stringWithFormat:@"%.1f", minutesSleepAggr / 60.0f];
                                                        }
                                                        
                                                        // 10.0 swimming distance
                                                        if (([[[UIDevice currentDevice] systemVersion] compare:@"10.0" options:NSNumericSearch] != NSOrderedAscending)) {
                                                            [self fetchQuantity:[HKQuantityType quantityTypeForIdentifier:HKQuantityTypeIdentifierDistanceSwimming] date:date completionHandler:^(HKStatistics *result, NSError *error) {
                                                                dispatch_async(dispatch_get_main_queue(), ^{
                                                                    if (error) {
                                                                        summary.swimming = @"0";
                                                                    } else {
                                                                        HKQuantity *resultQuantity = result.sumQuantity; //result.averageQuantity;
                                                                        if (resultQuantity) {
                                                                            HKUnit *unit = [HKUnit meterUnit];
                                                                            double value = [resultQuantity doubleValueForUnit:unit];
                                                                            summary.swimming = [NSString stringWithFormat:@"%.1f", value/1000.0f];
                                                                        }else{
                                                                            summary.swimming = @"0";
                                                                        }
                                                                        
                                                                    }
                                                                    completionHandler(summary);
                                                                });
                                                            }];
                                                             
                                                            
                                                        }else{
                                                            summary.swimming = @"0";
                                                            completionHandler(summary);
                                                        }
                                                        
                                                        
                                                        
                                                    });
                                                }];
                                            }else{
                                                summary.standing = @"0";
                                                completionHandler(summary);
                                            }
                                            
                                            
                                        });
                                    }];
                                });
                            }];
                        });
                    }];

                });
            }];
        });
    }];
}

- (void)fetchCategory:(HKCategoryType *)type date:(NSDate *)date
    completionHandler:(void (^)(NSArray *result, NSError *error))completionHandler
{
    
    NSDate *startDate = [CGlobal getFirstTimeOfDay:date isGmt:useGmt]; //[CGlobal getFirstDay1:date];
    NSDate *endDate = date;
    
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate
                                                               endDate:endDate
                                                               options:HKQueryOptionStrictStartDate];
    
    HKSampleType *sampleType = [HKSampleType categoryTypeForIdentifier:HKCategoryTypeIdentifierAppleStandHour];
    
    HKSampleQuery *query = [[HKSampleQuery alloc] initWithSampleType:sampleType predicate:predicate limit:0 sortDescriptors:nil resultsHandler:^(HKSampleQuery *query, NSArray *results, NSError *error) {
        if (error) {
            completionHandler(nil, error);
        } else {
            completionHandler(results, error);
        }
    }];
    
    [self.healthStore executeQuery:query];
    
}
- (void)fetchQuantity:(HKQuantityType *)type date:(NSDate *)date
    completionHandler:(void (^)(HKStatistics *result, NSError *error))completionHandler
{
    
    NSDate *startDate = [CGlobal getFirstTimeOfDay:date isGmt:useGmt];
    NSDate *endDate   = date;
    
    
    NSPredicate *predicate = [HKQuery predicateForSamplesWithStartDate:startDate
                                                               endDate:endDate
                                                               options:HKQueryOptionStrictStartDate];
    
    HKStatisticsOptions options = type.aggregationStyle == HKQuantityAggregationStyleCumulative ? HKStatisticsOptionCumulativeSum : HKStatisticsOptionDiscreteAverage;
    HKStatisticsQuery *query = [[HKStatisticsQuery alloc] initWithQuantityType:type
                                                       quantitySamplePredicate:predicate
                                                                       options:options
                                                             completionHandler:
                                ^(HKStatisticsQuery *query, HKStatistics *result, NSError *error) {
                                    if (completionHandler) {
                                        
                                        if (error) {
                                            completionHandler(nil, error);
                                        }
                                        else {
                                            /*HKQuantity *quantity = result.sumQuantity;
                                            if (quantity) {
                                                NSDate *date = result.startDate;
                                                double value = [quantity doubleValueForUnit:[HKUnit countUnit]];
                                                NSLog(@"%@: %f", date, value);
                                            }*/
                                            completionHandler(result, error);
                                        }
                                    }
                                }];
    
    [self.healthStore executeQuery:query];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    self.appIsStarting = NO;
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    self.appIsStarting = NO;
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    self.appIsStarting = YES;
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    self.appIsStarting = NO;
    
    EnvVar* env = [CGlobal sharedId].env;
    
    if (env.lastLogin > 0) {
        int tipstep = (int)env.tip_step;
        
        NSLog(@"applicationDidBecomeActive tipstep = %d",tipstep);
        switch (tipstep) {
            case 1:
            {
                [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_NOTICE object:@{@"notice":@"2"}];
                //            [CGlobal AlertMessage:@"didbecome active first" Title:nil];
                break;
            }
            case 2:{
                [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_NOTICE object:@{@"notice":@"3"}];
                break;
            }
            default:{
                                
                break;
            }
                
        }
        
    }
    
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}


-(void) checkNetworkStatus:(NSNotification *)notice
{
    
    NetworkStatus internetStatus = [self.reachability currentReachabilityStatus];
    
    switch (internetStatus)
    {
        case NotReachable:
        {
            NSLog(@"The internet is down.");
            
            break;
        }
        case ReachableViaWiFi:
        {
            NSLog(@"The internet is working via WIFI.");
            
            
            break;
        }
        case ReachableViaWWAN:
        {
            NSLog(@"The internet is working via WWAN.");
            
            
            break;
        }
    }
}
-(void)onLogin:(NSDictionary*)dict{
    ResponseLogin* resp = [[ResponseLogin alloc] initWithDictionary:dict];
    if (resp.result) {
        EnvVar* env = [CGlobal sharedId].env;
        int custId = [resp.custId intValue];
        [env setLastLogin:custId];
        env.fname = resp.custName;
        env.lname = resp.custLname;
        env.password = resp.password;
        env.public_share =resp.public_share;
        env.screen =resp.screen;
        env.email = resp.emailAddress;
        env.push_enabled = resp.push_enabled;
        
        [env saveDefaults:@"fname" value:env.fname];
        [env saveDefaults:@"lname" value:env.lname];
        [env saveDefaults:@"password" value:env.password];
        [env saveDefaults:@"public_share" value:env.public_share];
        [env saveDefaults:@"screen" value:env.screen];
        
        [self gotoChallengeScreen];
    }
}

-(void)logOut{
    
    [self unregisterUUID];
    
    EnvVar* env = [CGlobal sharedId].env;
    [env logOut];
    
    [_dbManager logout];
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle: nil];
    
    UINavigationController *navigationController = (UINavigationController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"CLoginNav"];
    
    
    self.window.rootViewController = navigationController;
    
}
-(void)saveServerDataToLocalDb:(ResponseMyInfo*)info{
    [_dbManager replaceChallenges:info.allchallenges];
    EnvVar* env = [CGlobal sharedId].env;
    
    env.my_invitee_pending = info.inviteinfo.my_invitee_pending;
    env.friends_invitee_pending = info.inviteinfo.friends_invitee_pending;
    env.total_invitee_pending = info.inviteinfo.total_invitee_pending;
    [_dbManager replaceInviteeInfo:info.inviteinfo.inviteinfo_data];
    [_dbManager replaceSortInfo:info.sortinfo];
    
    [_dbManager replaceWinnerInfo:info.winnerinfo];
    
}
/**
 When User Refresh Challenge Scree, Start to sync the system.
 **/
-(void)trySyncStart{
    EnvVar* env = [CGlobal sharedId].env;
    int status = (int)env.lastSyncStatus;
    
    if (_willShowChatWindow) {
        return;
    }
    switch (status) {
        case GLOBAL_SYNC_FIRSTTIME:{
            if (env.lastSyncStatus == GLOBAL_SYNC_INITIAL) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self collectHealthData];
                });
            }
            break;
        }
        case GLOBAL_SYNC_INITIAL:{
            EnvVar* env = [CGlobal sharedId].env;
            if (env.lastSyncStatus == GLOBAL_SYNC_INITIAL) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self collectHealthData];
                });
            }
            break;
        }
        case GLOBAL_SYNC_COLLECTING:{
            //            NSLog(@"GLOBAL_SYNC_COLLECTING");
            break;
        }
        case GLOBAL_SYNC_COLLECTING_DONE:{
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                EnvVar* env = [CGlobal sharedId].env;
                if (env.lastSyncStatus == GLOBAL_SYNC_COLLECTING_DONE) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self pushLocalDbToServer];
                    });
                }
            });
            
            break;
        }
        case GLOBAL_SYNC_PUSHING:{
            //            NSLog(@"GLOBAL_SYNC_PUSHING");
            break;
        }
        case GLOBAL_SYNC_PUSHING_DONE:{
            //            NSLog(@"GLOBAL_SYNC_PUSHING_DONE");
            dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC);
            dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                EnvVar* env = [CGlobal sharedId].env;
                if (env.lastSyncStatus == GLOBAL_SYNC_PUSHING_DONE) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [self getUserInformationFromServer];
                    });
                }
            });
            break;
        }
        case GLOBAL_SYNC_GETTING_MYINFO:{
            break;
        }
        default:{
            //            NSLog(@"GLOBAL_SYNC default  = %d",status);
            break;
        }
    }
}

#pragma -mark AlertDialog
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    int tag = (int)alertView.tag;
    switch (tag) {
        case 100:
        {
            // show dialog
            [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_NOTICE object:@{@"notice":@"1"}];
            break;
        }
        default:
            break;
    }
}
-(void)setBadgeNumber{
    
    NSString*date_str = [CGlobal getDayPart1FromNSDate:[NSDate date] isGmt:useGmt];
    NSMutableArray*list = [self.dbManager getChallenges:date_str];
    int count = 0;
    for (int i=0; i<list.count; i++) {
        TblChallenge* model = list[i];
        if ([model hasMessages]) {
            count += [model.msg_count intValue];
        }
    }
    
    UIApplication.sharedApplication.applicationIconBadgeNumber = count;
    NSLog(@"setBadgeNumber %d",count);
}
-(void)goChatView:(TblChat*)chat_model{
    EnvVar* env = [CGlobal sharedId].env;
    if (env.lastLogin<=0) {
        // when log out
        return;
    }
    NSString*date_str = [CGlobal getDayPart1FromNSDate:[NSDate date] isGmt:useGmt];
    NSMutableArray*list = [self.dbManager getChallenges:date_str];
    TblChallenge* challenge = nil;
    for (int i=0; i<list.count; i++) {
        TblChallenge* model = list[i];
        if ([model.challenge_id intValue] == [chat_model.ch_id intValue]) {
            // when equal save it
            challenge = model;
            break;
        }
    }
    if (challenge) {
        if (UIApplication.sharedApplication.keyWindow.rootViewController) {
            UIViewController* parentViewController = UIApplication.sharedApplication.keyWindow.rootViewController;
            while (parentViewController.presentedViewController != nil){
                parentViewController = parentViewController.presentedViewController;
            }
            
            UIViewController* curViewController = parentViewController;
            if ([curViewController isKindOfClass:[MyNavViewController class]]) {
//                UINavigationController* tmp_vc = curViewController;
//
//                UIStoryboard* ms = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
//
//                ChallengeDetailViewController *detail = [ms instantiateViewControllerWithIdentifier:@"ChallengeDetailViewController"];
//
//                detail.challengeInfo = challenge;
//                [tmp_vc pushViewController:detail animated:NO];
                [CGlobal AlertMessage:@"case2" Title:nil];
            }else if([curViewController isKindOfClass:[MHCustomTabBarController class]]){
                MHCustomTabBarController* m_vc = curViewController;
                if([m_vc.destinationViewController isKindOfClass:[MyNavViewController class]]){
                    UINavigationController* tmp_vc = m_vc.destinationViewController;
                    
                    UIStoryboard* ms = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    
                    ChallengeDetailViewController *detail = [ms instantiateViewControllerWithIdentifier:@"ChallengeDetailViewController"];
                    
                    detail.challengeInfo = challenge;
                    
                    if (tmp_vc.viewControllers.count>0) {
                        UIViewController*home = tmp_vc.viewControllers[0];
                        [tmp_vc setViewControllers:@[home,detail] animated:NO];
                    }else{
                        [CGlobal AlertMessage:@"case1" Title:nil];
                    }
                    
                }
            }else{
                if (curViewController == nil) {
                    [CGlobal AlertMessage:@"case3" Title:nil];
                }else{
                    
//                    id p = curViewController;
//                    NSString* class = NSStringFromClass([p class]);
//                    const char* className = class_getName([p class]);
//
//                    [CGlobal AlertMessage: [NSString stringWithFormat:@"case4 %@ %s",class,className] Title:nil];
                }
                
            }
            
        }
    }else{
        NSLog(@"No Challenge %@ in user database",chat_model.ch_id);
    }
    
}
-(void)processNotification:(NSDictionary*)userInfo Status:(NSString*)string{
    if (userInfo[@"aps"][@"type"]==nil) {
        return;
    }else{
        // {"aps":{"alert":"hello this is test chat messsage4","sound":"default","type":"4","r":{"i":"3","u":"2","n":"huangbo","t":"1533008762","c":"323"}}}
        int type = [userInfo[@"aps"][@"type"] intValue];
        if (type == 4) {
//            long origin = UIApplication.sharedApplication.applicationIconBadgeNumber;
//            UIApplication.sharedApplication.applicationIconBadgeNumber = origin + 1;
            
            id dict = userInfo[@"aps"][@"r"];
            TblChat *model = [[TblChat alloc] initWithDictionaryABC:dict Encode:false];
            if(self.dbManager == nil){
                NSString*sourceName = @"myfit.sqlite";
                _dbManager = [[DBManager alloc] initWithDatabaseFilename:sourceName SourceName:sourceName];
            }
            model.msg = userInfo[@"aps"][@"alert"];
            [model makeNotSeen];
            [_dbManager insertOrUpdateChatData:model];
            
            
            [self setBadgeNumber];
            
            if (string!=nil) {
                if ([string isEqualToString:@"tap_noti"]) {
                    // in case tap notification
                    _willShowChatWindow = true;
                    [self goChatView:model];
                    
                }else if ([string isEqualToString:@"app_active"]) {
                    // in case tap notification
                    //[self goChatView:model];
                    [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_RECEIVEMSG object:@{@"chat_model":model}];
                    
                }
            }
            
                        
        }
        
        return;
    }
}
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    NSLog(@"didReceiveRemoteNotification");
}
//-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler{
//    
//}
-(void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler{
    
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateBackground ||
        (state == UIApplicationStateInactive &&
         !self.appIsStarting)) {
            NSDictionary *aps = userInfo[@"aps"];
            if (aps) {
                // perform the background fetch and
                // call completion handler
                [self processNotification:userInfo Status:nil];
            }
        }
    else if (state == UIApplicationStateInactive &&
             self.appIsStarting) {
        // user tapped notification
        [self processNotification:userInfo Status:@"tap_noti"];
    }
    else {
        // app is active
        [self processNotification:userInfo Status:@"app_active"];
    }
    completionHandler(UIBackgroundFetchResultNoData);
    
    return;
    
    
    int type = [userInfo[@"aps"][@"type"] intValue];
    
    
    NSDate * date = [NSDate date];
    NSLog(@"Input Date = %@",date);
    date = [CGlobal getLastTimeOfDay:date isGmt:useGmt];
    
    if (type == 1) {
        date = [date dateByAddingTimeInterval:-60*60*24*1];
        NSLog(@"parameter to getMyHealthData = %@",date);
    }
    
    NSDate*nowtime = [NSDate date];
    NSTimeInterval interval = [nowtime timeIntervalSinceDate:date];
    
    
    
    if (interval>0 && interval <= 20) {
        date = [date dateByAddingTimeInterval:-60*60*24*1];
    }
    
    [self getMyHealthData :date completionHandler:^(SummaryInfo *info) {
        
        EnvVar*env = [CGlobal sharedId].env;
        
        NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
        [dict setValue:[CGlobal getDayPart1FromNSDate:date isGmt:useGmt] forKey:@"date"];
        [dict setValue:[info getHealthDataRequestString] forKey:@"healthdata"];
        [dict setValue:@"" forKey:@"users"];
        [dict setValue:@"savechallengebulk" forKey:@"action"];
        [dict setValue:env.custId forKey:@"custId"];
        
        //NSString* winnerdate = [CGlobal getTimeStringFromDate:date isGmt:useGmt];
        NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"yyyy-MM-dd"];
        if (useGmt) {
            NSTimeZone *timezone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
            [formatter setTimeZone:timezone];
        }else{
            NSTimeZone *timezone = [NSTimeZone localTimeZone];
            [formatter setTimeZone:timezone];
        }
        [dict setValue:[formatter stringFromDate:date] forKey:@"lastwinnerdate"];
        
        
        NetworkParser* manager = [NetworkParser sharedManager];
        NSString*serverurl = g_baseUrl;
        NSLog(@"%@",dict);
        [manager generalNetwork:serverurl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
            if (error == nil) {
                
            }
            NSLog(@"logged healthdata");
            completionHandler(UIBackgroundFetchResultNewData);
        } method:@"GET"];
    }];
}
@end
