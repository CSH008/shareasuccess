//
//  ResponseInviteInfo.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "ResponseInviteInfo.h"
#import "BaseModel.h"
#import "TblInviteInfoData.h"

@implementation ResponseInviteInfo
-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
        id obj = [dict objectForKey:@"inviteinfo_data"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            self.inviteinfo_data = [[NSMutableArray alloc] init];
            for (int i=0; i< [array count]; i++) {
                TblInviteInfoData *ach = [[TblInviteInfoData alloc] initWithDictionary:array[i]];
                [self.inviteinfo_data addObject:ach];
            }
            
        }
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        NSDictionary*abcDict = @{@"my_invitee_pending":@"a" ,
                                 @"friends_invitee_pending":@"b",
                                 @"total_invitee_pending":@"c",
                                 @"result":@"d",
                                 @"res":@"e"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        
        id obj = [dict objectForKey:@"d"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            self.inviteinfo_data = [[NSMutableArray alloc] init];
            for (int i=0; i< [array count]; i++) {
                TblInviteInfoData *ach = [[TblInviteInfoData alloc] initWithDictionaryABC:array[i]];
                [self.inviteinfo_data addObject:ach];
            }
            
        }
    }
    return self;
}
@end


