//
//  ResponseInviteInfo.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>

@interface ResponseInviteInfo : NSObject

@property (assign, nonatomic) long my_invitee_pending;
@property (assign, nonatomic) long friends_invitee_pending;
@property (assign, nonatomic) long total_invitee_pending;
@property (strong, nonatomic) NSMutableArray* inviteinfo_data;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
@end
