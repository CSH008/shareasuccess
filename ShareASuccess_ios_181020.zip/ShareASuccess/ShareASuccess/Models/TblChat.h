//
//  TblChat.h
//  ShareASuccess
//
//  Created by BoHuang on 7/30/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TblChat : NSObject
@property (copy, nonatomic) NSString* id;
@property (copy, nonatomic) NSString* user_id;
@property (copy, nonatomic) NSString* user_name;
@property (copy, nonatomic) NSString* msg;    // new added
@property (copy, nonatomic) NSString* time_val;    // new added
@property (copy, nonatomic) NSString* ch_id;    // new added
@property (copy, nonatomic) NSString* deleted;
@property (copy, nonatomic) NSString* last_seen;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict Encode:(BOOL)isEncode;
-(instancetype)initWithArray:(NSArray*) dict;

-(void)checkForInsert;

-(void)makeSeen;
-(void)makeNotSeen;

-(void)makeDeleted;
-(void)makeNotDeleted;
//-(NSArray*)getStrValues;
@end
