//
//  TblInvitee.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>

@interface TblInvitee : NSObject

@property (copy, nonatomic) NSString* email_address;
@property (copy, nonatomic) NSString* status;
@property (copy, nonatomic) NSString* custid;
@property (copy, nonatomic) NSString* fname;    // new added
@property (copy, nonatomic) NSString* reqId;    // new added
@property (copy, nonatomic) NSString* accepted_date;    // new added

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict;
-(instancetype)initWithString:(NSString*) data;
-(NSString*)getStringForSql;
-(BOOL)isValid;
@end
