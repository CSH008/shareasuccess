//
//  TblChallenge.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "TblChallenge.h"
#import <objc/runtime.h>
#import "BaseModel.h"
#import "TblInvitee.h"
#import "CGlobal.h"
#import "AppDelegate.h"

@implementation TblChallenge
-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        id obj = [dict objectForKey:@"invitees"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            self.invitees = [[NSMutableArray alloc] init];
            for (int i=0; i< [array count]; i++) {
                TblInvitee *ach = [[TblInvitee alloc] initWithDictionary:array[i]];
                [self.invitees addObject:ach];
            }
        }
        
        
        // total 7 fields existing.
        _colors_gr = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR], [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],nil];
        _colors_my = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR], [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],nil];
        
        if (_date_added!= nil && _date_added.length > 10) {
            _date_added = [CGlobal getFirstDayStringFromString:_date_added isGmt:useGmt];
            _date_added = [_date_added substringToIndex:10];
        }
        
//        if (_type == nil) {
//            _type = @"1";
//        }
//        _type = @"1";
//        _aim_type = @"1";
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        NSDictionary*abcDict = @{@"email_address":@"a" ,
                                 @"fname":@"b",
                                 @"challenge_id":@"c",
                                 @"custId":@"d",
                                 @"challenge_name":@"e",
                                 @"challenge_description":@"f"  ,
                                 @"steps":@"g",
                                 @"walking_running":@"h",
                                 @"stand_hours":@"i"                                 ,
                                 @"active_energy":@"j",
                                 @"cycling_distance":@"k",
                                 @"flights_climbed":@"l",
                                 @"challenge_status":@"m",
                                 @"date_added":@"n",
                                 @"total":@"o",
                                 @"pending":@"p",
                                 @"accepted":@"q",
                                 @"cancelled":@"r"                                 ,
                                 @"invitees":@"s",
                                 @"type":@"t",
                                 @"swim":@"u",
                                 @"aim_steps":@"v",
                                 @"aim_walking_running":@"w",
                                 @"aim_cycling_distance":@"x",
                                 @"aim_stand_hours":@"y",
                                 @"aim_flights_climbed":@"z",
                                 @"aim_active_energy":@"aa" ,
                                 @"aim_swim":@"ab",
                                 @"aim_type":@"ac"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        
        
        id obj = [dict objectForKey:@"s"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            self.invitees = [[NSMutableArray alloc] init];
            for (int i=0; i< [array count]; i++) {
                TblInvitee *ach = [[TblInvitee alloc] initWithDictionaryABC:array[i]];
                [self.invitees addObject:ach];
            }
        }
        
        // total 7 fields existing.
        _colors_gr = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR], [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],nil];
        _colors_my = [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR], [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],nil];
        
        if (_date_added!= nil && _date_added.length > 10) {
            _date_added = [CGlobal getFirstDayStringFromString:_date_added isGmt:useGmt];
            _date_added = [_date_added substringToIndex:10];
            
        }
    }
    return self;
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.rowid = [dict objectAtIndex:0];
        self.challenge_id = [dict objectAtIndex:1];
        self.custId = [dict objectAtIndex:2];
        self.challenge_name = [dict objectAtIndex:3];
        self.challenge_description = [dict objectAtIndex:4];
        self.steps = [dict objectAtIndex:5];
        self.walking_running = [dict objectAtIndex:6];
        self.stand_hours = [dict objectAtIndex:7];
        self.active_energy = [dict objectAtIndex:8];
        self.cycling_distance = [dict objectAtIndex:9];
        self.flights_climbed = [dict objectAtIndex:10];
        self.challenge_status = [dict objectAtIndex:11];
        self.date_added = [dict objectAtIndex:12];
        self.total = [[dict objectAtIndex:13] intValue];
        self.pending = [[dict objectAtIndex:14] intValue];
        self.accepted = [[dict objectAtIndex:15] intValue];
        self.cancelled = [[dict objectAtIndex:16] intValue];
        id obj = [dict objectAtIndex:17];
        if (obj!=nil && obj != [NSNull null] && [obj isKindOfClass:[NSString class]]) {
            _invitees = [[NSMutableArray alloc] init];
            NSString*invitees = (NSString*)obj;
            NSArray* array = [invitees componentsSeparatedByString:@" "];
            for (int i=0; i< [array count]; i++) {
                TblInvitee*item = [[TblInvitee alloc] initWithString:array[i]];
                if ([item isValid]) {
                    [_invitees addObject:item];
                }
            }
        }
        
        self.email_address = [dict objectAtIndex:18];
        self.fname = [dict objectAtIndex:19];
        self.type = dict[20];
        self.swim = dict[21];
        self.aim_steps = dict[22];
        self.aim_walking_running = dict[23];
        self.aim_cycling_distance = dict[24];
        self.aim_stand_hours = dict[25];
        self.aim_flights_climbed = dict[26];
        self.aim_active_energy = dict[27];
        self.aim_swim = dict[28];
        
        self.aim_type = dict[29];
        self.display_order = [dict[30] intValue];
        
        self.aim_walking_running = [self checkComma:self.aim_walking_running Fraction:0];
        self.aim_cycling_distance = [self checkComma:self.aim_cycling_distance Fraction:0];
        self.aim_stand_hours = [self checkComma:self.aim_stand_hours Fraction:0];
        self.aim_active_energy = [self checkComma:self.aim_active_energy Fraction:0];
        self.aim_swim = [self checkComma:self.aim_swim Fraction:1];
//        _color_mydata_steps = GLOBAL_COLOR_NOCOLOR;
//        _color_mydata_walking = GLOBAL_COLOR_NOCOLOR;
//        _color_mydata_standing = GLOBAL_COLOR_NOCOLOR;
//        _color_mydata_active = GLOBAL_COLOR_NOCOLOR;
//        _color_mydata_cycling = GLOBAL_COLOR_NOCOLOR;
//        _color_mydata_flights = GLOBAL_COLOR_NOCOLOR;
//        
//        
//        _color_group_steps = GLOBAL_COLOR_NOCOLOR;
//        _color_group_walking = GLOBAL_COLOR_NOCOLOR;
//        _color_group_standing = GLOBAL_COLOR_NOCOLOR;
//        _color_group_active = GLOBAL_COLOR_NOCOLOR;
//        _color_group_cycling = GLOBAL_COLOR_NOCOLOR;
//        _color_group_flights = GLOBAL_COLOR_NOCOLOR;
        
    }
    return self;
}
-(NSString*)checkComma:(NSString*) value Fraction:(int)fraction{
    @try {
        float p = value.floatValue;
        NSString* format = [NSString stringWithFormat:@"%%.%df",fraction];
        value = [NSString stringWithFormat:format,p];
        return value;
    } @catch (NSException *exception) {
        return value;
    }
}
+(NSString*)getInsertSql:(id)targetClass TableName:(NSString*)tableName{
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([targetClass class], &numberOfProperties);
    
    NSString*sql = nil;
    
    NSString*part1 =@"";
    NSString*part2 =@"";
    NSMutableArray* exceptions = [[NSMutableArray alloc] initWithObjects:@"rowid",@"color_mydata_steps",@"color_mydata_walking",@"color_mydata_standing",@"color_mydata_active",@"color_mydata_cycling",@"color_mydata_flights",@"color_group_steps",@"color_group_walking",@"color_group_standing",@"color_group_active",@"color_group_cycling",@"color_group_flights",@"display_order",@"challengename",@"Description",@"workdistance",@"hours",@"energy",@"climbed",@"email",@"leading_steps",@"leading_walking",@"leading_standing",@"leading_active",@"leading_cycling",@"leading_flights",@"color_mydata_swim",@"color_group_swim",@"leading_swim",@"colors_my",@"colors_gr",@"leading_val",@"msg_count",nil];
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [targetClass valueForKey:name];
        
        if ([exceptions indexOfObject:name] != NSNotFound) {
            continue;
        }
        if (value==nil) {
            NSString*item1 = [NSString stringWithFormat:@"`%@`,",name];
            NSString*item2 = @"'',";
            
            part1 = [part1 stringByAppendingString:item1];
            part2 = [part2 stringByAppendingString:item2];
        }else{
            
            if (value!=nil && [value isKindOfClass:[NSString class]]) {
                value = [CGlobal escapeString:value];
                NSString*item1 = [NSString stringWithFormat:@"`%@`,",name];
                NSString*item2 = [NSString stringWithFormat:@"'%@',",value];
                
                part1 = [part1 stringByAppendingString:item1];
                part2 = [part2 stringByAppendingString:item2];
                
            }else if(value!=nil && [value isKindOfClass:[NSNumber class]]){
                
                NSString*item1 = [NSString stringWithFormat:@"`%@`,",name];
                NSString*item2 = [NSString stringWithFormat:@"'%d',",[value intValue]];
                
                part1 = [part1 stringByAppendingString:item1];
                part2 = [part2 stringByAppendingString:item2];
            }
            else if([name isEqualToString:@"invitees"] && value!=nil && [value isKindOfClass:[NSMutableArray class]]){
                NSString* subvalue = @"";
                
                NSMutableArray* array = (NSMutableArray*)value;
                
                for (int p=0; p< [array count]; p++) {
                    TblInvitee*subitem = array[p];
                    NSString* temp1 = [subitem getStringForSql];
                    subvalue = [subvalue stringByAppendingString:[NSString stringWithFormat:@"%@ ",temp1]];
                }
                if ([subvalue length]>0) {
                    subvalue = [subvalue substringToIndex:[subvalue length]-1];
                    
                    NSString*item1 = [NSString stringWithFormat:@"`%@`,",name];
                    NSString*item2 = [NSString stringWithFormat:@"'%@',",subvalue];
                    
                    part1 = [part1 stringByAppendingString:item1];
                    part2 = [part2 stringByAppendingString:item2];
                }else{
                    subvalue = @",,,,,";
                    
                    NSString*item1 = [NSString stringWithFormat:@"`%@`,",name];
                    NSString*item2 = [NSString stringWithFormat:@"'%@',",subvalue];
                    
                    part1 = [part1 stringByAppendingString:item1];
                    part2 = [part2 stringByAppendingString:item2];
                }
                
                
            }
        }
        
//        NSLog(@"Property %@ attributes: %@", name, name);
    }
    free(propertyArray);
    if ([part1 length] > 0) {
        part1 = [part1 substringToIndex:[part1 length]-1];
        part2 = [part2 substringToIndex:[part2 length]-1];
        
        sql = [NSString stringWithFormat:@"insert into %@ (%@) values (%@)",tableName,part1,part2];
    }
    
    return sql;
}
-(NSArray*)getAimValues{
    
    NSArray* array = @[@"aim_steps",@"aim_walking_running",@"aim_cycling_distance",@"aim_stand_hours",@"aim_flights_climbed",@"aim_active_energy",@"aim_swim"];
    
    NSMutableArray* ret = [[NSMutableArray alloc] initWithArray:@[@"",@"",@"",@"",@"",@"",@""]];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        float fl = 0;
        @try {
            fl = [value floatValue];
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = [NSNumber numberWithFloat:fl];
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getStrAimValues{
    
    NSArray* array = @[@"aim_steps",@"aim_walking_running",@"aim_cycling_distance",@"aim_stand_hours",@"aim_flights_climbed",@"aim_active_energy",@"aim_swim"];
    NSArray* comma_array1 = @[@"aim_swim"];
    
    NSMutableArray* ret = [[NSMutableArray alloc] initWithArray:@[@"",@"",@"",@"",@"",@"",@""]];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        NSString* fl = @"";
        @try {
            if ([comma_array1 indexOfObject:name] != NSNotFound) {
                float val = [value floatValue];
                fl = [NSString stringWithFormat:@"%.1f",val];
            }else{
                int val = [value floatValue];
                fl = [NSString stringWithFormat:@"%i",val];
            }
            
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = fl;
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getChallengeValues{
    
    NSArray* array = @[@"steps",@"walking_running",@"cycling_distance",@"stand_hours",@"flights_climbed",@"active_energy",@"swim"];
    
    NSMutableArray* ret = [[NSMutableArray alloc] initWithArray:@[@"",@"",@"",@"",@"",@"",@""]];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        int fl = 0;
        @try {
            fl = [value intValue];
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = [NSNumber numberWithInt:fl];
        
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getImageArray{
    int challengetype = 0;
    @try {
        challengetype = [self.type intValue];
    } @catch (NSException *exception) {
        
    }
    
    if (challengetype == 0) {
        return @[@"exe_steps",@"exe_walking",@"exe_cycling",@"exe_standing",@"exe_flights",@"exe_activeenergy",@"exe_swim"];
    }else{
        return @[@"exe_steps_2",@"exe_walking_2",@"exe_cycling_2",@"exe_standing_2",@"exe_flights_2",@"exe_activeenergy_2",@"exe_swim_2"];
    }
    
}
+(NSMutableArray*)getLeadingSamples{
    NSMutableArray*array = [[NSMutableArray alloc] init];
    for (int i=0; i<7; i++) {
        [array addObject:[[NSMutableArray alloc] init]];
    }
    return array;
}
-(BOOL)hasMessages{
    if (_msg_count == nil) {
        AppDelegate* appDelegate = [UIApplication sharedApplication].delegate;
        int count = [appDelegate.dbManager notSeenMessages:_challenge_id];
        _msg_count = [NSString stringWithFormat:@"%d",count];
    }
    
    if ([_msg_count intValue]>0) {
        return true;
    }
    return false;
}
@end
