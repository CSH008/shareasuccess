//
//  TblWinnerInfo.h
//  Fit
//
//  Created by Twinklestar on 10/14/16.
//
//

#import "BaseModel.h"

@interface TblWinnerInfo : NSObject

@property (copy, nonatomic) NSString* id;
@property (copy, nonatomic) NSString* challenge_id;
@property (copy, nonatomic) NSString* date_for;
@property (copy, nonatomic) NSString* steps;    // new added
@property (copy, nonatomic) NSString* walking_running;    // new added
@property (copy, nonatomic) NSString* stand_hours;    // new added
@property (copy, nonatomic) NSString* active_energy;
@property (copy, nonatomic) NSString* cycling_distance;
@property (copy, nonatomic) NSString* flights_climbed;
@property (copy, nonatomic) NSString* swim;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict;

-(NSArray*)getValues;
-(NSArray*)getStrValues;
@end
