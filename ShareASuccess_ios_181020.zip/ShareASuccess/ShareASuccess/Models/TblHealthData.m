//
//  TblHealthData.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "TblHealthData.h"
#import "BaseModel.h"
#import <objc/runtime.h>
#import "CGlobal.h"

@implementation TblHealthData

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}
-(void)checkForInsert{
    NSMutableArray* array = [[NSMutableArray alloc] initWithObjects:@"steps",@"sleep",@"active_cal",@"weight",@"calorieGoal",@"exercise",@"standing",@"walking",@"cycling",@"flights",@"activeCalories",@"cal_goal",@"swim", nil];
    
    NSMutableArray* comma_fields = [[NSMutableArray alloc] initWithObjects:@"walking", @"cycling",@"swim",nil];
    
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            continue;
        }
        NSString* value = [self valueForKey:name];
        if (value == nil || [value isEqualToString:@""]) {
            if ([comma_fields indexOfObject:name] == NSNotFound) {
                [self setValue:@"0"  forKey:name];
            }else{
                [self setValue:@"0.0"  forKey:name];
            }
        }else{
            if ([value isEqualToString:@"-"]) {
                continue;
            }else{      //if ([value isEqualToString:@"0"] || [value isEqualToString:@"0.0"] )
                if ([comma_fields indexOfObject:name] == NSNotFound) {
                    int tempval = [value intValue];
                    [self setValue:[NSString stringWithFormat:@"%d",tempval]  forKey:name];
                }
            }
        }
    }
    free(propertyArray);
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.rowid = [dict objectAtIndex:0];
        self.custId = [dict objectAtIndex:1];
        self.date = [dict objectAtIndex:2];
        self.steps = [dict objectAtIndex:3];
        self.sleep = [dict objectAtIndex:4];
        self.active_cal = [dict objectAtIndex:5];
        self.weight = [dict objectAtIndex:6];
        self.calorieGoal = [dict objectAtIndex:7];
        self.exercise = [dict objectAtIndex:8];
        self.standing = [dict objectAtIndex:9];
        self.walking = [dict objectAtIndex:10];
        self.cycling = [dict objectAtIndex:11];
        self.flights = [dict objectAtIndex:12];
        self.day = [dict objectAtIndex:13];
        // swim
        self.swim = [dict objectAtIndex:14];
        
        self.activeCalories = _active_cal;
        self.cal_goal = _calorieGoal;
        
        
    }
    return self;
}
-(instancetype)initWithArrayForBulk:(NSArray*) dict {
    self = [super init];
    if(self) {
        self.steps = [dict objectAtIndex:0];
        self.walking = [dict objectAtIndex:1];
        self.cycling = [dict objectAtIndex:2];
        self.standing = [dict objectAtIndex:3];
        self.flights = [dict objectAtIndex:4];
        self.active_cal = [dict objectAtIndex:5];
        self.swim = [dict objectAtIndex:6];
        
        self.steps = [BaseModel decodeString:self.steps];
        self.walking = [BaseModel decodeString:self.walking];
        self.cycling = [BaseModel decodeString:self.cycling];
        self.standing = [BaseModel decodeString:self.standing];
        self.flights = [BaseModel decodeString:self.flights];
        self.active_cal = [BaseModel decodeString:self.active_cal];
        self.swim = [BaseModel decodeString:self.swim];
        
    }
    return self;
}
-(instancetype)initNull:(NSString*)custId Date:(NSString*)date{
    self = [super init];
    if(self) {
        self.custId = custId;
        self.date = date;
        self.steps = @"-";
        self.sleep = @"-";
        self.active_cal = @"-";
        self.weight = @"-";
        self.calorieGoal = @"-";
        self.exercise = @"-";
        self.standing = @"-";
        self.walking = @"-";
        self.cycling = @"-";
        self.flights = @"-";
        self.swim = @"-";
        
        self.activeCalories = _active_cal;
        self.cal_goal = _calorieGoal;
    }
    return self;
}
-(void)checkForRequest{
    NSMutableArray* array = [[NSMutableArray alloc] initWithObjects:@"steps",@"sleep",@"active_cal",@"weight",@"calorieGoal",@"exercise",@"standing",@"walking",@"cycling",@"flights",@"activeCalories",@"cal_goal", @"swim",nil];
    
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        if (value == nil || [value isEqualToString:@""]) {
            [self setValue:@"0.0"  forKey:name];
        }
    }
    free(propertyArray);
}
-(void)setDate:(NSString *)date{
    //dd/mm/yy
    //yyyy-mm-dd hh:mm:ss
    if (date == nil) {
        return;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@/%@/%@",dd,mm,yy];
    _date = date;
    _day = ret;
}
-(NSString*)getHealthDataRequestString{
    NSString*ret = @"";
    [self checkForRequest];
    ret = [NSString stringWithFormat:@"(%@,%@,%@,%@,%@,%@,%@)",_steps,_walking,_cycling,_standing,_flights,_active_cal,_swim];
    return ret;
}
-(void)checkForUse{    
    NSArray* array = @[@"steps",@"sleep",@"active_cal",@"weight",@"calorieGoal",@"exercise",@"standing",@"walking",@"cycling",@"flights",@"activeCalories",@"cal_goal",@"swim",@"t_steps",@"t_sleep",@"t_weight",@"t_exercise",@"t_standing",@"t_walking",@"t_cycling",@"t_flights",@"t_active_cal",@"t_cal_goal",@"t_swim"];
    
//    NSMutableArray* array = [[NSMutableArray alloc] initWithObjects:@"steps",@"sleep",@"active_cal",@"weight",@"calorieGoal",@"exercise",@"standing",@"walking",@"cycling",@"flights",@"activeCalories",@"cal_goal", @"swim",nil];
    
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        if (value == nil || [value isEqualToString:@""]) {
            [self setValue:@"0.0"  forKey:name];
        }
    }
    free(propertyArray);
}
-(NSArray*)getHealthStrValues{
    NSArray* array = @[@"steps",@"walking",@"cycling",@"standing",@"flights",@"active_cal",@"swim"];
    NSMutableArray* comma_fields1 = [[NSMutableArray alloc] initWithObjects:@"swim",nil];
    NSMutableArray* ret = [TblHealthData getDefaultValuesIndex];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        NSString* f1 = @"0";
        @try {
            if (value!=nil) {
                float ff = [value floatValue];
                if ([comma_fields1 indexOfObject:name] == NSNotFound) {
                    f1 = value;
                }else{
                    f1 = [NSString stringWithFormat:@"%.1f",ff];
                }
                
            }
        } @catch (NSException *exception) {
            
        }
        //[ret addObject:f1];
        NSUInteger index = [array indexOfObject:name];
        ret[index] = f1;
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getHealthValues{
    NSArray* array = @[@"steps",@"walking",@"cycling",@"standing",@"flights",@"active_cal",@"swim"];
    
    NSMutableArray* ret = [TblHealthData getDefaultValuesIndex];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        float fl = 0;
        @try {
            fl = [value floatValue];
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = [NSNumber numberWithFloat:fl];
        
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getTotalHealthStrValues{
    NSArray* array = @[@"t_steps",@"t_walking",@"t_cycling",@"t_standing",@"t_flights",@"t_active_cal",@"t_swim"];
    NSMutableArray* comma_fields1 = [[NSMutableArray alloc] initWithObjects:@"swim",nil];
    NSMutableArray* ret = [TblHealthData getDefaultValuesIndex];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        NSString* f1 = @"0";
        @try {
            if (value!=nil) {
                float ff = [value floatValue];
                if ([comma_fields1 indexOfObject:name] == NSNotFound) {
                    f1 = value;
                }else{
                    f1 = [NSString stringWithFormat:@"%.1f",ff];
                }
            }
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = f1;
        
    }
    free(propertyArray);
    
    return ret;
}
-(NSArray*)getTotalHealthValues{
    NSArray* array = @[@"t_steps",@"t_walking",@"t_cycling",@"t_standing",@"t_flights",@"t_active_cal",@"t_swim"];
    
    NSMutableArray* ret = [TblHealthData getDefaultValuesIndex];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        float fl = 0;
        @try {
            fl = [value floatValue];
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = [NSNumber numberWithFloat:fl];
    }
    free(propertyArray);
    
    return ret;
}
+(NSMutableArray*)getDefaultColorsIndex{
    return [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR], [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],[NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR],nil];
}
+(NSMutableArray*)getDefaultValuesIndex{
    return [[NSMutableArray alloc] initWithObjects:[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:0.0f], [NSNumber numberWithFloat:0.0f],[NSNumber numberWithFloat:0.0f],nil];
}
@end
