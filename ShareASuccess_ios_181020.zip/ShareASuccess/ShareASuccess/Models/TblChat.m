//
//  TblChat.m
//  ShareASuccess
//
//  Created by BoHuang on 7/30/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "TblChat.h"
#import "BaseModel.h"
#import <objc/runtime.h>

@implementation TblChat
-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict Encode:(BOOL)isEncode{
    self = [super init];
    if(self){
        
        NSDictionary*abcDict = @{@"id":@"i" ,
                                 @"user_id":@"u",
                                 @"user_name":@"n",
                                 @"msg":@"m",
                                 @"time_val":@"t",
                                 @"ch_id":@"c"  ,
                                 @"deleted":@"d"  ,
                                 };
        if (isEncode) {
            [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        }else{
            [BaseModel parseResponseABCNoDecode:self Dict:dict ABC:abcDict];
        }
        
        
    }
    return self;
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.id = [dict objectAtIndex:0];
        self.user_id = [dict objectAtIndex:1];
        self.user_name = [dict objectAtIndex:2];
        self.msg = [dict objectAtIndex:3];
        self.time_val = [dict objectAtIndex:4];
        self.ch_id = [dict objectAtIndex:5];
    }
    return self;
}
-(void)makeSeen{
    _last_seen = @"1";
}
-(void)makeNotSeen{
    _last_seen = @"0";
}
-(void)makeDeleted{
    _deleted = @"1";
}
-(void)makeNotDeleted{
    _deleted = @"0";
}
-(void)checkForInsert{
//    NSMutableArray* array = [[NSMutableArray alloc] initWithObjects:@"steps", nil];
//    
//    NSMutableArray* comma_fields = [[NSMutableArray alloc] initWithObjects:@"walking", @"cycling",@"swim",nil];
//    
//    unsigned int numberOfProperties = 0;
//    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
//    
//    for (NSUInteger i = 0; i < numberOfProperties; i++)
//    {
//        objc_property_t property = propertyArray[i];
//        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
//        if ([array indexOfObject:name] == NSNotFound) {
//            continue;
//        }
//        NSString* value = [self valueForKey:name];
//        if (value == nil || [value isEqualToString:@""]) {
//            if ([comma_fields indexOfObject:name] == NSNotFound) {
//                [self setValue:@"0"  forKey:name];
//            }else{
//                [self setValue:@"0.0"  forKey:name];
//            }
//        }else{
//            if ([value isEqualToString:@"-"]) {
//                continue;
//            }else{      //if ([value isEqualToString:@"0"] || [value isEqualToString:@"0.0"] )
//                if ([comma_fields indexOfObject:name] == NSNotFound) {
//                    int tempval = [value intValue];
//                    [self setValue:[NSString stringWithFormat:@"%d",tempval]  forKey:name];
//                }
//            }
//        }
//    }
//    free(propertyArray);
}
@end
