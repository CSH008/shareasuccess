//
//  TblSortInfo.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>

@interface TblSortInfo : NSObject

@property (copy, nonatomic) NSString* rowid;
@property (copy, nonatomic) NSString* id;
@property (copy, nonatomic) NSString* name;
@property (assign, nonatomic) long display_order;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict;
@end
