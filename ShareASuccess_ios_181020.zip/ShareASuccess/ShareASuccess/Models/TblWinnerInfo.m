//
//  TblWinnerInfo.m
//  Fit
//
//  Created by Twinklestar on 10/14/16.
//
//

#import "TblWinnerInfo.h"
#import "BaseModel.h"
#import <objc/runtime.h>

@implementation TblWinnerInfo

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        NSDictionary*abcDict = @{@"id":@"a" ,
                                 @"challenge_id":@"b",
                                 @"date_for":@"c",
                                 @"steps":@"d",
                                 @"walking_running":@"e",
                                 @"stand_hours":@"f"  ,
                                 @"active_energy":@"g",
                                 @"cycling_distance":@"h",
                                 @"flights_climbed":@"i",
                                 @"swim":@"j"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        
    }
    return self;
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.id = [dict objectAtIndex:0];
        self.challenge_id = [dict objectAtIndex:1];
        self.date_for = [dict objectAtIndex:2];
        self.steps = [dict objectAtIndex:3];
        self.walking_running = [dict objectAtIndex:4];
        self.stand_hours = [dict objectAtIndex:5];
        self.active_energy = [dict objectAtIndex:6];
        self.cycling_distance = [dict objectAtIndex:7];
        self.flights_climbed = [dict objectAtIndex:8];
        self.swim = [dict objectAtIndex:9];
    }
    return self;
}
+(NSMutableArray*)getDefaultValues{
    return [[NSMutableArray alloc] initWithObjects:@"",@"",@"",@"",@"",@"",@"",nil];
}
-(NSArray*)getStrValues{
    NSArray* array = @[@"steps",@"walking_running",@"cycling_distance",@"stand_hours",@"flights_climbed",@"active_energy",@"swim"];
    
    NSMutableArray* ret = [TblWinnerInfo getDefaultValues];
    unsigned int numberOfProperties = 0;
    objc_property_t *propertyArray = class_copyPropertyList([self class], &numberOfProperties);
    
    for (NSUInteger i = 0; i < numberOfProperties; i++)
    {
        objc_property_t property = propertyArray[i];
        NSString *name = [[NSString alloc] initWithUTF8String:property_getName(property)];
        if ([array indexOfObject:name] == NSNotFound) {
            
            continue;
        }
        //NSString *attributesString = [[NSString alloc] initWithUTF8String:property_getAttributes(property)];
        NSString* value = [self valueForKey:name];
        NSString* f1 = @"";
        @try {
            if (value!=nil) {
                f1 = value;
            }
        } @catch (NSException *exception) {
            
        }
        NSUInteger index = [array indexOfObject:name];
        ret[index] = f1;
    }
    free(propertyArray);
    
    return ret;
}

@end
