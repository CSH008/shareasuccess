//
//  ResponseMyInfo.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>
#import "ResponseInviteInfo.h"

@interface ResponseMyInfo : NSObject

@property (copy, nonatomic) NSString* calling_custId;
@property (strong, nonatomic) NSMutableArray* allchallenges;
@property (strong, nonatomic) ResponseInviteInfo* inviteinfo;
@property (strong, nonatomic) NSMutableArray* sortinfo;
@property (strong, nonatomic) NSMutableArray* winnerinfo;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
@end
