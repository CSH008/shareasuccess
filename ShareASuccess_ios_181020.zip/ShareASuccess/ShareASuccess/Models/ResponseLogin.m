//
//  ResponseLogin.m
//  Fit
//
//  Created by BoHuang on 7/2/16.
//
//

#import "ResponseLogin.h"
#import "BaseModel.h"

@implementation ResponseLogin

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}

@end
