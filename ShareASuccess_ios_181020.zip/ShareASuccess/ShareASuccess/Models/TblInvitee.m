//
//  TblInvitee.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "TblInvitee.h"
#import "BaseModel.h"
#import "CGlobal.h"

@implementation TblInvitee

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
        if (_accepted_date!=nil && [_accepted_date length]>10) {
            // yyyy-mm-dd
            _accepted_date = [CGlobal getFirstDayStringFromString:_accepted_date isGmt:useGmt];
            _accepted_date = [_accepted_date substringToIndex:10];
        }
        
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        NSDictionary*abcDict = @{@"reqId":@"a" ,
                                 @"email_address":@"b",
                                 @"status":@"c",
                                 @"custid":@"d",
                                 @"fname":@"e",
                                 @"accepted_date":@"f"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        
        if (_accepted_date!=nil && [_accepted_date length]>10) {
            // yyyy-mm-dd
            _accepted_date = [CGlobal getFirstDayStringFromString:_accepted_date isGmt:useGmt];
            _accepted_date = [_accepted_date substringToIndex:10];
        }
        
    }
    return self;
}
-(instancetype)initWithString:(NSString*) data{
    self = [super init];
    if(self){
        
        if (data!=nil && ![data isEqualToString:@""]) {
            NSArray* array = [data componentsSeparatedByString:@","];
            if ([array count] == 6) {
                _email_address = array[0];
                _status = array[1];
                _custid = array[2];
                _fname = array[3];
                _reqId = array[4];
                _accepted_date = array[5];
            }
        }
        
    }
    return self;
}
-(BOOL)isValid{
    if (_email_address==nil || [_email_address isEqualToString:@""]) {
        return false;
    }
    if (_status==nil || [_status isEqualToString:@""]) {
        return false;
    }
    if (_email_address==nil || [_email_address isEqualToString:@""]) {
        return false;
    }
    if (_custid==nil || [_custid isEqualToString:@""]) {
        return false;
    }
//    if (_reqId==nil || [_reqId isEqualToString:@""]) {
//        return false;
//    }

    return true;
}
-(NSString*)getStringForSql{
    NSString* value = @"";
    
    
    if (_email_address!=nil) {
        value = [value stringByAppendingString:_email_address];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    if (_status!=nil) {
        value = [value stringByAppendingString:_status];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    if (_custid!=nil) {
        value = [value stringByAppendingString:_custid];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    if (_fname!=nil) {
        value = [value stringByAppendingString:_fname];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    if (_reqId!=nil) {
        value = [value stringByAppendingString:_reqId];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    if (_accepted_date!=nil) {
        value = [value stringByAppendingString:_accepted_date];
        value = [value stringByAppendingString:@","];
    }else{
        value = [value stringByAppendingString:@","];
    }
    
    
    value = [value substringToIndex:[value length]-1];
    return value;
}
@end
