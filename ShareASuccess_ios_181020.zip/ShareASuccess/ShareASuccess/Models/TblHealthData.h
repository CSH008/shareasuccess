//
//  TblHealthData.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>

@interface TblHealthData : NSObject

//request
@property (copy, nonatomic) NSString* rowid;
@property (copy, nonatomic) NSString* custId;
@property (copy, nonatomic) NSString* date;

@property (copy, nonatomic) NSString* steps;
@property (copy, nonatomic) NSString* sleep;
@property (copy, nonatomic) NSString* weight;
@property (copy, nonatomic) NSString* exercise;
@property (copy, nonatomic) NSString* standing;
@property (copy, nonatomic) NSString* walking;
@property (copy, nonatomic) NSString* cycling;
@property (copy, nonatomic) NSString* flights;
@property (copy, nonatomic) NSString* active_cal;
@property (copy, nonatomic) NSString* cal_goal;
@property (copy, nonatomic) NSString* swim;

@property (copy, nonatomic) NSString* t_steps;
@property (copy, nonatomic) NSString* t_sleep;
@property (copy, nonatomic) NSString* t_weight;
@property (copy, nonatomic) NSString* t_exercise;
@property (copy, nonatomic) NSString* t_standing;
@property (copy, nonatomic) NSString* t_walking;
@property (copy, nonatomic) NSString* t_cycling;
@property (copy, nonatomic) NSString* t_flights;
@property (copy, nonatomic) NSString* t_active_cal;
@property (copy, nonatomic) NSString* t_cal_goal;
@property (copy, nonatomic) NSString* t_swim;

@property (copy, nonatomic) NSString* action;
@property (assign, nonatomic) long result;
@property (copy, nonatomic) NSString* res;
@property (copy, nonatomic) NSString* users;

@property (copy, nonatomic) NSString* activeCalories;
@property (copy, nonatomic) NSString* calorieGoal;

@property (copy, nonatomic) NSString* day;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict ;
-(void)setDate:(NSString *)date;
-(void)checkForRequest;
-(instancetype)initNull:(NSString*)custId Date:(NSString*)date;
-(void)checkForInsert;
-(NSString*)getHealthDataRequestString;

-(instancetype)initWithArrayForBulk:(NSArray*) dict ;
-(void)checkForUse;
-(NSArray*)getHealthValues;
-(NSArray*)getTotalHealthValues;
+(NSMutableArray*)getDefaultColorsIndex;
-(NSArray*)getTotalHealthStrValues;
-(NSArray*)getHealthStrValues;
-(NSMutableArray*)getDefaultValuesIndex;
@end
