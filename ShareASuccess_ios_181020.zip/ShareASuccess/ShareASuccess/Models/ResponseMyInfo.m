//
//  ResponseMyInfo.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "ResponseMyInfo.h"
#import "BaseModel.h"
#import "TblChallenge.h"
#import "ResponseInviteInfo.h"
#import "TblSortInfo.h"
#import "TblWinnerInfo.h"
#import "CGlobal.h"

@implementation ResponseMyInfo
-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
     
        id obj = [dict objectForKey:@"allchallenges"];
        if (obj!=nil && obj!= [NSNull null] && [obj isKindOfClass:[NSDictionary class]]) {
            NSDictionary*subdict = obj;
            self.allchallenges = [[NSMutableArray alloc] init];
            for (NSString* subkey in subdict) {
                if (useEncode) {
                    TblChallenge *item = [[TblChallenge alloc] initWithDictionaryABC:subdict[subkey]];
                    [self.allchallenges addObject:item];
                }else{
                    TblChallenge *item = [[TblChallenge alloc] initWithDictionary:subdict[subkey]];
                    [self.allchallenges addObject:item];
                }
                
            }
        }
        
        obj = [dict objectForKey:@"inviteinfo"];
        if (obj!=nil && obj!= [NSNull null]) {
            if (useEncode) {
                self.inviteinfo = [[ResponseInviteInfo alloc] initWithDictionaryABC:obj];
            }else{
                self.inviteinfo = [[ResponseInviteInfo alloc] initWithDictionary:obj];
            }
            
            
        }
        
        obj = [dict objectForKey:@"sortinfo"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            self.sortinfo = [[NSMutableArray alloc] init];
            for (int i=0; i< [array count]; i++) {
                if (useEncode) {
                    TblSortInfo *ach = [[TblSortInfo alloc] initWithDictionaryABC:array[i]];
                    [self.sortinfo addObject:ach];
                }else{
                    TblSortInfo *ach = [[TblSortInfo alloc] initWithDictionary:array[i]];
                    [self.sortinfo addObject:ach];
                }
                
                
                
            }
        }
        
        self.winnerinfo = nil;
        obj = [dict objectForKey:@"winnerinfo"];
        if (obj!=nil && obj!= [NSNull null]) {
            NSArray*array = obj;
            if ([obj isKindOfClass:[NSArray class]]) {
                self.winnerinfo = [[NSMutableArray alloc] init];
                for (int i=0; i< [array count]; i++) {
                    if (useEncode) {
                        TblWinnerInfo *ach = [[TblWinnerInfo alloc] initWithDictionaryABC:array[i]];
                        [self.winnerinfo addObject:ach];
                    }else{
                        TblWinnerInfo *ach = [[TblWinnerInfo alloc] initWithDictionary:array[i]];
                        [self.winnerinfo addObject:ach];
                    }
                    
                    
                }
            }
        }
    }
    return self;
}
@end
