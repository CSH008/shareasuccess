//
//  ResponseLogin.h
//  Fit
//
//  Created by BoHuang on 7/2/16.
//
//

#import <Foundation/Foundation.h>

@interface ResponseLogin : NSObject

@property (assign, nonatomic) int result;
@property (copy, nonatomic) NSString* res;
@property (copy, nonatomic) NSString* custId;
@property (copy, nonatomic) NSString* custName;
@property (copy, nonatomic) NSString* custLname;
@property (copy, nonatomic) NSString* emailAddress;
@property (copy, nonatomic) NSString* password;
@property (copy, nonatomic) NSString* screen;
@property (copy, nonatomic) NSString* public_share;
@property (copy, nonatomic) NSString* lastSyncDate;
@property (copy, nonatomic) NSString* push_enabled;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
@end
