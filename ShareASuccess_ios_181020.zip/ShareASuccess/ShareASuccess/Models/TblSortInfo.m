//
//  TblSortInfo.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "TblSortInfo.h"
#import "BaseModel.h"
@implementation TblSortInfo
-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        NSDictionary*abcDict = @{@"id":@"a" ,
                                 @"name":@"b",
                                 @"display_order":@"c"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
        
        
    }
    return self;
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.rowid = [dict objectAtIndex:0];
        self.id = [dict objectAtIndex:1];
        self.name = [dict objectAtIndex:2];
        self.display_order = [[dict objectAtIndex:3] intValue];
    }
    return self;
}
@end
