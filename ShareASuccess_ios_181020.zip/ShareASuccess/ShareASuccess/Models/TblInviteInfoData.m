//
//  TblInviteInfoData.m
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import "TblInviteInfoData.h"
#import "BaseModel.h"
@implementation TblInviteInfoData

-(instancetype)initWithDictionary:(NSDictionary*) dict{
    self = [super init];
    if(self){
        
        [BaseModel parseResponse:self Dict:dict];
        
    }
    return self;
}
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict{
    self = [super init];
    if(self){
        //@"total":@"a" ,
        //@"pending" @"k"
        NSDictionary*abcDict = @{
                                 @"total":@"a" ,
                                 @"custId":@"b",
                                 @"fname":@"c",
                                 @"challenge_name":@"d",
                                 @"challenge_description":@"e",
                                 @"challenge_id":@"f",
                                 @"reqId":@"g",
                                 @"date":@"h",
                                 @"type":@"i",
                                 @"status":@"j"};
        
        [BaseModel parseResponseABC:self Dict:dict ABC:abcDict];
                
    }
    return self;
}
-(instancetype)initWithArray:(NSArray*) dict{
    self = [super init];
    if(self) {
        self.rowid = [dict objectAtIndex:0];
        self.custId = [dict objectAtIndex:1];
        self.fname = [dict objectAtIndex:2];
        self.challenge_name = [dict objectAtIndex:3];
        self.challenge_description = [dict objectAtIndex:4];
        self.challenge_id = [dict objectAtIndex:5];
        self.reqId = [dict objectAtIndex:6];
        self.date = [dict objectAtIndex:7];
        self.type = [dict objectAtIndex:8];
        self.status = [dict objectAtIndex:9];
        
        
//        self.total = 0;
//        self.pending = 0;
        self.total = [[dict objectAtIndex:10] intValue];
        self.pending = [[dict objectAtIndex:11] intValue];
    }
    return self;
}

+(TblInviteInfoData*) cloneThis:(TblInviteInfoData*)data{
    TblInviteInfoData* ret = [[TblInviteInfoData alloc] init];
    ret.reqId = data.reqId;
    return ret;
}
@end
