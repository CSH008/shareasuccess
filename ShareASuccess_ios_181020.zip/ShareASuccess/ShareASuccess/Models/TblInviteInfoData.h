//
//  TblInviteInfoData.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>
#import "TblChallenge.h"

@interface TblInviteInfoData : NSObject

@property (copy, nonatomic) NSString* rowid;
@property (copy, nonatomic) NSString* custId;
@property (copy, nonatomic) NSString* fname;
@property (copy, nonatomic) NSString* challenge_name;
@property (copy, nonatomic) NSString* challenge_description;
@property (copy, nonatomic) NSString* challenge_id;
@property (copy, nonatomic) NSString* reqId;
@property (copy, nonatomic) NSString* date;
@property (copy, nonatomic) NSString* type;
@property (copy, nonatomic) NSString* status;

-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict;

//@property (copy, nonatomic) NSString* total;
//@property (copy, nonatomic) NSString* pending;

@property (assign, nonatomic) long total;
@property (assign, nonatomic) long pending;

+(TblInviteInfoData*) cloneThis:(TblInviteInfoData*)data;

-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
@end
