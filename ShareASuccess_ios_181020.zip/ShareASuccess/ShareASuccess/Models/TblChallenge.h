//
//  TblChallenge.h
//  Fit
//
//  Created by BoHuang on 6/30/16.
//
//

#import <Foundation/Foundation.h>

@interface TblChallenge : NSObject

@property (copy, nonatomic) NSString* rowid;
@property (copy, nonatomic) NSString* challenge_id;
@property (copy, nonatomic) NSString* custId;
@property (copy, nonatomic) NSString* challenge_name;
@property (copy, nonatomic) NSString* challenge_description;
@property (copy, nonatomic) NSString* steps;
@property (copy, nonatomic) NSString* walking_running;
@property (copy, nonatomic) NSString* stand_hours;
@property (copy, nonatomic) NSString* active_energy;
@property (copy, nonatomic) NSString* cycling_distance;
@property (copy, nonatomic) NSString* flights_climbed;
@property (copy, nonatomic) NSString* challenge_status;
@property (copy, nonatomic) NSString* date_added;
@property (assign, nonatomic) long total;
@property (assign, nonatomic) long pending;
@property (assign, nonatomic) long accepted;
@property (assign, nonatomic) long cancelled;
@property (strong, nonatomic) NSMutableArray* invitees;
@property (copy, nonatomic) NSString* email_address;
@property (copy, nonatomic) NSString* fname;
@property (copy, nonatomic) NSString* type;
@property (copy, nonatomic) NSString* swim;
@property (copy, nonatomic) NSString* aim_steps;
@property (copy, nonatomic) NSString* aim_walking_running;
@property (copy, nonatomic) NSString* aim_cycling_distance;
@property (copy, nonatomic) NSString* aim_stand_hours;
@property (copy, nonatomic) NSString* aim_flights_climbed;
@property (copy, nonatomic) NSString* aim_active_energy;
@property (copy, nonatomic) NSString* aim_swim;
@property (copy, nonatomic) NSString* aim_type;

@property (copy, nonatomic) NSString* msg_count;


@property (assign, nonatomic) long display_order;

//@property (assign, nonatomic) int color_mydata_steps;
//@property (assign, nonatomic) int color_mydata_walking;
//@property (assign, nonatomic) int color_mydata_standing;
//@property (assign, nonatomic) int color_mydata_active;
//@property (assign, nonatomic) int color_mydata_cycling;
//@property (assign, nonatomic) int color_mydata_flights;
//@property (assign, nonatomic) int color_mydata_swim;

@property (strong, nonatomic) NSMutableArray* colors_my;
@property (strong, nonatomic) NSMutableArray* colors_gr;
@property (strong, nonatomic) NSMutableArray* leading_val;

//@property (assign, nonatomic) int color_group_steps;
//@property (assign, nonatomic) int color_group_walking;
//@property (assign, nonatomic) int color_group_standing;
//@property (assign, nonatomic) int color_group_active;
//@property (assign, nonatomic) int color_group_cycling;
//@property (assign, nonatomic) int color_group_flights;
//@property (assign, nonatomic) int color_group_swim;

//@property (strong, nonatomic) NSMutableArray* leading_steps;
//@property (strong, nonatomic) NSMutableArray* leading_walking;
//@property (strong, nonatomic) NSMutableArray* leading_standing;
//@property (strong, nonatomic) NSMutableArray* leading_active;
//@property (strong, nonatomic) NSMutableArray* leading_cycling;
//@property (strong, nonatomic) NSMutableArray* leading_flights;
//@property (strong, nonatomic) NSMutableArray* leading_swim;


-(instancetype)initWithDictionary:(NSDictionary*) dict;
-(instancetype)initWithDictionaryABC:(NSDictionary*) dict;
-(instancetype)initWithArray:(NSArray*) dict;

+(NSString*)getInsertSql:(id)targetClass TableName:(NSString*)tableName;

// request Fields
//@property (copy, nonatomic) NSString* custId;
@property (copy, nonatomic) NSString* challengename;
@property (copy, nonatomic) NSString* Description;
//@property (copy, nonatomic) NSString* steps;
//@property (copy, nonatomic) NSString* cycling_distance;
@property (copy, nonatomic) NSString* workdistance;
@property (copy, nonatomic) NSString* hours;
@property (copy, nonatomic) NSString* energy;
@property (copy, nonatomic) NSString* climbed;
@property (strong, nonatomic) NSMutableArray* email;
-(NSArray*)getAimValues;
-(NSArray*)getChallengeValues;
-(NSArray*)getImageArray;
+(NSMutableArray*)getLeadingSamples;
-(NSArray*)getStrAimValues;

-(BOOL)hasMessages;
@end
