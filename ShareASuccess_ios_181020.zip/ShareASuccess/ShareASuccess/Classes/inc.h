//
//  inc.h
//  Fit
//
//  Created by Denis on 10/9/15.
//
//

#ifndef inc_h
#define inc_h

#define SEGUE_LOGIN_TO_MAIN             @"LoginToMain"
#define SEGUE_LOGIN_TO_USERSETUP        @"LoginToUserSetup"
#define SEGUE_LOGIN_TO_RESETPASSWORD        @"LoginToResetPassword"
#define SEGUE_RESETPASSWORD_TO_RESETPASSWORDMESSAGE @"ResetPasswordToResetPasswordMessage"
#define SEGUE_CHALLENGE_TO_ADDCHALLENGE @"ChallengeToAddChallenge"
#define SEGUE_CHALLENGE_TO_CHALLENGEDETAIL  @"ChallengeToChallengeDetail"
#define SEGUE_CHALLENGEDETAIL_TO_ADDCHALLENGE   @"ChallengeDetailToAddChallenge"
#define SEGUE_CHALLENGEDETAIL_TO_CHALLENGE   @"ChallengeDetailToChallenge"
#define SEGUE_CHALLENGE_TO_EDITCHALLENGE @"ChallengeToEditChallenge"

#define ALERT_TITLE_DEFAULT @"Alert"
#define ALERT_ERRORMESSAGE @"Request failed."
#define ALERT_ERRORNOINTERNET @"You don't seem to be connected to the internet, please check your connection and try again."
#define ALERT_LOGIN_INFORMATION_EMPTY @"Email and password should be required."
#define ALERT_LOGIN_FAILED @"Login failed."
#define ALERT_REGISTER_INFORMATION_EMPTY @"All fields should be required."
#define ALERT_REGISTER_INVALID_EMAIL @"Please enter a valid email address and try again."
#define ALERT_REGISTER_EMAIL_DIFFERENT  @"Please input same email address."
#define ALERT_REGISTER_FAILED @"Registering failed."
#define ALERT_EMAIL_REQUIRE @"Email should be required."
#define ALERT_PROFILE_PASSWORD_DIFFERENT  @"Please input same password."
#define ALERT_PROFILE_UPDATE_SUCCESS @"Your profile successfully updated."
#define ALERT_CHALLENGE_NAME_REQUIRED   @"Challenge name should be required."
#define ALERT_SAVECHALLENGE_FAILED   @"Challenge saving failed."

#define ALERT_SUMMARY_INFORMATION_EMPTY @"Summary information is empty. Please try again."
#define ALERT_TOMORROWDATE_INFORMATION_EMPTY @"Summary information is empty. Please try again."
#define ALERT_SAVE_MYSUMMARY_ERROR @"Saving your summary data is failed."
#define ALERT_INVITE_INFORMATION_EMPTY @"Invite information is empty. Please try again."
#define ALERT_NEWINVITE_NAME_EMPTY @"Please input the name."
#define ALERT_NEWINVITE_EMAIL_EMPTY @"Please input the email address."
#define ALERT_NEWINVITE_INFORMATION_EMPTY @"Sending is failed."

#define SERVICE_TIMEOUT 15

#endif /* inc_h */
