//
//  Utils.m
//  Fit
//
//  Created by Denis on 10/9/15.
//
//

#import "Utils.h"

@implementation CustInfo
@end

@implementation SummaryInfo
-(NSString*)getHealthDataRequestString{
    NSString*ret = @"";
//    [self checkForRequest];
    
    
    ret = [NSString stringWithFormat:@"(%@,%@,%@,%@,%@,%@,%@)",_steps,_walking,_cycling,_standing,_flights,_activeCal,_swimming];
    
//    ret = [NSString stringWithFormat:@"(%@,%@,%@,%@,%@,%@,%@)",_steps,_walking,_cycling,_standing,_flights,_active_cal,_swim];
    return ret;
}
@end

@implementation InviteInfo
@end

@implementation ChallengeData
@end

@implementation ChallengeInfo
@end
/*
@implementation ChallengeDetailInfo
@end
*/
@implementation GetChallengeDetail
@end
@implementation Utils

+ (void) showAlert:(NSString *)description title:(NSString *)title
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title
                                                    message:description
                                                   delegate:nil
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

+ (NSString *) getShortStringFromDate:(NSDate *)date {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    
    NSString *monthName;
    
    switch ([components month]) {
        case 1:
            monthName = @"Jan";
            break;
        case 2:
            monthName = @"Feb";
            break;
        case 3:
            monthName = @"Mar";
            break;
        case 4:
            monthName = @"Apr";
            break;
        case 5:
            monthName = @"May";
            break;
        case 6:
            monthName = @"Jun";
            break;
        case 7:
            monthName = @"Jul";
            break;
        case 8:
            monthName = @"Aug";
            break;
        case 9:
            monthName = @"Sep";
            break;
        case 10:
            monthName = @"Oct";
            break;
        case 11:
            monthName = @"Nov";
            break;
        case 12:
            monthName = @"Dec";
            break;
        default:
            break;
    }
    
    NSString *stringDate = [NSString stringWithFormat:@"%i %@", (int)[components day], monthName];
    
    return stringDate;
}

+ (NSString *) getLongStringFromDate:(NSDate *)date {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    
    NSString *monthName;
    
    switch ([components month]) {
        case 1:
            monthName = @"Jan";
            break;
        case 2:
            monthName = @"Feb";
            break;
        case 3:
            monthName = @"Mar";
            break;
        case 4:
            monthName = @"Apr";
            break;
        case 5:
            monthName = @"May";
            break;
        case 6:
            monthName = @"Jun";
            break;
        case 7:
            monthName = @"Jul";
            break;
        case 8:
            monthName = @"Aug";
            break;
        case 9:
            monthName = @"Sep";
            break;
        case 10:
            monthName = @"Oct";
            break;
        case 11:
            monthName = @"Nov";
            break;
        case 12:
            monthName = @"Dec";
            break;
        default:
            break;
    }
    
    NSString *stringDate = [NSString stringWithFormat:@"%i %@ %i", (int)[components day], monthName, (int)[components year]];
    
    return stringDate;
}

+ (NSString *) getJsonStringFromDate:(NSDate *)date {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    NSString *stringDate = [NSString stringWithFormat:@"%.2i/%.2i/%i", (int)[components day], (int)[components month], (int)[components year]];
    
    return stringDate;
}

+ (NSDate *) getDateFromJsonString:(NSString *)string {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormatter setLocale:locale];
    NSDate *date = [dateFormatter dateFromString:string];
    return date;
}

+ (NSString *) getStringFromDate:(NSDate *)date
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"dd/MM/yyyy"];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [dateFormatter setLocale:locale];
    NSString *newDate = [dateFormatter stringFromDate:date];
    return newDate;
}

+ (NSDate *) getYesterdayTomorrowDate:(BOOL)bYesterday date:(NSDate *)date {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:date];
    
    if (bYesterday)
        [components setDay:([components day] - 1)];
    else
        [components setDay:([components day] + 1)];
    NSDate *resDate = [calendar dateFromComponents:components];
    
    return resDate;
}

+ (NSDate *) getDate:(int)month {
    NSCalendar* calendar = [NSCalendar currentCalendar];
    calendar.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    NSDateComponents* components = [calendar components:NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay fromDate:[NSDate date]];
    
    [components setMonth:month];
    NSDate *resDate = [calendar dateFromComponents:components];
    
    return resDate;
}

+(NSString *)convertArrayToJsonString : (NSMutableArray *)arr
{
    NSData *jsonData2 = [NSJSONSerialization dataWithJSONObject:arr options:NSJSONWritingPrettyPrinted error:nil];
    NSString *jsonString = [[NSString alloc] initWithData:jsonData2 encoding:NSUTF8StringEncoding];
    
    return jsonString;
}

+(NSMutableArray *)convertJsonStringToArray :(NSString *)jsonString
{
    NSData* data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSArray *values = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];  // if you are expecting  the JSON string to be in form of array else use NSDictionary instead

    return [[NSMutableArray alloc] initWithArray:values];
}

@end
