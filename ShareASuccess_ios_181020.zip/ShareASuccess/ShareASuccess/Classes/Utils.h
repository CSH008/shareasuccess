//
//  Utils.h
//  Fit
//
//  Created by Denis on 10/9/15.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface CustInfo : NSObject
@property (assign, nonatomic) int custId;
@property (strong, nonatomic) NSString *firstName;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *screenName;
@property (strong, nonatomic) NSString *email;
@property (strong, nonatomic) NSString *password;
@property (strong, nonatomic) NSString *publicdata;

@end

@interface SummaryInfo : NSObject
-(NSString*)getHealthDataRequestString;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSDate *date;
@property (strong, nonatomic) NSString *steps;
@property (strong, nonatomic) NSString *sleep;
@property (strong, nonatomic) NSString *activeCal;
@property (strong, nonatomic) NSString *weight;
@property (strong, nonatomic) NSString *walking;
@property (strong, nonatomic) NSString *cycling;
@property (strong, nonatomic) NSString *flights;
@property (strong, nonatomic) NSString *calorieGoal;
@property (strong, nonatomic) NSString *exercise;
@property (strong, nonatomic) NSString *standing;
@property (strong, nonatomic) NSString *swimming;
@end

@interface InviteInfo : NSObject
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *challengename;
@property (assign, nonatomic) int custId;
@property (assign, nonatomic) int challengeId;
@property (assign, nonatomic) int reqId;
@property (strong, nonatomic) NSDate *date;
@property (assign, nonatomic) int type;
@property (assign, nonatomic) int status;
@property (assign, nonatomic) int myinvitepending;
@property (assign, nonatomic) int friendinvitepending;
@property (assign, nonatomic) int totalinvitepending;
@property (assign, nonatomic) NSString *needToUpdate;
@end

@interface ChallengeData : NSObject
@property (assign, nonatomic) int challengeId;
@property (strong, nonatomic) NSString *challengename;
@property (strong, nonatomic) NSString *challengedescription;
@property (assign, nonatomic) int custId;
@property (assign, nonatomic) int reqId;
@property (strong, nonatomic) NSDate *date;
@property (assign, nonatomic) int type;
@property (assign, nonatomic) int myinvitepending;
@property (assign, nonatomic) int friendinvitepending;
@property (assign, nonatomic) int status;
@property (strong, nonatomic) NSString *needToUpdate;
@end


@interface ChallengeInfo : NSObject
@property (assign, nonatomic) int id;
@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *detail;
@property (strong, nonatomic) NSString *challengedescription;
@property (strong, nonatomic) NSString *challengeadded;
@property (strong, nonatomic) NSString *display_order;
@property (assign, nonatomic) int challengestatus;
@property (assign, nonatomic) int total;
@property (assign, nonatomic) int pending;
@property (assign, nonatomic) int step_myself;
@property (assign, nonatomic) int step_group;
@property (assign, nonatomic) int active_myself;
@property (assign, nonatomic) int active_group;
@property (assign, nonatomic) int walking_myself;
@property (assign, nonatomic) int walking_group;
@property (assign, nonatomic) int cycling_myself;
@property (assign, nonatomic) int cycling_group;
@property (assign, nonatomic) int flights_myself;
@property (assign, nonatomic) int flights_group;
@property (assign, nonatomic) int standing_myself;
@property (assign, nonatomic) int standing_group;
@property (assign, nonatomic) BOOL bSteps;
@property (assign, nonatomic) BOOL bWalking;
@property (assign, nonatomic) BOOL bCycling;
@property (assign, nonatomic) BOOL bStanding;
@property (assign, nonatomic) BOOL bActive;
@property (assign, nonatomic) BOOL bFlights;
@property (assign, nonatomic) NSString *challenge_type;

@end

@interface GetChallengeDetail : NSObject

@property (strong, nonatomic) NSString *challengename;
@property (strong, nonatomic) NSString *challengedescription;
@property (assign, nonatomic) int steps;
@property (assign, nonatomic) int cycling;
@property (assign, nonatomic) int walking;
@property (assign, nonatomic) int standing;
@property (assign, nonatomic) int active;
@property (assign, nonatomic) int flights;
@property (strong, nonatomic) NSString *invitesemail;
@property (assign, nonatomic) int status;
@end

@interface Utils : NSObject

+ (void) showAlert:(NSString *)description title:(NSString *)title;

+ (void) showLoading;
+ (void) hideLoading;

+ (NSString *) getShortStringFromDate:(NSDate *)date;
+ (NSString *) getLongStringFromDate:(NSDate *)date;
+ (NSString *) getJsonStringFromDate:(NSDate *)date;
+ (NSDate *) getDateFromJsonString:(NSString *)string;
+ (NSDate *) getYesterdayTomorrowDate:(BOOL)bYesterday date:(NSDate *)date;

+ (NSString *) getStringFromDate:(NSDate *)date;

+ (NSDate *) getDate:(int)month;

+(NSString *)convertArrayToJsonString : (NSMutableArray *)arr;

+(NSMutableArray *)convertJsonStringToArray :(NSString *)jsonString;

@end
