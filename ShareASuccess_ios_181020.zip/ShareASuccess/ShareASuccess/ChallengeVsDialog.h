//
//  ChallengeVsDialog.h
//  ShareASuccess
//
//  Created by BoHuang on 9/10/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TblChallenge.h"
#import "MainDetailTableViewCell.h"
#import "MainDetailAimTableViewCell.h"
#import "CGlobal.h"
#import "ChallengeDetailViewController.h"
#import "TblHealthData.h"
#import "UIView+Property.h"
#import "MyPopupDialog.h"


@interface ChallengeVsDialog : UIView<UITableViewDelegate, UITableViewDataSource, UIAlertViewDelegate,ViewDialogDelegate>
@property (weak, nonatomic) IBOutlet UIImageView *img_user1;
@property (weak, nonatomic) IBOutlet UIImageView *img_user2;

@property (weak, nonatomic) IBOutlet UIView *viewBackground;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *viewHeader;
@property (weak, nonatomic) IBOutlet UILabel *lblUser1;
@property (weak, nonatomic) IBOutlet UILabel *lblUser2;

@property (nonatomic,assign) BOOL can_goleft;
@property (nonatomic,assign) BOOL can_goright;

-(BOOL)setData:(CGRect)viewRootRect Vc:(ChallengeDetailViewController*)vc TargetId:(NSString*)targetid;

-(void)firstProcess:(CGRect)viewRootRect Vc:(ChallengeDetailViewController*)vc;

@property (nonatomic,strong) NSString* targetId;
@end
