//
//  UITableViewCellFixed.m
//  Sample
//
//  Created by BoHuang on 12/24/16.
//  Copyright © 2016 Ralph Shane. All rights reserved.
//

#import "UITableViewCellFixed.h"

@implementation UITableViewCellFixed

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void) layoutSubviews {
    [super layoutSubviews];
    CGSize size = self.frame.size;
    self.textLabel.frame = CGRectMake(5, 0, size.width, size.height);
}

@end
