//
//  UITableViewCellFixed.h
//  Sample
//
//  Created by BoHuang on 12/24/16.
//  Copyright © 2016 Ralph Shane. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITableViewCellFixed : UITableViewCell

@end
