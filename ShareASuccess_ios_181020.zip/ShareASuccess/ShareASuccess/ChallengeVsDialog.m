//
//  ChallengeVsDialog.m
//  ShareASuccess
//
//  Created by BoHuang on 9/10/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "ChallengeVsDialog.h"
#import "UIView+Animation.h"

@interface ChallengeVsDialog()

@property (strong, nonatomic) TblChallenge *challengeInfo;
@property (assign, nonatomic) int challengeType;
@property (assign, nonatomic) CGFloat cellHeight;
@property (nonatomic, strong) NSMutableArray* listData;

@property (nonatomic, strong) TblHealthData* my_data;
@property (strong, nonatomic) NSMutableDictionary *group_data;
@property (nonatomic,strong) TblWinnerInfo *winnerinfo;
@property (nonatomic,strong) ChallengeDetailViewController* vc;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contraintTableHeight;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contraintTitleTop;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_TopHeight;

@end

@implementation ChallengeVsDialog

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setMyStyle:(CGRect)viewRootRect{
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:viewRootRect];
    self.layer.masksToBounds = NO;
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    self.layer.shadowOpacity = 0.5f;
    self.layer.shadowPath = shadowPath.CGPath;
}

-(void)firstProcess:(CGRect)viewRootRect Vc:(ChallengeDetailViewController*)vc{
    UISwipeGestureRecognizer*swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeLeft:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionLeft];
    [self addGestureRecognizer:swipe];

    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeRight:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [self addGestureRecognizer:swipe];
//
//    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeUp:)];
//    [swipe setDirection:UISwipeGestureRecognizerDirectionUp];
//    [self addGestureRecognizer:swipe];
//
//    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeDown:)];
//    [swipe setDirection:UISwipeGestureRecognizerDirectionDown];
//    [self addGestureRecognizer:swipe];
    
    NSString *identifier = @"MainDetailAimTableViewCell";
    [_tableView registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    
    identifier = @"MainDetailTableViewCell";
    [_tableView registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    self.tableView.scrollEnabled = false;
    
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    self.cellHeight = vc.cellHeight;
    
    CGFloat height = _constraint_TopHeight.constant + 2*_cellHeight + 2;
    
    self.contraintTableHeight.constant = 2 * _cellHeight;
    
//    self.contraintTitleTop.constant = (self.frame.size.height - height) / 2;
    
//    // Create blur effect
//    UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleRegular];
//
//    // Add effect to an effect view
//    UIVisualEffectView *visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
//    visualEffectView.frame = self.frame;
//
////    self.viewBackground = blurEffectView;
//    [self.viewBackground addSubview:visualEffectView];
    
//    self.tableView.frame = CGRectMake(self.tableView.frame.origin.x, self.tableView.frame.origin.y, viewRootRect.size.width, 2*_cellHeight);
    self.frame = CGRectMake(0, 0, viewRootRect.size.width, height);
    
    [self setMyStyle:self.frame];
}

-(void)gestureSwipeUp:(UISwipeGestureRecognizer*)gesture{
    int focus = -1;
    for (int i=0; i<self.vc.listData.count; i++) {
        TblInvitee* invitee =  self.vc.listData[i];
        if([invitee.custid isEqualToString:self.targetId]){
            focus = i;
            break;
        }
    }
    if (focus <= 0) {
        return;
    }
    TblInvitee* invitee =  self.vc.listData[focus - 1];
    NSString * newTargetID = invitee.custid;
    
    [self setData:CGRectZero Vc:self.vc TargetId:newTargetID];
    [self.tableView reloadData];
}

-(void)gestureSwipeDown:(UISwipeGestureRecognizer*)gesture{
    int focus = -1;
    for (int i=0; i<self.vc.listData.count; i++) {
        TblInvitee* invitee =  self.vc.listData[i];
        if([invitee.custid isEqualToString:self.targetId]){
            focus = i;
            break;
        }
    }
    if (focus >= self.vc.listData.count - 1) {
        return;
    }
    TblInvitee* invitee =  self.vc.listData[focus + 1];
    NSString * newTargetID = invitee.custid;
    
    [self setData:CGRectZero Vc:self.vc TargetId:newTargetID];
    [self.tableView reloadData];
}

-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    [self.vc gestureSwipeLeft:gesture];
//    if (_can_goright) {
//        [self moveRight];
//    }
}

// handle swipe right gesture
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture{
    [self.vc gestureSwipeRight:gesture];
//    if (_can_goleft) {
//        [self moveLeft];
//    }
}

-(void)moveLeft{
    curDate = [curDate dateByAddingTimeInterval:-24*60*60];
    [self.vc updateData];
    [self.tableView slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
//    [self.tableView reloadData];
}
// set day to next days and update
-(void)moveRight{
    curDate = [curDate dateByAddingTimeInterval:24*60*60];
    [self.vc updateData];
    [self.tableView slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
//    [self.tableView reloadData];
}

-(BOOL)setData:(CGRect)viewRootRect Vc:(ChallengeDetailViewController*)vc TargetId:(NSString*)targetid{
    self.vc = vc;
    //self.listData = vc.listData;
    self.challengeInfo = vc.challengeInfo;
    self.challengeType = vc.challengeType;
    self.my_data = vc.my_data;
    self.winnerinfo = vc.winnerinfo;
    self.cellHeight = vc.cellHeight;
    self.targetId = targetid;
    self.group_data = vc.group_data;
    
    self.can_goleft = vc.can_goleft;
    self.can_goright = vc.can_goright;
    
    self.listData = [[NSMutableArray alloc] init];
    
    EnvVar* env = [CGlobal sharedId].env;
    _lblUser1.text = env.screen;
    
    for (int i=0; i<vc.listData; i++) {
        TblInvitee* invitee =  vc.listData[i];
        if([invitee.custid isEqualToString:targetid]){
            [self.listData addObject:invitee];
            
            if (invitee.fname == nil || [invitee.fname isEqualToString:@""]) {
                _lblUser2.text = invitee.email_address;
            }else{
                _lblUser2.text = invitee.fname;
            }
//            thisId = invitee.custid;
            
            break;
        }
    }
    if (self.listData.count == 0) {
        return FALSE;
    }
    
    if (_challengeType == 0) {
//        self.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
        self.tableView.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
        self.viewHeader.backgroundColor = APP_COLOR_PRIMARY;
    }else{
//        self.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
        self.tableView.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
        self.viewHeader.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
    }
    
    UIImage* image = [CGlobal localUserImage:targetid];
    if (image!=nil) {
        _img_user2.image = image;
    }else{
        _img_user2.image = [UIImage imageNamed:@"user_avatar.png"];
        [CGlobal getUserImage:targetid Callback:^(UIImage *ret) {
            if (ret!=nil) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    _img_user2.image = ret;
                });
            }
        }];
    }
    
    image = [CGlobal localUserImage:env.custId];
    if (image!=nil) {
        _img_user1.image = image;
    }else{
        _img_user1.image = [UIImage imageNamed:@"user_avatar.png"];
        [CGlobal getUserImage:targetid Callback:^(UIImage *ret) {
            if (ret!=nil) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    _img_user1.image = ret;
                });
            }
        }];
    }
    
    return true;
}
- (IBAction)tapClose:(id)sender {
//    if ([self.xo isKindOfClass:[MyPopupDialog class]]) {
//        MyPopupDialog* dialog = (MyPopupDialog*)self.xo;
//        [dialog dismissPopup];
//    }
    [self removeFromSuperview];
    [self.vc.viewMaskBackground setHidden:YES];
    [self.vc.viewMaskBackground_Head setHidden:YES];
    [self.vc.viewTemp setHidden:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    
    return _listData.count + 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _cellHeight;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_challengeType == 0) {
        MainDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainDetailTableViewCell"];
        EnvVar* env = [CGlobal sharedId].env;
        long row = indexPath.row;
        TblHealthData*info;
        TblInvitee* invitee = nil;
        if (row == 0) {
            cell.viewLineTop1.hidden = true;
            info = _my_data;
        }else{
            cell.viewLineTop1.hidden = false;
            invitee = _listData[row-1];
            if ([invitee.status isEqualToString:@"0"]) {
                info  = [[TblHealthData alloc] initNull:invitee.custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
            }else{
                info = [_group_data objectForKey:invitee.custid];
            }
            
        }
        [cell setData:info Invitee:invitee Challenge:_challengeInfo WinnerInfo:_winnerinfo];
//        cell.aDelegate = self;
        
        cell.backgroundColor = self.backgroundColor;
        return cell;
    }else{
        MainDetailAimTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainDetailAimTableViewCell"];
        EnvVar* env = [CGlobal sharedId].env;
        long row = indexPath.row;
        TblHealthData*info,*aimInfo;
        TblInvitee* invitee = nil;
        if (row == 0) {
            info = _my_data;
            cell.viewLineTop1.hidden = true;
        }else{
            cell.viewLineTop1.hidden = false;
            invitee = _listData[row-1];
            if ([invitee.status isEqualToString:@"0"]) {
                info  = [[TblHealthData alloc] initNull:invitee.custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
            }else{
                info = [_group_data objectForKey:invitee.custid];
            }
        }
        
        [cell setData:info Invitee:invitee Challenge:_challengeInfo WinnerInfo:_winnerinfo];
//        cell.aDelegate = self;
        cell.backgroundColor = self.backgroundColor;
        return cell;
    }
}
@end
