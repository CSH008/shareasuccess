//
//  HelpDialog.m
//  ShareASuccess
//
//  Created by BoHuang on 9/5/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "HelpDialog.h"
#import "HelpViewC1.h"
#import "HelpViewC2.h"
#import "HelpViewC3.h"
#import "HelpViewC4.h"
#import "HelpViewC5.h"
#import "HelpViewC6.h"

#import "CGlobal.h"
#import "UIView+Animation.h"
#import "UIView+Property.h"
#import "HelpRootView.h"
#import "MyPopupDialog.h"


@interface HelpDialog ()

@property (assign,nonatomic) int curTag;

@property (assign,nonatomic) long curpage;
@property (assign,nonatomic) CGPoint lastOffset;
@property (assign,nonatomic) CGRect scrollViewRect;

@property (strong,nonatomic) NSArray* helpViews;
@property (strong,nonatomic) NSArray* helpViews_C;
//@property (strong,nonatomic) HelpIndicator* helpIndicator;
@end
@implementation HelpDialog

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
- (IBAction)tapClose:(id)sender {
//    if (self.aDelegate!=nil) {
//        [self.aDelegate didSubmit:@{@"action":@"close"} View:self];
//    }
    if ([self.xo isKindOfClass:[MyPopupDialog class]]) {
        MyPopupDialog* dialog = (MyPopupDialog*)self.xo;
        [dialog dismissPopup];
    }
}
-(void)setMyStyle:(CGRect)viewRootRect{
    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:viewRootRect];
    self.layer.masksToBounds = NO;
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOffset = CGSizeMake(0.0f, 5.0f);
    self.layer.shadowOpacity = 0.5f;
    self.layer.shadowPath = shadowPath.CGPath;
}
-(void)firstProcess:(CGRect)viewRootRect{
    
    [self setMyStyle:viewRootRect];
    self.backgroundColor = APP_COLOR_PRIMARY;
    _scrollViewRect = viewRootRect;
    
    
    NSArray* customViews2= [[NSBundle mainBundle] loadNibNamed:@"HelpRootView" owner:self options:nil];
    HelpRootView* view6_1_a = (HelpRootView*)customViews2[0];
    
    CGFloat width = viewRootRect.size.width;
    CGFloat height = viewRootRect.size.height;
    
    self.scrollView.delegate = self;
    
    NSArray* customViews;
    customViews = [[NSBundle mainBundle] loadNibNamed:@"HelpViewC" owner:self options:nil];
    
    HelpViewC2*view2c = (HelpViewC2*)customViews[1]; [view2c firstProcess];
    HelpViewC3*view3c = (HelpViewC3*)customViews[2]; [view3c firstProcess];
    HelpViewC4*view4c = (HelpViewC4*)customViews[3]; [view4c firstProcess];
    HelpViewC5*view5c = (HelpViewC5*)customViews[4]; [view5c firstProcess];
    HelpViewC6*view6c = (HelpViewC6*)customViews[5];
    [view6c firstProcess];
    //    HelpRootView* view6c = (HelpRootView*)customViews2[0]; [view6c firstProcess];
    
    //customViews2= [[NSBundle mainBundle] loadNibNamed:@"HelpRootView" owner:self options:nil];
    //HelpRootView* view6_1_c = (HelpRootView*)customViews2[0];
    
    //customViews2= [[NSBundle mainBundle] loadNibNamed:@"HelpRootView" owner:self options:nil];
    //HelpRootView* view6_2_c = (HelpRootView*)customViews2[0];
    
    _helpViews_C = [[NSArray alloc] initWithObjects:view6_1_a, view2c,view6c, view3c,view4c,view5c,nil];
    NSArray* views = _helpViews_C;
    
    for (int i=0; i<views.count; i++) {
        UIView* view = views[i];
        [self.scrollView addSubview:view];
        view.frame = CGRectMake(width*i,0, width, height);
        view.backgroundColor = APP_COLOR_PRIMARY;
    }
    self.scrollView.showsHorizontalScrollIndicator = false;
    self.scrollView.showsVerticalScrollIndicator = false;
    self.scrollView.pagingEnabled = true;
    //self.scrollView.contentSize = CGSizeMake(width*views.count, height);
    
    self.scrollView.delegate = self;
    self.scrollView.contentSize = CGSizeMake(width*3, height);
    
    //_curTag = 302;
    _curTag = 302;
    // aim 301
    // ch  302
    _curpage = 0;
    NSArray* view_list = @[view5c,view6_1_a,view2c];
    for (int i=0; i<view_list.count; i++) {
        UIView* view = view_list[i];
        view.frame = CGRectMake(width*i,0, width, height);
        [self.scrollView bringSubviewToFront:view];
    }
    [self.scrollView setContentOffset:CGPointMake(width*1, 0) animated:false];
    
    [view6_1_a.btnAim addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    [view6_1_a.btnChallenge addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    view6_1_a.btnAim.tag = 301;
    view6_1_a.btnChallenge.tag = 302;
}

-(void)constructScrollView:(UIScrollView*)scrollView CurIndex:(int)pageIndex{
    NSArray* views = nil;
    if (_curTag == 301) {
        views = _helpViews;
    }else{
        views = _helpViews_C;
    }
    
    int pindex = _curpage;
    if (pageIndex==2) {
        // plus
        pindex = (pindex + 1)%views.count;
    }else if(pageIndex == 0){
        pindex = ( pindex - 1 + views.count ) % views.count;
    }else{
        return;
    }
    scrollView.scrollEnabled = false;
    
    
    _curpage = pindex;
    
    int prevIndex =( pindex - 1 + views.count ) % views.count;
    int nextIndex =(pindex + 1)%views.count;
    
    CGFloat width = self.scrollViewRect.size.width;
    CGFloat height = self.scrollViewRect.size.height;
    
    NSArray* view_list = @[views[prevIndex],views[pindex],views[nextIndex]];
    for (int i=0; i<view_list.count; i++) {
        UIView* view = view_list[i];
        view.frame = CGRectMake(width*i,0, width, height);
        [self.scrollView bringSubviewToFront:view];
    }
    
    [scrollView setContentOffset:CGPointMake(width*1, 0) animated:false];
    dispatch_async(dispatch_get_main_queue(), ^{
        scrollView.scrollEnabled = true;
    });
    
}
-(NSInteger)pageIndex:(UIScrollView*)scrollView{
    CGPoint offset = scrollView.contentOffset;
    
    CGFloat width = self.scrollViewRect.size.width;
    NSInteger pageIndex = offset.x/width;
    
    return pageIndex;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    
//    NSArray* views = nil;
//    if (_curTag == 301) {
//        views = _helpViews;
//    }else{
//        views = _helpViews_C;
//    }
//    NSInteger pageIndex = [self pageIndex:scrollView];
//
//    if (pageIndex>=0 && pageIndex < views.count) {
//        //_pageIndicator.currentPage = pageIndex;
//        //[self constructScrollView:scrollView CurIndex:pageIndex];
//
//        //NSLog(@"scrollViewDidScroll inside %d",pageIndex);
//    }
    //NSLog(@"scrollViewDidScroll %d",pageIndex);
//    if (_pageIndicator.currentPage == 2) {
//        _btnStart.hidden = false;
//    }
    
//    BOOL readyLeft
//    if (_curTag == 301) {
//        // aim
//        if (pageIndex == _helpViews.count - 1) {
//            // last page
//
//        }
//    }else if(_curTag == 302){
//        //challenge
//    }
}
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    NSInteger pageIndex = [self pageIndex:scrollView];
    NSLog(@"AAAAAAAAAAAAAAAAAAAA %d",pageIndex);
    
    NSArray* views = nil;
    if (_curTag == 301) {
        views = _helpViews;
    }else{
        views = _helpViews_C;
    }
    
    if (pageIndex>=0 && pageIndex < views.count) {
        [self constructScrollView:scrollView CurIndex:pageIndex];
    }
    
    
}
-(void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    NSInteger pageIndex = [self pageIndex:scrollView];
    NSLog(@"BBBBBBBBBBBBBBB %d %@",pageIndex,decelerate?@"willDecelerate true":@"willDecelerate false");
}

-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    _curpage = ( _curpage - 1 + _helpViews.count ) % _helpViews.count;
    long snappage = _curpage;
    [_viewRoot slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *view in _helpViews) {
            view.hidden = true;
        }
        for (UIView *view in _helpViews_C) {
            view.hidden = true;
        }
        UIView*view = _helpViews[snappage];
        if (_curTag == 301) {
            view = _helpViews[snappage];
        }else{
            view = _helpViews_C[snappage];
        }
        view.hidden = false;
    });
}
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture{
    _curpage = (_curpage + 1)%_helpViews.count;
    long snappage = _curpage;
    [_viewRoot slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *view in _helpViews) {
            view.hidden = true;
        }
        for (UIView *view in _helpViews_C) {
            view.hidden = true;
        }
        UIView*view = _helpViews[snappage];
        if (_curTag == 301) {
            view = _helpViews[snappage];
        }else{
            view = _helpViews_C[snappage];
        }
        view.hidden = false;
    });
}

-(void)ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    switch (tag) {
        case 999:
        {
            //            [self.navigationController popViewControllerAnimated:true];
            [self.vc.navigationController popToRootViewControllerAnimated:true];
            break;
        }
        case 101:{
            [self gestureSwipeRight:nil];
            break;
        }
        case 301:
        {
            // aim
            _curTag = tag;
            //[self gestureSwipeRight:nil];
            CGFloat width = self.scrollViewRect.size.width;
            CGFloat height = self.scrollViewRect.size.height;
            NSArray* view_list = @[_helpViews[_helpViews.count-1],_helpViews[0],_helpViews[1]];
            for (int i=0; i<view_list.count; i++) {
                UIView* view = view_list[i];
                view.frame = CGRectMake(width*i,0, width, height);
                [self.scrollView bringSubviewToFront:view];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.scrollView setContentOffset:CGPointMake(_scrollViewRect.size.width*2, 0) animated:true];
            });
            
            break;
        }
        case 302:
        {
            //challenge
            _curTag = tag;
            //[self gestureSwipeRight:nil];
            
            CGFloat width = self.scrollViewRect.size.width;
            CGFloat height = self.scrollViewRect.size.height;
            NSArray* view_list = @[_helpViews_C[_helpViews_C.count-1],_helpViews_C[0],_helpViews_C[1]];
            for (int i=0; i<view_list.count; i++) {
                UIView* view = view_list[i];
                view.frame = CGRectMake(width*i,0, width, height);
                [self.scrollView bringSubviewToFront:view];
            }
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.scrollView setContentOffset:CGPointMake(_scrollViewRect.size.width*2, 0) animated:true];
            });
            
            break;
        }
        default:
            break;
    }
}
@end
