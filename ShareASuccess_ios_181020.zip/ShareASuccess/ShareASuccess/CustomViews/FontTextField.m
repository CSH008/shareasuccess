//
//  FontTextField.m
//  ShareASuccess
//
//  Created by BoHuang on 9/7/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "FontTextField.h"
#import "CGlobal.h"
@implementation FontTextField

-(void)setAbcBold:(CGFloat)abcBold{
    if (abcBold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_bold.fontName size:abcBold];
        self.font = font;
    }
    _abcBold = abcBold;
}

-(void)setAbcSemibold:(CGFloat)abcSemibold{
    if (abcSemibold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_semibold.fontName size:abcSemibold];
        self.font = font;
    }
    _abcSemibold = abcSemibold;
}

-(void)setAbcLightItalic:(CGFloat)abcLightItalic{
    if (abcLightItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_lightitalic.fontName size:abcLightItalic];
        self.font = font;
    }
    _abcLightItalic = abcLightItalic;
}
#pragma -mark secondly added font
-(void)setAbcLight:(CGFloat)abcLight{
    if (abcLight>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_light.fontName size:abcLight];
        self.font = font;
    }
    _abcLight = abcLight;
}
-(void)setAbcMedium:(CGFloat)abcMedium{
    if (abcMedium>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_medium.fontName size:abcMedium];
        self.font = font;
    }
    _abcMedium = abcMedium;
}
-(void)setAbcRegular:(CGFloat)abcRegular{
    if (abcRegular>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regular.fontName size:abcRegular];
        self.font = font;
    }
    _abcRegular = abcRegular;
}
-(void)setAbcRegularItalic:(CGFloat)abcRegularItalic{
    if (abcRegularItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regularitalic.fontName size:abcRegularItalic];
        self.font = font;
    }
    _abcRegularItalic = abcRegularItalic;
}


-(void)setThemeMode:(int)themeMode{
    switch (themeMode) {
        case 1:
            // top title -- bold white
            //self.font = defaultFont_Headline_Bold;
            self.abcRegular = 14;
            [self setColorMode:0];
            [self setBackMode:0];
            [self setPlaceholderMode:0];
            break;
        default:
            break;
    }
}
-(void)setPlaceholderMode:(int)placeholderMode{
    switch (placeholderMode) {
        case 1:
            
            break;
            
        default:
            if ([self respondsToSelector:@selector(setAttributedPlaceholder:)])
            {
                self.attributedPlaceholder = [[NSAttributedString alloc] initWithString:self.placeholder attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
            }
            break;
    }
    _placeholderMode = placeholderMode;
}
-(void)setBackMode:(int)backMode{
    switch (backMode) {
        case 1:
            
            break;
            
        default:
            self.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
            break;
    }
    _backMode = backMode;
}
-(void)setColorMode:(int)colorMode{
    switch (colorMode) {
        case 1:
            
            break;
            
        default:
            self.textColor = [UIColor whiteColor];
            break;
    }
    _colorMode = colorMode;
}
@end
