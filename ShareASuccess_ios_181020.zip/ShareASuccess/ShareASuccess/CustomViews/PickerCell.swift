//
//  PickerCell.swift
//  ShareASuccess
//
//  Created by BoHuang on 2/17/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

import UIKit

class PickerCell: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBOutlet weak var viewTopBorder: UIView!
    @IBOutlet weak var viewBottomBorder: UIView!
    @IBOutlet weak var lblContent: UILabel!

    func setData(data:String){
        lblContent.text = data
        lblContent.isHidden = false
        viewTopBorder.isHidden = true
        viewBottomBorder.isHidden = true
    }
}
