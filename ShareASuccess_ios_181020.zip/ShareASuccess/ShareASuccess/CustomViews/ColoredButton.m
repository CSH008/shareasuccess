//
//  ColoredButton.m
//  ShareASuccess
//
//  Created by BoHuang on 9/6/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "ColoredButton.h"
#import "CGlobal.h"

@implementation ColoredButton
-(void)setAbcBold:(CGFloat)abcBold{
    if (abcBold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_bold.fontName size:abcBold];
        self.titleLabel.font = font;
    }
    _abcBold = abcBold;
}

-(void)setAbcSemibold:(CGFloat)abcSemibold{
    if (abcSemibold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_semibold.fontName size:abcSemibold];
        self.titleLabel.font = font;
    }
    _abcSemibold = abcSemibold;
}

-(void)setAbcLightItalic:(CGFloat)abcLightItalic{
    if (abcLightItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_lightitalic.fontName size:abcLightItalic];
        self.titleLabel.font = font;
    }
    _abcLightItalic = abcLightItalic;
}
#pragma -mark secondly added font
-(void)setAbcLight:(CGFloat)abcLight{
    if (abcLight>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_light.fontName size:abcLight];
        self.titleLabel.font = font;
    }
    _abcLight = abcLight;
}
-(void)setAbcMedium:(CGFloat)abcMedium{
    if (abcMedium>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_medium.fontName size:abcMedium];
        self.titleLabel.font = font;
    }
    _abcMedium = abcMedium;
}
-(void)setAbcRegular:(CGFloat)abcRegular{
    if (abcRegular>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regular.fontName size:abcRegular];
        self.titleLabel.font = font;
    }
    _abcRegular = abcRegular;
}
-(void)setAbcRegularItalic:(CGFloat)abcRegularItalic{
    if (abcRegularItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regularitalic.fontName size:abcRegularItalic];
        self.titleLabel.font = font;
    }
    _abcRegularItalic = abcRegularItalic;
}

-(void)setBackColorMode:(int)backColorMode{
    switch (backColorMode) {
        case 1:
            [self setBackgroundColor:APP_COLOR_PRIMARY_SECONDARY];
            break;
            
        default:
            [self setBackgroundColor:APP_COLOR_BUTTON_PRIMARY];
            break;
    }
    _backColorMode = backColorMode;
}

-(void)setTextColorMode:(int)textColorMode{
    switch (textColorMode) {
        case 1:
            
            break;
            
        default:
            [self setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
            break;
    }
    _textColorMode = textColorMode;
}
-(void)setThemeMode:(int)themeMode{
    switch (themeMode) {
        case 1:
            // new button on main page
            self.textColorMode = 0;
            self.backColorMode = 0;
            self.abcSemibold = 15;
            break;
        case 2:
            // plus button on add challenge page
            self.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
            self.layer.cornerRadius = 4;
            self.layer.masksToBounds = true;
            [self setTextColorMode:0];
            self.abcBold = 24;
            break;
        case 3:
            // challenge button on main page
            self.textColorMode = 0;
            self.backColorMode = 1;
            self.abcBold = 15;
            break;
        case 4:
            // aim button on main page
            self.textColorMode = 0;
            self.backColorMode = 0;
            self.abcBold = 15;
            break;
        default:
            
            break;
    }
    _themeMode = themeMode;
}
@end
