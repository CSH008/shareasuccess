//
//  SymbolImageView.m
//  ShareASuccess
//
//  Created by BoHuang on 9/1/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "SymbolImageView.h"

@implementation SymbolImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setBorerWidth:(CGFloat)borerWidth{
    if (borerWidth>0) {
        self.layer.borderWidth = borerWidth;
        
    }
}
-(void)setCornerRadius:(CGFloat)cornerRadius{
    if (cornerRadius>0) {
        self.layer.cornerRadius = cornerRadius;
        self.layer.masksToBounds = true;
    }
    _cornerRadius = cornerRadius;
}
-(void)setBackMode:(int)backMode{
    switch (backMode) {
        case 1:
            //self.layer.borderWidth = 2;
            self.layer.borderColor = [UIColor whiteColor].CGColor;
            break;
            
        default:
            break;
    }
    _backMode = backMode;
}


@end
