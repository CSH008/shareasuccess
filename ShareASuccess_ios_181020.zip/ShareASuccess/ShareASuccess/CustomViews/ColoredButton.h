//
//  ColoredButton.h
//  ShareASuccess
//
//  Created by BoHuang on 9/6/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ColoredButton : UIButton

@property (nonatomic) IBInspectable CGFloat abcBold;
@property (nonatomic) IBInspectable CGFloat abcLightItalic;
@property (nonatomic) IBInspectable CGFloat abcSemibold;
@property (nonatomic) IBInspectable CGFloat abcLight;
@property (nonatomic) IBInspectable CGFloat abcMedium;
@property (nonatomic) IBInspectable CGFloat abcRegular;
@property (nonatomic) IBInspectable CGFloat abcRegularItalic;

@property (nonatomic) IBInspectable int textColorMode;
@property (nonatomic) IBInspectable int backColorMode;

@property (nonatomic) IBInspectable int themeMode;
@end
