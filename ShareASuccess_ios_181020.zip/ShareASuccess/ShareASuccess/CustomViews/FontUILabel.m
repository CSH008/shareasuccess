//
//  FontUILabel.m
//  ShareASuccess
//
//  Created by BoHuang on 9/5/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "FontUILabel.h"
#import "CGlobal.h"
@implementation FontUILabel

-(void)setAbcBold:(CGFloat)abcBold{
    if (abcBold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_bold.fontName size:abcBold];
        self.font = font;
    }
    _abcBold = abcBold;
}

-(void)setAbcSemibold:(CGFloat)abcSemibold{
    if (abcSemibold>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_semibold.fontName size:abcSemibold];
        self.font = font;
    }
    _abcSemibold = abcSemibold;
}

-(void)setAbcLightItalic:(CGFloat)abcLightItalic{
    if (abcLightItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_lightitalic.fontName size:abcLightItalic];
        self.font = font;
    }
    _abcLightItalic = abcLightItalic;
}
#pragma -mark secondly added font
-(void)setAbcLight:(CGFloat)abcLight{
    if (abcLight>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_light.fontName size:abcLight];
        self.font = font;
    }
    _abcLight = abcLight;
}
-(void)setAbcMedium:(CGFloat)abcMedium{
    if (abcMedium>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_medium.fontName size:abcMedium];
        self.font = font;
    }
    _abcMedium = abcMedium;
}
-(void)setAbcRegular:(CGFloat)abcRegular{
    if (abcRegular>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regular.fontName size:abcRegular];
        self.font = font;
    }
    _abcRegular = abcRegular;
}
-(void)setAbcRegularItalic:(CGFloat)abcRegularItalic{
    if (abcRegularItalic>0) {
        UIFont* font = [UIFont fontWithName:abcAlena_regularitalic.fontName size:abcRegularItalic];
        self.font = font;
    }
    _abcRegularItalic = abcRegularItalic;
}
-(void)setThemeMode:(int)themeMode{
    switch (themeMode) {
        case 1:
            // title on help page
            // general title on overall pages.
            self.font = defaultFont_Headline_Bold;
            [self setColorMode:0];
            break;
        case 2:
            // label on help page,  lightitalic
            [self setAbcLightItalic:14];
            [self setColorMode:0];
            break;
        case 3:
            // chat username on detail page
            [self setAbcBold:14];
            [self setColorMode:0];
            break;
        case 4:
            // chat datetime on detail page
            [self setAbcSemibold:14];
            [self setColorMode:0];
            break;
        case 5:
            // chat cell text on detail page
            [self setAbcRegular:14];
            [self setColorMode:0];
            break;
        case 6:
            // label on profile page
            [self setAbcLightItalic:15];
            [self setColorMode:0];
            break;
        case 7:
            // exe labels on add challenge page
            [self setAbcRegular:15];
            [self setColorMode:0];
        case 8:
            // top date label on detail page
            [self setAbcRegular:15];
            [self setColorMode:0];
        default:
            break;
    }
}
-(void)setColorMode:(int)colorMode{
    switch (colorMode) {
        case 1:
            
            break;
            
        default:
            self.textColor = [UIColor whiteColor];
            break;
    }
    _colorMode = colorMode;
}

@end
