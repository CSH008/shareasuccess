//
//  SymbolImageView.h
//  ShareASuccess
//
//  Created by BoHuang on 9/1/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SymbolImageView : UIImageView

@property (nonatomic) IBInspectable CGFloat cornerRadius;
@property (nonatomic) IBInspectable CGFloat borerWidth;
@property (nonatomic) IBInspectable int backMode;

@end
