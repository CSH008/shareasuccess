//
//  InviteDialog.m
//  Fit
//
//  Created by Twinklestar on 10/12/16.
//
//

#import "InviteDialog.h"
#import "TblInvitee.h"

#import "CGlobal.h"

@implementation InviteDialog

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)initProc {
    [super awakeFromNib];
    // Initialization code
//    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    _font1 = [UIFont boldSystemFontOfSize:15];
    [_labelName setFont:_font1];
    [_labelTitle setFont:_font1];
    
    _font2 = [UIFont systemFontOfSize:15];
    [_labelDesc setFont:_font2];
    
    CGRect screenRect = [UIScreen mainScreen].bounds;
    _labelwidth1 = screenRect.size.width - 40;
    
    [CGlobal makeStyle1:_btn_accept Mode:0];
    [CGlobal makeStyle1:_btn_reject Mode:0];
    
    _btn_reject.backgroundColor = APP_COLOR_DOT_RED;
    
    _labelName.textColor = [CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f];
    _labelDesc.textColor = [CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f];
    _labelTitle.textColor = [CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f];
}

-(void)setData:(TblInviteInfoData*)inviteinfo{
    
    _inviteData = inviteinfo;
    int total = 0;
    //    if (inviteinfo.total!=nil) {
    //        total = [inviteinfo.total intValue] -1;
    //    }
    total = inviteinfo.total - 1;
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Pending invites (%d)" value:@"" table:nil];
    NSString *title = [NSString stringWithFormat:temp,total];
    _labelTitle.text = title;
    _labelName.text = inviteinfo.challenge_name;
    _labelDesc.text = inviteinfo.challenge_description;
    
    CGFloat height = [self heightForData:inviteinfo];
    _constraint_height.constant = height;
    
    [_view_root setNeedsLayout];
    [_view_root layoutIfNeeded];
    
    if ([self superview] == nil) {
        _constraint_space_tobottom.constant = -height;
    }else{
        
    }
    
}
-(CGFloat) heightForData:(TblInviteInfoData *)inviteinfo{
    int total = 0;
    //    if (inviteinfo.total!=nil) {
    //        total = [inviteinfo.total intValue] -1;
    //    }
    
    total = inviteinfo.total -1;
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Pending invites (%d)" value:@"" table:nil];
    NSString *title = [NSString stringWithFormat:temp,total];
    
    CGFloat height1 = [CGlobal heightForView:title Font:_font1 Width:_labelwidth1];
    CGFloat height2 = [CGlobal heightForView:inviteinfo.challenge_name Font:_font1 Width:_labelwidth1];
    CGFloat height3 = [CGlobal heightForView:inviteinfo.challenge_description Font:_font2 Width:_labelwidth1];
    CGFloat height = 20 + 28;  // 20 is top space
    
    height = height + height1 + height2+ height3+120;
    return height;
}
@end
