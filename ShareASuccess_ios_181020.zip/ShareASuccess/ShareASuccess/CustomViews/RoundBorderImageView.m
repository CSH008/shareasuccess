//
//  RoundBorderImageView.m
//  ShareASuccess
//
//  Created by Twinklestar on 3/28/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import "RoundBorderImageView.h"

@implementation RoundBorderImageView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)setCornerRadius:(CGFloat)cornerRadius{
    if (cornerRadius>0) {
        self.layer.cornerRadius = cornerRadius;
        self.layer.masksToBounds = true;
    }
    _cornerRadius = cornerRadius;
}
-(void)setBackMode:(int)backMode{
    switch (backMode) {
        case 1:
            self.layer.borderColor = [UIColor whiteColor].CGColor;
            self.layer.borderWidth = 1;
            self.layer.masksToBounds = true;
            break;
            
        default:
            break;
    }
    _backMode = backMode;
}

@end
