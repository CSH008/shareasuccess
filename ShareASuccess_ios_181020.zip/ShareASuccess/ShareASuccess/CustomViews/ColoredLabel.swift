//
//  ColoredLabel.swift
//  ShareASuccess
//
//  Created by BoHuang on 2/22/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

import UIKit

class ColoredLabel: UILabel {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBInspectable var colorMode: Int = -1 {
        didSet {
            switch colorMode {
            case 9:
                // help bingo
                self.textColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                self.font = defaultFont_Headline_Bold
                break
            case 8:
                self.textColor = CGlobal.color(withHexString: "6d6f72", alpha: 1.0)
                
                self.font = defaultFont_Headline_Bold
                break;
            case 7:
                self.textColor = APP_COLOR_DOT_RED
                break
            case 6:
                self.textColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                break;
            case 5:
                self.textColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                let font = UIFont.boldSystemFont(ofSize: 15)
                self.font = font
                break
            case 4:
                self.textColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                let font = UIFont.boldSystemFont(ofSize: 13)
                self.font = font
                break
            case 3:
                self.textColor = APP_COLOR_DOT_RED
                let font = UIFont.boldSystemFont(ofSize: 13)
                self.font = font
                break
            case 2:
                // red
                self.textColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                self.font = defaultFont_Headline_Bold
            case 1:
                // gray
                self.textColor = CGlobal.color(withHexString: "6d6f72", alpha: 1.0)
                let font = UIFont.systemFont(ofSize: 12)
                self.font = font
            case 0:
                // blue tone
                self.textColor = CGlobal.color(withHexString: "7F7F82", alpha: 1.0)
                
            default:
                break;
                
            }
        }
    }
}
