//
//  FontTextField.h
//  ShareASuccess
//
//  Created by BoHuang on 9/7/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FontTextField : UITextField
@property (nonatomic) IBInspectable CGFloat abcBold;
@property (nonatomic) IBInspectable CGFloat abcLightItalic;
@property (nonatomic) IBInspectable CGFloat abcSemibold;
@property (nonatomic) IBInspectable CGFloat abcLight;
@property (nonatomic) IBInspectable CGFloat abcMedium;
@property (nonatomic) IBInspectable CGFloat abcRegular;
@property (nonatomic) IBInspectable CGFloat abcRegularItalic;

@property (nonatomic) IBInspectable int placeholderMode;
@property (nonatomic) IBInspectable int colorMode;
@property (nonatomic) IBInspectable int backMode;
@property (nonatomic) IBInspectable int themeMode;
@end
