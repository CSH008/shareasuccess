//
//  RefreshContent.h
//  Fit
//
//  Created by Twinklestar on 7/25/16.
//
//

#import <UIKit/UIKit.h>

@interface RefreshContent : UIView

@property (nonatomic,weak) IBOutlet UILabel* labelFirst;
@property (nonatomic,weak) IBOutlet UILabel* labelSecond;
@end
