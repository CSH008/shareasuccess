//
//  RoundBorderImageView.h
//  ShareASuccess
//
//  Created by Twinklestar on 3/28/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface RoundBorderImageView : UIImageView

@property (nonatomic) IBInspectable CGFloat cornerRadius;
@property (nonatomic) IBInspectable int backMode;

@end
