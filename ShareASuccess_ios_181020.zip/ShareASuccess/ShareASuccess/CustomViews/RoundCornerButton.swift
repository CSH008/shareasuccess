import UIKit

@IBDesignable
class RoundCornerButton: UIButton {
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
//            layer.cornerRadius = cornerRadius
//            layer.masksToBounds = cornerRadius > 0
//            let maskPath = UIBezierPath.bezierPathWithRoundedRect
            var bounds = self.bounds;
            let sr = UIScreen.main.bounds
            let width = (sr.size.width - status_leading*2)/2
            let newb = CGRect.init(x:0,y:0,width:width,height:sr.size.height)
            
            let maskPath = UIBezierPath.init(roundedRect: newb, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
            let maskLayer = CAShapeLayer.init()
            maskLayer.frame = newb
            maskLayer.path = maskPath.cgPath
            self.layer.mask = maskLayer
            
            
//            UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:viewRound.bounds byRoundingCorners:(UIRectCornerTopLeft | UIRectCornerBottomLeft ) cornerRadii:CGSizeMake(10.0, 10.0)];
            
//            CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
//            maskLayer.frame = view.bounds;
//            maskLayer.path  = maskPath.CGPath;
//            viewRound.layer.mask = maskLayer;
        }
    }
    
    @IBInspectable var backMode: Int = -1 {
        didSet {
            switch backMode {
                
            case 2:
                self.backgroundColor = CGlobal.color(withHexString: "ffffff", alpha: 1.0)
                
            case 1:// red
                self.backgroundColor = APP_COLOR_DOT_RED
            case 0:
                // green
                self.backgroundColor = APP_COLOR_DOT_GREEN
                
            default:
                break;
                
            }
        }
    }
    
}
