//
//  ColoredView.swift
//  ShareASuccess
//
//  Created by q on 2/10/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

import UIKit
@IBDesignable
class ColoredView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRadius
            self.layer.masksToBounds = true
        }
    }
    @IBInspectable var backMode: Int = -1 {
        didSet {
            switch backMode {
            case 9:
                // aim back on add challenge page
                self.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
                break;
            case 8:
                // challenge back on add challenge page
                self.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
                break;
            case 7:
                
                self.backgroundColor = APP_COLOR_CELL_GRAY;
            case 6:
                //
                self.backgroundColor = CGlobal.color(withHexString: "#1C8390", alpha: 1.0)
                break;
            case 5:
                
                self.backgroundColor = APP_COLOR_PRIMARY;
                
                //self.backgroundColor = CGlobal.color(withHexString: "#5C719E", alpha: 1.0)
                
                
                break;
            case 4:
                //
                self.backgroundColor = APP_COLOR_DOT_RED
                
                break
            case 3:
                self.backgroundColor = CGlobal.color(withHexString: "#791113", alpha: 1.0)
                break
            case 2:
                self.backgroundColor = APP_COLOR_DOT_GREEN
                break;
            case 1:
                self.backgroundColor = CGlobal.color(withHexString: "#62B45A", alpha: 1.0)
                break;
            case 0:
                // red
                self.backgroundColor = APP_COLOR_DOT_RED
                
            default:
                break;
                
            }
        }
    }
}
