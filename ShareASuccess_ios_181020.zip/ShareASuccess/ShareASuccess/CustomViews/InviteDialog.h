//
//  InviteDialog.h
//  Fit
//
//  Created by Twinklestar on 10/12/16.
//
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblInviteInfoData.h"
@interface InviteDialog : UIView

@property (weak, nonatomic) IBOutlet UIImageView *imageType;
@property (weak, nonatomic) IBOutlet UIImageView *imageStatus;
@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelDesc;

@property (weak, nonatomic) IBOutlet UIButton *btn_reject;
@property (weak, nonatomic) IBOutlet UIButton *btn_accept;

@property (weak, nonatomic) IBOutlet UIView *view_top1;
@property (weak, nonatomic) IBOutlet UIView *view_top2;
@property (weak, nonatomic) IBOutlet UIView *view_root;


@property (weak, nonatomic) UIFont *font1,*font2;
@property (assign, nonatomic) CGFloat labelwidth1;

@property (strong, nonatomic) TblInviteInfoData* inviteData;

-(void)setData:(TblInviteInfoData*)data;
- (void)initProc;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint* constraint_height;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint* constraint_space_tobottom;
@end
