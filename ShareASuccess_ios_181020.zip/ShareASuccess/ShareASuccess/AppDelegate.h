//
//  AppDelegate.h
//  Fit
//
//  Created by Denis on 10/7/15.
//
//

#import <UIKit/UIKit.h>
#import <HealthKit/HealthKit.h>
#import "Utils.h"
#import "AFNetworking.h"
#import "ChallengeViewController.h"
#import "DBManager.h"
#import "Reachability.h"
#import "ResponseMyInfo.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate,UIAlertViewDelegate>

@property (nonatomic , assign)BOOL isUploadInProgress;
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) CustInfo *custInfo;
@property (strong, nonatomic) HKHealthStore *healthStore;
@property (strong, nonatomic) ChallengeViewController *challengeScreen;

@property (strong, nonatomic) Reachability *reachability;
@property (strong, nonatomic) Reachability *hostReachable;

@property (strong, nonatomic) DBManager *dbManager;

@property (assign, nonatomic) BOOL recoverMode;
@property (assign, nonatomic) BOOL appIsStarting;

-(void)collectHealthData;
-(void)gotoChallengeScreen;
-(void)saveMyInfo:(ResponseMyInfo*)info;
-(void)getUserInformationFromServer;
-(void)onLogin:(NSDictionary*)dict;
-(void)showLoginScreen;
-(void)pushLocalDbToServer;
-(void)logOut;
-(void)trySyncStart;

-(void)registerDeviceUUID;
-(void)unregisterUUID;
typedef void (^PhotoDownloadingCompletionBlock)(BOOL success);

-(void)processNotification:(NSDictionary*)userInfo;
-(void)setBadgeNumber;
@property (strong,nonatomic) NSDictionary* launchData;
@property (assign,nonatomic) BOOL willShowChatWindow;

@end

