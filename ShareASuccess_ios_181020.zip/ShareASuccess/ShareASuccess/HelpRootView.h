//
//  HelpRootView.h
//  ShareASuccess
//
//  Created by BoHuang on 5/8/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpRootView : UIView
@property (weak, nonatomic) IBOutlet UIButton *btnAim;
@property (weak, nonatomic) IBOutlet UIButton *btnChallenge;
@property (weak, nonatomic) IBOutlet UILabel *lblHead;

-(void)firstProcess;
@end
