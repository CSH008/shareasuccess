//
//  HelpRootView.m
//  ShareASuccess
//
//  Created by BoHuang on 5/8/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import "HelpRootView.h"
#import "CGlobal.h"

@implementation HelpRootView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)firstProcess{
    //self.backgroundColor = APP_COLOR_DOT_RED_OLD;
//    NSString*fontname = self.lblHead.font.fontName;
//    NSLog(@"fontname %@",fontname);
//    self.lblHead.font = defaultFont_Headline_Bold;
    self.btnAim.titleLabel.font = [UIFont fontWithName:abcAlena_lightitalic.fontName size:16];
    self.btnChallenge.titleLabel.font = [UIFont fontWithName:abcAlena_lightitalic.fontName size:16];
}
@end
