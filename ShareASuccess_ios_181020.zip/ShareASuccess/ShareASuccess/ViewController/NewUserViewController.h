//
//  NewUserViewController.h
//  ShareASuccess
//
//  Created by BoHuang on 9/11/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NewUserViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupFirstName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupLastName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupScreenName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupEmail;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupReEmail;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSignupPassword;


@property (weak, nonatomic) IBOutlet UISwitch *SwitchData;
@property (weak, nonatomic) IBOutlet UISwitch *SwitchPush;
@end
