//
//  UserSetupViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "UserSetupViewController.h"
#import "CGlobal.h"
@implementation UserSetupViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = APP_COLOR_PRIMARY;
}
-(IBAction) ClickView:(UIView*)sender{
    [self.navigationController popViewControllerAnimated:true];
}
-(void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
@end
