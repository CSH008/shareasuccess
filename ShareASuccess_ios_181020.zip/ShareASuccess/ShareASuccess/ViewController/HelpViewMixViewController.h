//
//  HelpViewMixViewController.h
//  ShareASuccess
//
//  Created by BoHuang on 4/3/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpViewMixViewController : UIViewController<UIScrollViewDelegate>

@property (nonatomic,strong) UIScrollView* scrollview;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_right;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;
@property (weak, nonatomic) IBOutlet UIImageView *imgCross;

//@property (nonatomic,assign) int viewMode;

@property (nonatomic,strong) IBOutlet UIView* viewRoot;
@property (nonatomic,strong) IBOutlet UIView* viewRootSuper;

@property (nonatomic,strong) IBOutlet UIPageControl* pageControl;

@property (strong, nonatomic) UIPageViewController *pageController;

@property (strong,nonatomic) NSLayoutConstraint *constraint_viewwidth;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewheight;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewleading;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewtop;
@property (weak, nonatomic) IBOutlet UIButton *btnNext;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_bottom;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top_title;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_trailing;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;
@property (weak, nonatomic) IBOutlet UIStackView *stackNext;
@end
