//
//  ChallengeDetailViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "ChallengeDetailViewController.h"
#import "AddChallengeViewController.h"
#import "ChallengeViewController.h"
#import "ChallengeDetailCell.h"
#import "Utils.h"
#import "inc.h"
#import "CGlobal.h"
#import "TblHealthData.h"
#import "TblInvitee.h"
#import "NetworkParser.h"
#import "UIView+Animation.h"
#import "TblWinnerInfo.h"
//#import "ChallengeAimDetailTableViewCell.h"
#import "MainDetailAimTableViewCell.h"
#import "MainDetailTableViewCell.h"
#import "ShareASuccess-Swift.h"
#import "IQKeyboardManager.h"
#import "MyPopupDialog.h"
#import "ChallengeVsDialog.h"

@interface ChallengeDetailViewController()<GrowingTextViewDelegate,ViewDialogDelegate,UIScrollViewDelegate> {
    int nIndexLastView;
}

@property (nonatomic,assign) CGRect screenRect;

@property (nonatomic,assign) CGFloat historyHeight_MessageContent;
@property (nonatomic,assign) CGFloat history_FlexHeight;
@property (nonatomic,assign) CGFloat availableHeight_FlexAndMsgArea;
@property (nonatomic,assign) CGFloat expandedHeight_MsgBox;
@property (nonatomic,assign) BOOL isEditChat;
@property (nonatomic,strong) TblChat* lastChat;

@property (nonatomic,strong) SwiftCodeManager* manager;
@property (nonatomic,strong) MyPopupDialog* dialog;

@property ChatCellBaseView *lastChatView;

@end

@implementation ChallengeDetailViewController
-(void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    nIndexLastView = -1;
    
    self.viewHeadCell1.hidden = true;
    self.viewHeadCloseForKeyboardShow.hidden = true;
    [self.viewRoot bringSubviewToFront:self.viewHeadCloseForKeyboardShow];
    
    _bottomOffset_input = 70;
    _constraint_MsgContent_toBottom.constant = _bottomOffset_input;
    _isEditChat = false;
    _challengeType=0;
    _viewGreen.hidden = true;
    [_viewScrollContainer firstProcess];
    
    
    [[IQKeyboardManager sharedManager] setEnable:NO];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:NO];
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:NO];
    
    _manager = [[SwiftCodeManager alloc] init];
    _manager.vc = self;
    [_manager viewDidLoad];
    
    self.textView.delegate = self;
    
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    _lastChat = [delegate.dbManager lastChatFor:_challengeInfo];
    if(_lastChat)
        NSLog(@"last time %@",_lastChat.time_val);
    else
        NSLog(@"no latest chat");
    
    @try {
        _challengeType = [_challengeInfo.type intValue];
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
    
    NSString *identifier = @"MainDetailAimTableViewCell";
    [_tableView registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    [_tableView2 registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    
    identifier = @"MainDetailTableViewCell";
    [_tableView registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    [_tableView2 registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    
    _constraint_leading.constant =  status_leading;
    _constraint_trailing.constant = status_trailing;
    _constraint_toolbar_bottom.constant = bottom_space;
    _constraint_toolbar_top_title.constant = top_space_toolbar_title;
    _constraint_first_top.constant = 20; //top_space - statusbar_gap1;
    _constraint_first_top_for_keyboard_show.constant = 20; //top_space - statusbar_gap1;
    
    _constraint_menu_height.constant = 0; // g_menuHeight;
    
    _screenRect = [[UIScreen mainScreen] bounds];
    _tool_lbl_title2.hidden = true;
    
    [_tableView setDelegate:self];
    [_tableView setDataSource:self];
    
    [_tableView2 setDelegate:self];
    [_tableView2 setDataSource:self];
    _tableView2.scrollEnabled = false;
    
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    UIImageView* myimage1 = _imageSymbol1;
    UIImageView* myimage2 = _imageSymbol2;
    UIImageView* myimage3 = _imageSymbol3;
    UIImageView* myimage4 = _imageSymbol4;
    UIImageView* myimage5 = _imageSymbol5;
    
    NSMutableArray *myImageArray = [[NSMutableArray alloc] initWithObjects:myimage1,myimage2,myimage3,myimage4,myimage5,nil];
    NSMutableArray *myImageArray_c = [[NSMutableArray alloc] initWithObjects:_imageSymbol1_c,_imageSymbol2_c,_imageSymbol3_c,_imageSymbol4_c,_imageSymbol5_c,nil];
    
    for (int i=0; i< [myImageArray count]; i++) {
        UIImageView*imageview = [myImageArray objectAtIndex:i];
        imageview.image = nil;
        imageview.contentMode = UIViewContentModeScaleAspectFit;
        
        imageview = [myImageArray_c objectAtIndex:i];
        imageview.image = nil;
        imageview.contentMode = UIViewContentModeScaleAspectFit;
    }
    
    
    NSString* aa = [NSString stringWithFormat:@"%@ %@",_challengeInfo.challenge_name, [[NSBundle mainBundle] localizedStringForKey:@"Detail" value:@"" table:nil]];
    
    
    _lbl_headline0.text = _challengeInfo.challenge_name;
    _lbl_headline2.text = _challengeInfo.challenge_name;
    if (_challengeType == 0) {
        
        
        _toolbar_rightclose.image = [UIImage imageNamed:@"ico_close.png"];
        _imgClose.image = [UIImage imageNamed:@"icon_cross"];
        [_btnPlusChat setImage:[UIImage imageNamed:@"ico_msg_plus.png"] forState:UIControlStateNormal];
        
        NSArray* series_int = [_challengeInfo getChallengeValues];
        NSArray* series_imgname = [_challengeInfo getImageArray];
        
        NSArray* viewImgArray  = @[_viewSymbol1,_viewSymbol2,_viewSymbol3,_viewSymbol4,_viewSymbol5];
        NSArray* viewImgArray_c  = @[_viewSymbol1_c,_viewSymbol2_c,_viewSymbol3_c,_viewSymbol4_c,_viewSymbol5_c];
        for (UIView* view in viewImgArray) {
            view.hidden = true;
        }
        for (UIView* view in viewImgArray_c) {
            view.hidden = true;
        }
        
        int nCount = 0;
        for (int i=0; i<series_int.count; i++) {
            int number = [series_int[i] intValue];
            if (number == 1) {
                UIImageView* myImage = [myImageArray objectAtIndex:nCount];
                UIImageView* myImage_c = [myImageArray_c objectAtIndex:nCount];
                myImage.image = [UIImage imageNamed:series_imgname[i]];
                myImage_c.image = [UIImage imageNamed:series_imgname[i]];
                
                UIView*view = viewImgArray[nCount];
                view.hidden = false;
                
                UIView*view_c = viewImgArray_c[nCount];
                view_c.hidden = false;
                
                nCount++;
                
            }
            if (nCount == 5) {
                break;
            }
        }
        
        self.viewRoot.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
//        self.view.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
    }else{
        
        _toolbar_rightclose.image = [UIImage imageNamed:@"ico_close_2.png"];
        _imgClose.image = [UIImage imageNamed:@"icon_cross_2"];
        [_btnPlusChat setImage:[UIImage imageNamed:@"ico_msg_plus_2.png"] forState:UIControlStateNormal];
        self.viewRoot.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
        
        NSArray* series = @[_challengeInfo.aim_steps,_challengeInfo.aim_walking_running,_challengeInfo.aim_cycling_distance,_challengeInfo.aim_stand_hours,_challengeInfo.aim_flights_climbed,_challengeInfo.aim_active_energy,_challengeInfo.aim_swim];
        
        NSArray* series_float = [_challengeInfo getAimValues];
        NSArray* series_imgname = [_challengeInfo getImageArray];
        NSArray *myAimArray = [[NSMutableArray alloc] initWithObjects:_labelAim1,_labelAim2,_labelAim3,_labelAim4,_labelAim5, nil];
        NSArray *myAimArray_c = [[NSMutableArray alloc] initWithObjects:_labelAim1_c,_labelAim2_c,_labelAim3_c,_labelAim4_c,_labelAim5_c, nil];
        
        for (UILabel*label in myAimArray) {
            label.text = @"";
        }
        for (UILabel*label in myAimArray_c) {
            label.text = @"";
        }
        
        NSArray* viewDayArray  = @[_viewAim1,_viewAim2,_viewAim3,_viewAim4,_viewAim5];
        NSArray* viewDayArray_c  = @[_viewAim1_c,_viewAim2_c,_viewAim3_c,_viewAim4_c,_viewAim5_c];
        NSArray* viewImgArray  = @[_viewSymbol1,_viewSymbol2,_viewSymbol3,_viewSymbol4,_viewSymbol5];
        NSArray* viewImgArray_c  = @[_viewSymbol1_c,_viewSymbol2_c,_viewSymbol3_c,_viewSymbol4_c,_viewSymbol5_c];
        for (UIView* view in viewDayArray) {
            view.backgroundColor = [UIColor clearColor];
            view.hidden = true;
        }
        for (UIView* view in viewDayArray_c) {
            view.backgroundColor = [UIColor clearColor];
            view.hidden = true;
        }
        for (UIView* view in viewImgArray) {
            view.hidden = true;
        }
        for (UIView* view in viewImgArray_c) {
            view.hidden = true;
        }
        _viewAim.backgroundColor = [UIColor clearColor]; // [APP_COLOR_COLOREDVIEW];
        _viewAim_c.backgroundColor = [UIColor clearColor];
        
        int nCount = 0;
        for (int i=0; i<series_float.count; i++) {
            float number = [series_float[i] intValue];
            if (number > 0) {
                UIImageView* myImage =      myImageArray[nCount];
                UIImageView* myImage_c =    myImageArray_c[nCount];
                UILabel* label = myAimArray[nCount];
                UILabel* label_c = myAimArray_c[nCount];
                label.text = series[i];
                label_c.text = series[i];
                myImage.image = [UIImage imageNamed:series_imgname[i]];
                myImage_c.image = [UIImage imageNamed:series_imgname[i]];
                
                UIView* view = viewDayArray[nCount];
                //view.backgroundColor = APP_COLOR_COLOREDVIEW;
                view.hidden = false;
                
                UIView* view_c = viewDayArray_c[nCount];
                //view.backgroundColor = APP_COLOR_COLOREDVIEW;
                view_c.hidden = false;
                
                UIView* imgview = viewImgArray[nCount];
                imgview.hidden = false;
                
                UIView* imgview_c = viewImgArray_c[nCount];
                imgview_c.hidden = false;
                
                nCount++;
            }
            
            if (nCount == 5) {
                break;
            }
        }
        
        
    }
    
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Challenge detail %@" value:@"" table:nil];
    NSString* string = [NSString stringWithFormat:temp,[Utils getJsonStringFromDate:curDate]];
    _tool_lbl_title1.text = string;
    
    
    self.labelDesc.text = self.challengeInfo.challenge_description;
    
    
    [_labelDesc setFont:defaultFont];
    
    
    CGRect screenRect = [UIScreen mainScreen].bounds;
    CGFloat height_desc = [CGlobal heightForView:self.labelDesc.text Font:defaultFont Width:screenRect.size.width - 20];
    
    CGFloat height_name = 0;
    //_constraint_topviewheight.constant = height_desc + height_name + 90-29-17 + 24;     //      36  -   12
    _constraint_topviewheight.constant = 50;
    [_labelDesc setNeedsUpdateConstraints];
    [_view_top1 setNeedsUpdateConstraints];
    [_scrollView layoutIfNeeded];
    //hgc
    
    NSDateFormatter *gmtDateFormatter = [[NSDateFormatter alloc] init];
    gmtDateFormatter.timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [gmtDateFormatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"en_US_POSIX"];
    [gmtDateFormatter setLocale:locale];
    
    
    NSArray* array = [CGlobal findAllTextFieldsInView:self.view];
    for (int i=0; i< [array count]; i++) {
        UIView* view = [array objectAtIndex:i];
        [CGlobal makeStyle1:view Mode:0];
    }
    
    [_btnEdit addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    EnvVar* env = [CGlobal sharedId].env;
    if ([_challengeInfo.custId isEqualToString:env.custId]) {
        // owner
        if ([_challengeInfo.type intValue] == 0) {
            // edit challenge
            _imgEdit.image = [UIImage imageNamed:@"ico_setting.png"];
        }else{
            // edit aim
            _imgEdit.image = [UIImage imageNamed:@"ico_setting_2.png"];
        }
        _btnEdit.tag = 100;
        
        _view_editchat.hidden = false;
        
    }else{
        
        if ([_challengeInfo.type intValue] == 0) {
            // edit challenge
            _imgEdit.image = [UIImage imageNamed:@"ico_leave.png"];
        }else{
            // edit aim
            _imgEdit.image = [CGlobal getColoredImage:@"ico_leave.png" Color:APP_COLOR_PRIMARY];
        }
        
        _btnEdit.tag = 101;
        
        _view_editchat.hidden = true;
    }
    
    [_btnClose addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _btnClose.tag = 899;
    
    [self updateData];
    
    UISwipeGestureRecognizer*swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeLeft:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionLeft];
    [_scrollView addGestureRecognizer:swipe];
    
    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeRight:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [_scrollView addGestureRecognizer:swipe];
    
    [_tableView setScrollEnabled:false];
    
    _btnNextDate.hidden = true;
    _btnPrevDate.hidden = true;
    _img_next.hidden = true;
    _img_prev.hidden = true;
    
    [_btn_setting addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _btn_setting.tag = 300;
    
    [_btnToday addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _btnToday.tag = 400;
    if([CGlobal isToday:curDate isGmt:useGmt]){
        _btnToday.hidden = true;
        _imgToday.hidden = true;
    }else{
        _btnToday.hidden = false;
        _imgToday.hidden = false;
    }
    
    _btn_setting.hidden = true;
    _img_setting.hidden = true;
    
    
    [self initAimView];
    [self initStyles];
    
    [self loadMessageFromServer];
    
    self.viewChatCloseContainer.hidden = true;
    
    self.view.backgroundColor = self.viewRoot.backgroundColor;
//    self.scrollView.backgroundColor = self.viewRoot.backgroundColor;
    _view_scrollroot.backgroundColor = self.viewRoot.backgroundColor;
    _view_top2.backgroundColor = self.viewRoot.backgroundColor;
    _view_top3.backgroundColor = self.viewRoot.backgroundColor;
    _tableView.backgroundColor = self.viewRoot.backgroundColor;
    _tableView2.backgroundColor = self.viewRoot.backgroundColor;
    
    _viewHeadCell1.backgroundColor = self.viewRoot.backgroundColor; // [UIColor redColor]; //
    _msgcontent_root.backgroundColor = self.viewRoot.backgroundColor;
    _viewBack_plussign.backgroundColor = self.viewRoot.backgroundColor;
    _viewHeadCloseForKeyboardShow.backgroundColor = self.viewRoot.backgroundColor;
    
    self.scrollView.delegate = self;
}
-(void)initStyles{
    
}
-(void)initAimView{
    NSString* day = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    if (_challengeType == 0) {
        // challenging
        _constraint_aimBarHeight.constant = 0;
        _viewBar.hidden = true;
        _viewBarClone.hidden = true;
        _cellHeight = 59;
        _constraint_tableTopSpace.constant = 10;
        
        _constraint_viewHeadCell1_Height.constant = _cellHeight + 40;
        
        
    }else{
        _cellHeight = 59;
        _constraint_aimBarHeight.constant = 22;
        _constraint_viewHeadCell1_Height.constant = _cellHeight + 40 + 34;
        
        CGRect rect = [[UIScreen mainScreen] bounds];
        CGFloat fontsize;
        if (rect.size.width<=320) {
            fontsize = 11.0;
        }else{
            fontsize = 12.0;
        }
        
        NSArray* myArray = @[_labelAim1,_labelAim2,_labelAim3,_labelAim4,_labelAim5,_labelAim];
        NSArray* myArray_c = @[_labelAim1_c,_labelAim2_c,_labelAim3_c,_labelAim4_c,_labelAim5_c,_labelAim_c];
        for (int i=0; i<[myArray count]; i++) {
            UILabel* label = [myArray objectAtIndex:i];
            [label setTextColor:APP_COLOR_PRIMARY_SECONDARY];
            [label setFont:[UIFont systemFontOfSize:fontsize]];
            
            label = [myArray_c objectAtIndex:i];
            [label setTextColor:APP_COLOR_PRIMARY_SECONDARY];
            [label setFont:[UIFont systemFontOfSize:fontsize]];
        }
    }
}


// handle swipe left gesture
-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    if (_can_goright) {
        [self moveRight];
    }
}
// handle swipe right gesture
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture{
    if (_can_goleft) {
        [self moveLeft];
    }
}
// set day to previous days and update
-(void)moveLeft{
    curDate = [curDate dateByAddingTimeInterval:-24*60*60];
    [self updateData];
    [_viewNumberContainer slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    [_viewHeadCell1 slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    if ([self.view viewWithTag:401]!=nil) {
        ChallengeVsDialog* helpView = [self.view viewWithTag:401];
        [helpView.tableView slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    }
}
// set day to next days and update
-(void)moveRight{
    curDate = [curDate dateByAddingTimeInterval:24*60*60];
    [self updateData];
    [_viewNumberContainer slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    [_viewHeadCell1 slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    if ([self.view viewWithTag:401]!=nil) {
        ChallengeVsDialog* helpView = [self.view viewWithTag:401];
        [helpView.tableView slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    }
}
- (IBAction)onTapPrevDateButton:(id)sender {
    [self moveLeft];
}

- (IBAction)onTapNextDateButton:(id)sender
{
    [self moveRight];
}

-(NSInteger) daysBetweenDate:(NSDate *)firstDate andDate:(NSDate *)secondDate {
    NSCalendar *currentCalendar = [NSCalendar currentCalendar];
    NSDateComponents *components = [currentCalendar components: NSCalendarUnitDay fromDate: firstDate toDate: secondDate options: 0];
    NSInteger days = [components day];
    NSLog(@"%li",(long)days);
    return days;
}
- (IBAction)tapEditChat:(id)sender {
    // ok
    _isEditChat = !_isEditChat;
    NSMutableArray*views = self.viewScrollContainer.views;
    for (int i=0; i<views.count; i++) {
        if ([views[i] isKindOfClass:[ChatCellBaseView class]]) {
            ChatCellBaseView* view = views[i];
            [view toggleDeleteViewWithIsEditable:_isEditChat];
        }
    }
}

#pragma mark - Dialog Delegate
-(BOOL)didSubmit:(NSDictionary *)data View:(id)view{
    AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return false;
    }
    if ([view isKindOfClass:[ChatCellBaseView class]]) {
        NSString* action = data[@"action"];
        TblChat* model = data[@"data"];
        if ([action isEqualToString:@"tap_delete"]) {
            ChatCellBaseView*chatbaseview = view;
            // network
            EnvVar*env = [CGlobal sharedId].env;
            NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
            [dict setValue:@"msg_del" forKey:@"action"];
            [dict setValue:model.id forKey:@"msgid"];
            
            NetworkParser* manager = [NetworkParser sharedManager];
            NSString*serverurl = g_baseUrl;
            NSLog(@"%@",dict);
            
            //            [CGlobal showIndicatorForView:self.msgcontent_root];
            [manager generalNetwork:serverurl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
                //
                NSLog(@"%@",dict);
                if (error == nil) {
                    // update the model
                    model.deleted = @"1";
                    DBManager* dbManager = appDelegate.dbManager;
                    [dbManager insertOrUpdateChatData:model];
                    
                    chatbaseview.hidden = true;
                }
                [CGlobal stopIndicatorForView:self.msgcontent_root];
            } method:@"post"];
        }else if ([action isEqualToString:@"tap_entire"]) {
            // tap_entire
            [self toggleChatView:nil];
        }
        
        
    }else if ([view isKindOfClass:[MainDetailAimTableViewCell class]]) {
        MainDetailAimTableViewCell* cell = view;
        [self tapUserImage:cell];
    }else if ([view isKindOfClass:[MainDetailTableViewCell class]]) {
        MainDetailTableViewCell* cell = view;
        [self tapUserImage:cell];
    }
    return false;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (tableView == self.tableView2) {
        return 1;
    }
    CGFloat baseheight = 189;
    
    CGFloat tableheight = _cellHeight* (_listData.count+1);
    CGFloat viewheight = tableheight + baseheight;
    
    _constraint_tableheight.constant = tableheight;
    
    [_tableView setNeedsUpdateConstraints];
    [_view_scrollroot setNeedsUpdateConstraints];
    
    [_scrollView layoutIfNeeded];
    
    
    return _listData.count+1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return _cellHeight;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_challengeType == 0) {
        MainDetailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainDetailTableViewCell"];
        EnvVar* env = [CGlobal sharedId].env;
        long row = indexPath.row;
        TblHealthData*info;
        TblInvitee* invitee = nil;
        if (row == 0) {
            info = _my_data;
        }else{
            invitee = _listData[row-1];
            if ([invitee.status isEqualToString:@"0"]) {
                info  = [[TblHealthData alloc] initNull:invitee.custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
            }else{
                info = [_group_data objectForKey:invitee.custid];
            }
            
        }
        [cell setData:info Invitee:invitee Challenge:_challengeInfo WinnerInfo:_winnerinfo];
        cell.aDelegate = self;
        cell.backgroundColor = self.viewRoot.backgroundColor;
        
        return cell;
    }else{
        MainDetailAimTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MainDetailAimTableViewCell"];
        EnvVar* env = [CGlobal sharedId].env;
        long row = indexPath.row;
        TblHealthData*info,*aimInfo;
        TblInvitee* invitee = nil;
        if (row == 0) {
            info = _my_data;
            
        }else{
            invitee = _listData[row-1];
            if ([invitee.status isEqualToString:@"0"]) {
                info  = [[TblHealthData alloc] initNull:invitee.custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
            }else{
                info = [_group_data objectForKey:invitee.custid];
            }
        }
        
        [cell setData:info Invitee:invitee Challenge:_challengeInfo WinnerInfo:_winnerinfo];
        cell.aDelegate = self;
        cell.backgroundColor = self.viewRoot.backgroundColor;
        return cell;
    }
}

- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:SEGUE_CHALLENGEDETAIL_TO_ADDCHALLENGE]) {
        AddChallengeViewController *add = (AddChallengeViewController *)segue.destinationViewController;
        add.challengeInfo = self.challengeInfo;
    }
    
}
-(IBAction) ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    switch (tag) {
        case 100:
        {
            // edit
            AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
            if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
                NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
                NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
                
                [Utils showAlert:localized_content title:localized_title];
                return;
            }
            
            [self performSegueWithIdentifier:SEGUE_CHALLENGEDETAIL_TO_ADDCHALLENGE sender:self];
            break;
        }
        case 101:{
            //withdraw
            [self onTapDisableChallengebutton:sender];
            break;
        }
        case 300:{
            [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_MAIN_COMMON_NOTI object:@{@"type":@"customsegue",@"segue":@"viewController1"}];
            break;
        }
        case 400:{
            curDate = [NSDate date];
            dispatch_async(dispatch_get_main_queue(), ^{
                [_viewNumberContainer slideInFromRight:0.3 Delegate:nil Bounds:CGRectZero];
                [self updateData];
            });
            
            break;
        }
        case 899:{
            if (self.viewNumberContainer.hidden) {
                // expand number view
                [self showNumberContent];
            }else{
                // close the controller
                [[NSNotificationCenter defaultCenter] removeObserver:self];
                
                [self.navigationController popViewControllerAnimated:true];
            }
            
            break;
        case 900:
            if (_manager.keyboardHeight>0) {
                [self.view endEditing:true];
                self.inputToolbar.hidden = true;
            }else{
                
            }
            break;
            
            
        }
        default:
            break;
    }
}
// handle when user withdraw a challenge.
- (IBAction)onTapDisableChallengebutton:(id)sender {
    NSString*text = _btnEdit.titleLabel.text;
    NSString *msg;
    if ([text isEqualToString:@"Edit"]) {
        //
        
        msg = [[NSBundle mainBundle] localizedStringForKey:@"Are you sure you want to disable this challenge?" value:@"" table:nil];
    }else{
        // withdraw
        if (_challengeType == 0) {
            msg = [[NSBundle mainBundle] localizedStringForKey:@"Do you want to withdraw from this challenge?" value:@"" table:nil];
        }else{
            msg = [[NSBundle mainBundle] localizedStringForKey:@"Do you want to withdraw from this aim?" value:@"" table:nil];
        }
        
    }
    NSString*yes = [[NSBundle mainBundle] localizedStringForKey:@"Yes" value:@"" table:nil];
    NSString*no = [[NSBundle mainBundle] localizedStringForKey:@"No" value:@"" table:nil];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:msg
                                                    message:@""
                                                   delegate:self
                                          cancelButtonTitle:nil
                                          otherButtonTitles:yes,no, nil];
    [alert show];
}
// handle disable withdraw when user confirms the dialog.
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        // withdraw challenge
        EnvVar* env = [CGlobal sharedId].env;
        NSString *url = [NSString stringWithFormat:@"https://share-a-success.com/tpw72betk/webservices.php?custId=%@&challengeId=%@&status=2&action=updateChallengeStatus", env.custId, _challengeInfo.challenge_id];
        [CGlobal showIndicator:self  Tag:nil];
        NetworkParser* manager = [NetworkParser sharedManager];
        [manager ontemplateGeneralRequestWithRawUrl:nil Path:url withCompletionBlock:^(NSDictionary *dict, NSError *error) {
            if (error == nil) {
                AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
                [delegate.dbManager deleteChallenge:_challengeInfo];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_CHALLENGELIST_CHANGED object:nil];
                [self.navigationController popViewControllerAnimated:true];
            }else{
                NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Failed to withdraw" value:@"" table:nil];
                NSString* alert = [[NSBundle mainBundle] localizedStringForKey:@"Alert" value:@"" table:nil];
                [CGlobal AlertMessage:temp Title:alert];
            }
            [CGlobal stopIndicator:self Tag:nil];
        }];
    }
}
// update the Screen based on the Current Day.
-(void) updateData{
    NSLog(@"challengeviewcontroller updatedata");
    EnvVar* env = [CGlobal sharedId].env;
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    
    _group_data = [[NSMutableDictionary alloc] init];
    _my_data = [delegate.dbManager getHealthData:curDate CustId:env.custId];
    if (_my_data == nil) {
        _my_data = [[TblHealthData alloc] initNull:env.custId Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
    }
    TblHealthData*my_data_t = [delegate.dbManager getHealthDataTo:curDate CustId:env.custId Mode:0];
    if (my_data_t!=nil) {
        _my_data.t_steps = my_data_t.steps;
        _my_data.t_walking = my_data_t.walking;
        _my_data.t_cycling = my_data_t.cycling;
        _my_data.t_standing = my_data_t.standing;
        _my_data.t_flights = my_data_t.flights;
        _my_data.t_active_cal = my_data_t.active_cal ;
        _my_data.t_swim = my_data_t.swim;
    }
    [_my_data checkForUse];
    _listData = [[NSMutableArray alloc] init];
    
    //interrupt for winnerinfo
    _winnerinfo =  [delegate.dbManager getWinnerData:curDate Challenge:_challengeInfo.challenge_id];
    //dd
    
    for (int i=0; i< [_challengeInfo.invitees count]; i++) {
        TblInvitee*invitee = _challengeInfo.invitees[i];
        NSString*custid = invitee.custid;
        
        if ([custid isEqualToString:env.custId]) {
            continue;
        }
        
        TblHealthData*healthdata = [delegate.dbManager getHealthData:curDate CustId:custid];
        if (healthdata==nil) {
            healthdata = [[TblHealthData alloc] initNull:custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
        }
        TblHealthData*healthdata_t = [delegate.dbManager getHealthDataTo:curDate CustId:custid Mode:0];
        if (healthdata_t!=nil) {
            
            healthdata.t_steps = healthdata_t.steps;
            healthdata.t_walking = healthdata_t.walking;
            healthdata.t_cycling = healthdata_t.cycling;
            healthdata.t_standing = healthdata_t.standing;
            healthdata.t_flights = healthdata_t.flights;
            healthdata.t_active_cal = healthdata_t.active_cal ;
            healthdata.t_swim = healthdata_t.swim;
        }
        [healthdata checkForUse];
        [_group_data setValue:healthdata forKey:custid];
        [_listData addObject:invitee];
    }
    
    //this is for adding the challenge owner when the app user is invited to this Challenge
    if (![_challengeInfo.custId isEqualToString:env.custId]) {
        NSString*custid = _challengeInfo.custId;
        TblHealthData*healthdata = [delegate.dbManager getHealthData:curDate CustId:custid];
        if (healthdata==nil) {
            healthdata = [[TblHealthData alloc] initNull:custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
        }
        TblHealthData*healthdata_t = [delegate.dbManager getHealthDataTo:curDate CustId:custid Mode:0];
        if (healthdata_t!=nil) {
            
            healthdata.t_steps = healthdata_t.steps;
            healthdata.t_walking = healthdata_t.walking;
            healthdata.t_cycling = healthdata_t.cycling;
            healthdata.t_standing = healthdata_t.standing;
            healthdata.t_flights = healthdata_t.flights;
            healthdata.t_active_cal = healthdata_t.active_cal ;
            healthdata.t_swim = healthdata_t.swim;
        }
        [healthdata checkForUse];
        [_group_data setValue:healthdata forKey:custid];
        
        TblInvitee* invitee = [[TblInvitee alloc] init];
        invitee.email_address = _challengeInfo.email_address;
        invitee.fname = _challengeInfo.fname;
        invitee.custid = custid;
        [_listData addObject:invitee];
    }
    
    // sort listdata
    
    NSArray* ppp = [_listData sortedArrayUsingComparator:^NSComparisonResult(TblInvitee* obj1,TblInvitee*  obj2) {
        NSString *first,*second;
        if (obj1.fname == nil || [obj1.fname isEqualToString:@""]) {
            first = obj1.email_address;
        }else{
            first = obj1.fname;
        }
        
        if (obj2.fname == nil || [obj2.fname isEqualToString:@""]) {
            second = obj2.email_address;
        }else{
            second = obj2.fname;
        }
        
        first = [first lowercaseString];
        second = [second lowercaseString];
        
        return [first compare:second];
        
    }];
    
    _listData = [[NSMutableArray alloc] initWithArray:ppp];
    
    NSMutableArray* maxminDays = [delegate.dbManager getMaxMinDay];
    if ([maxminDays count] == 2) {
        _maxDay = maxminDays[0];
        _minDay = maxminDays[1];
        
        _maxDay = [CGlobal getDayPart1:_maxDay];
        _minDay = [CGlobal getDayPart1:_minDay];
    }
    
    NSString*challenge_startday = nil;
    if ([_challengeInfo.custId isEqualToString:env.custId]) {
        challenge_startday =[CGlobal getDayPart1:_challengeInfo.date_added];
    }else{
        for (TblInvitee* item in _challengeInfo.invitees) {
            if ([item.custid isEqualToString:env.custId]) {
                challenge_startday =[CGlobal getDayPart1:item.accepted_date];
            }
        }
    }
    if ([_minDay compare:challenge_startday] == NSOrderedAscending) {
        _minDay = challenge_startday;
    }
    if (_challengeType == 0) {
        TblChallenge* item = _challengeInfo;
        
        float my_CGFLOAT_MIN = -1000;
        
        NSMutableArray* minValue_float = [[NSMutableArray alloc] initWithArray:@[[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX]]];
        NSMutableArray* maxValue_float = [[NSMutableArray alloc] initWithArray:@[[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN]]];
        
        
        NSMutableArray*otherids = [[NSMutableArray alloc] init];
        for (int j=0; j< [item.invitees count]; j++) {
            TblInvitee *invitee = item.invitees[j];
            if ([invitee.custid isEqualToString:env.custId]) {
                continue;
            }
            [otherids addObject:invitee.custid];
        }
        if (![item.custId isEqualToString:env.custId]) {
            [otherids addObject:item.custId];
        }
        
        
        NSMutableDictionary* temp = [[NSMutableDictionary alloc] initWithDictionary:_group_data];
        [temp setObject:_my_data forKey:_my_data.custId];
        NSArray* item_series_int = [item getChallengeValues];
        for (NSString *key in temp) {
            TblHealthData*iData = [temp objectForKey:key];
            NSString*cur_custid = iData.custId;
            if (![item.custId isEqualToString:cur_custid]) {
                for (int k=0; k<[item.invitees count]; k++) {
                    TblInvitee*invitee =  item.invitees[k];
                    if ([invitee.custid isEqualToString:cur_custid]) {
                        if ([invitee.status isEqualToString:@"0"]) {
                            iData = [[TblHealthData alloc] initNull:env.custId Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
                            NSLog(@"challengeid = %@  custid = %@",item.challenge_id,cur_custid);
                        }
                        break;
                    }
                }
            }
            NSArray* idata_float = [iData getHealthValues];
            
            for (int p=0; p<item_series_int.count; p++) {
                if ([item_series_int[p] intValue] == 1) {
                    float ivalue = [idata_float[p] floatValue];
                    if (ivalue>0) {
                        float minval = [minValue_float[p] floatValue];
                        float maxval = [maxValue_float[p] floatValue];
                        if (minval > ivalue) {
                            minval = ivalue;
                            minValue_float[p] = [NSNumber numberWithFloat:minval];
                        }
                        if (maxval < ivalue) {
                            maxval = ivalue;
                            maxValue_float[p] = [NSNumber numberWithFloat:maxval];
                        }
                    }
                }
                
            }
            
            
        }
        item.leading_val = [TblChallenge getLeadingSamples];
        for (NSString*key in temp) {
            TblHealthData*iData = [temp objectForKey:key];
            NSArray* idata_float = [iData getHealthValues];
            int nCount = 0;
            for (int p=0; p<item_series_int.count; p++) {
                if ([item_series_int[p] intValue] == 1 && [maxValue_float[p] floatValue] > 0 ) {
                    float ivalue = [idata_float[p] floatValue];
                    if (ivalue == [maxValue_float[p] floatValue]) {
                        NSMutableArray* iLeading = item.leading_val[p];
                        [iLeading addObject:iData.custId];
                    }
                    
                }
                
            }
        }
    }else{
        // aim
        // determine text color
        
    }
    
    
    [self updateToolBar];
    
    NSString* day = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    if (_challengeType == 0) {
        _lbl_top_challenge.text = [NSString stringWithFormat:@"%@ %@ -C",_challengeInfo.challenge_name,day];
    }else{
        _lbl_top_challenge.text = [NSString stringWithFormat:@"%@ %@ -A",_challengeInfo.challenge_name,day];
    }
    [_tableView reloadData];
    [_tableView2 reloadData];
    
    
    // add top header
    UIView* tmpRootView = self.viewHeadCell1;
    [self.viewRoot bringSubviewToFront:self.viewHeadCell1];
    self.tableView2.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    //
    if ([self.view viewWithTag:401]!=nil) {
        ChallengeVsDialog* helpView = [self.view viewWithTag:401];
        [helpView setData:helpView.frame Vc:self TargetId:helpView.targetId];
        [helpView.tableView reloadData];
    }
    [self.viewRoot bringSubviewToFront:self.viewHeadCell1];
}
// update the Top toolbar text based on the current Day.
-(void)updateToolBar{
    NSString* day = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    if ([day compare:_maxDay] == NSOrderedAscending) {
        _tool_btn_right.enabled = true;
        _img_next.image = [UIImage imageNamed:@"btn_next"];
        _can_goright = true;
    }else{
        _tool_btn_right.enabled = false;
        _img_next.image = [UIImage imageNamed:@"btn_next_disabled"];
        _can_goright = false;
    }
    
    if ([day compare:_minDay] == NSOrderedDescending) {
        _tool_btn_left.enabled = true;
        _img_prev.image = [UIImage imageNamed:@"btn_prev"];
        _can_goleft = true;
    }else{
        _tool_btn_left.enabled = false;
        _img_prev.image = [UIImage imageNamed:@"btn_prev_disabled"];
        _can_goleft = false;
    }
    day = [CGlobal getDayPart2FromNSDate:curDate isGmt:useGmt];
    NSString* dayofweek = [CGlobal getDayofWeekFromNSDate:curDate isGmt:useGmt];
    
    _tool_lbl_title1.text = @"";
    _lbl_headline1.text = dayofweek;//[NSString stringWithFormat:@"%@ %@",dayofweek,day];
    _lbl_headline3.text = day;
    
    // update img lock
    NSDate*date = [NSDate date];
    NSDate*monday = [CGlobal getFirstDay:date isGmt:useGmt];
    monday = [monday dateByAddingTimeInterval:-1*24*60*60];
    NSTimeInterval interval = [curDate timeIntervalSinceDate:monday];
    if (interval>0) {
        _img_lock.hidden = true;
    }else{
        _img_lock.hidden = false;
    }
    
    if([CGlobal isToday:curDate isGmt:useGmt]){
        _btnToday.hidden = true;
        _imgToday.hidden = true;
    }else{
        _btnToday.hidden = false;
        _imgToday.hidden = false;
    }
}


-(void)initializeChatView{
    EnvVar*env = [CGlobal sharedId].env;
    
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    DBManager* dbManager = delegate.dbManager;
    NSMutableArray*chat_list = [dbManager loadChat:_challengeInfo TIME:nil];
    //    [CGlobal showIndicatorForView:self.msgcontent_root];
    dispatch_async(dispatch_get_main_queue(), ^{
        NSString* myid = [NSString stringWithFormat:@"%d",env.lastLogin];

//        for (int i=self.viewScrollContainer.subviews.count-1; i>=0; i--)
//            [[self.viewScrollContainer.subviews objectAtIndex:i] removeFromSuperview];
//        [self.viewScrollContainer removeAllSubviews];
        
        if (nIndexLastView != -1) {
            int lastMessageIndex = nIndexLastView;
//            for(int i = self.viewScrollContainer.views.count - 1; i >= 0; i ++){
//                if (self.viewScrollContainer.views[i] == self.lastChatView) {
//                    lastMessageIndex = i;
//                    break;
//                } 
//            }
            
            for (int i = lastMessageIndex + 1; i < chat_list.count; i ++) {
                TblChat* model = chat_list[i];
                NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"ChatCells" owner:self options:nil];
                if ([model.user_id isEqualToString:myid]) {
                    // this is my message
                    ChatRight*view  = customViews[1];
                    [view setDataWithRow:model delegate:self type:_challengeType];
                    [self.viewScrollContainer addOneView:view];
                }else{
                    // other message
                    ChatLeft*view  = customViews[0];
                    [view setDataWithRow:model delegate:self type:_challengeType];
                    [self.viewScrollContainer addOneView:view];
                }
            }
        }
        else {
            for(int i=0; i<chat_list.count; i++){
                TblChat* model = chat_list[i];
                NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"ChatCells" owner:self options:nil];
                if ([model.user_id isEqualToString:myid]) {
                    // this is my message
                    ChatRight*view  = customViews[1];
                    [view setDataWithRow:model delegate:self type:_challengeType];
                    [self.viewScrollContainer addOneView:view];
                }else{
                    // other message
                    ChatLeft*view  = customViews[0];
                    [view setDataWithRow:model delegate:self type:_challengeType];
                    [self.viewScrollContainer addOneView:view];
                }
            }
        }
        
        if (nIndexLastView != self.viewScrollContainer.views.count - 1) {
            if(chat_list.count>0){
                TblChat* model = [chat_list lastObject];
                [model makeSeen];
                [dbManager insertOrUpdateChatData:model];
            }
            else{
                NSLog(@"no chat");
            }
            nIndexLastView = self.viewScrollContainer.views.count - 1;
            
            if (nIndexLastView != -1) {
                self.lastChatView = self.viewScrollContainer.views[nIndexLastView];
            }
            
            _historyHeight_MessageContent = [self.viewScrollContainer getHeightLast3Views];
            _constraint_MessageContent_Height.constant = _historyHeight_MessageContent;
            [self.viewScrollContainer setNeedsUpdateConstraints];
            [self controlInitialHeight];
            
            [self gotoBottom];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvMsg:) name:NOTIFICATION_RECEIVEMSG object:nil];
            
            [delegate setBadgeNumber];
            [CGlobal stopIndicatorForView:self.msgcontent_root];
        }
        else {
            _historyHeight_MessageContent = [self.viewScrollContainer getHeightLast3Views];
            _constraint_MessageContent_Height.constant = _historyHeight_MessageContent;
            [self.viewScrollContainer setNeedsUpdateConstraints];
            [self controlInitialHeight];
            
            [self gotoBottom];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvMsg:) name:NOTIFICATION_RECEIVEMSG object:nil];
            
            [delegate setBadgeNumber];
            [CGlobal stopIndicatorForView:self.msgcontent_root];
        }
    });
    
}
-(void)processHeightChanges{
    
    CGFloat msgHeight = [self.viewScrollContainer getHeightLast3Views];
    CGFloat flexHeight = fmax(0,self.availableHeight_FlexAndMsgArea - msgHeight);
    _historyHeight_MessageContent = msgHeight;
    _history_FlexHeight = flexHeight;
    
    if (self.viewNumberContainer.isHidden) {
        // this is full screen case
        // no need to do for constarint update views
    }else{
        // normal screen case
        
        _constraint_Msgcontent_TopMargin.constant = _history_FlexHeight;
        _constraint_MessageContent_Height.constant = _historyHeight_MessageContent;
        
        [self.msgcontent_root setNeedsUpdateConstraints];
        [self.view_scrollroot layoutIfNeeded];
    }
}
-(void)controlInitialHeight{
    CGRect frame = [self.view convertRect:self.tableView.frame fromView:self.tableView_Container];
    CGFloat sc_height = [UIScreen mainScreen].bounds.size.height;
    
    
    // get available height except message area and flexible area
    CGFloat allRemainHeight = _constraint_MsgContent_toBottom.constant      //  70
        + [UIApplication sharedApplication].statusBarFrame.size.height      // top status
        + frame.origin.y                                                    // height until tableview (member)
        + (self.listData.count + 1)*self.cellHeight;                        // member tableheight
    
    //
    self.availableHeight_FlexAndMsgArea = sc_height - allRemainHeight;
    
    
    CGFloat flexHeight = _availableHeight_FlexAndMsgArea - _historyHeight_MessageContent;
    _history_FlexHeight = fmax(0,flexHeight);
    _constraint_Msgcontent_TopMargin.constant = _history_FlexHeight;
    
    
    self.expandedHeight_MsgBox = sc_height - ( self.constraint_MsgContent_toBottom.constant + self.constraint_topviewheight.constant + [UIApplication sharedApplication].statusBarFrame.size.height );
    
    [self.msgcontent_root setNeedsUpdateConstraints];
    [self.view_scrollroot layoutIfNeeded];
    
    NSLog(@"availableHeight = %f",self.availableHeight_FlexAndMsgArea);
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NSLog(@"DETAIL RRRRRRRRRRRRRR");
}
-(void)recvMsg:(NSNotification*)noti{
    NSLog(@"received Msg");
    EnvVar* env = [CGlobal sharedId].env;
    if (noti.object!=nil) {
        if (noti.object[@"chat_model"]!=nil) {
            TblChat* model = noti.object[@"chat_model"];
            
            if ([model.ch_id intValue] == [_challengeInfo.challenge_id intValue] && [model.user_id intValue] != env.lastLogin) {
                [model makeSeen];
                
                AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
                [delegate.dbManager insertOrUpdateChatData:model];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"ChatCells" owner:self options:nil];
                    ChatLeft*view  = customViews[0];
                    [view setDataWithRow:model delegate:self type:_challengeType];
                    [self.viewScrollContainer addOneView:view];
                    nIndexLastView = self.viewScrollContainer.views.count - 1;
                    
                    [self gotoBottom];
                });
            }
            
            
            
        }
    }
    
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    [delegate setBadgeNumber];
}
-(void)gotoBottom{
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self.viewScrollContainer scrollToBottom];
        });
    });
}
-(void)saveChatListToLocal:(NSDictionary*) dict{
    NSMutableArray* list_msg = [[NSMutableArray alloc] init];
    NSArray*array  = dict[@"data"][@"msg"];
    if(array!=nil){
        for (int i=0; i< [array count]; i++) {
            TblChat *ach = [[TblChat alloc] initWithDictionaryABC:array[i] Encode:true];
            [list_msg addObject:ach];
        }
    }
    
    NSMutableArray* list_msg_del = [[NSMutableArray alloc] init];
    array  = dict[@"data"][@"msg_del"];
    if(array!=nil){
        for (int i=0; i< [array count]; i++) {
            TblChat *ach = [[TblChat alloc] initWithDictionaryABC:array[i] Encode:true];
            [list_msg_del addObject:ach];
        }
    }
    
    
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    DBManager* dbManager = delegate.dbManager;
    EnvVar* env = [CGlobal sharedId].env;
    if(list_msg.count>0){
        for (int i=0; i<list_msg.count; i++) {
            TblChat* model = list_msg[i];
            [model makeSeen];
            [dbManager insertOrUpdateChatData:model];
        }
        _lastChat = list_msg[list_msg.count-1];
    }
    
    if(list_msg_del.count>0){
        for (int i=0; i<list_msg_del.count; i++) {
            TblChat* model = list_msg_del[i];
            //            [model makeDeleted];
            [dbManager insertOrUpdateChatData:model];
        }
        NSLog(@"deleted %d",list_msg_del.count);
    }
}
-(void)loadMessageFromServer{
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate.reachability currentReachabilityStatus] == NotReachable) {
        [self initializeChatView];
    }
    else{
        [self getMessages :nil];
        
        self.timerLoadingMessages = [NSTimer scheduledTimerWithTimeInterval:5.0
                                         target:self
                                       selector:@selector(getMessages:)
                                       userInfo:nil
                                        repeats:YES];
    }
    
}

- (void)getMessages :(NSTimer *)timer  {
    NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
    [dict setValue:_lastChat?_lastChat.time_val:@"0" forKey:@"last_t"];
    [dict setValue:@"msg_ch" forKey:@"action"];
    [dict setValue:_challengeInfo.challenge_id forKey:@"ch_id"];
    [dict setValue:@"1" forKey:@"convert"];
    
    NetworkParser* manager = [NetworkParser sharedManager];
    NSString*serverurl = g_baseUrl;
    NSLog(@"%@",dict);
    
    //        [CGlobal showIndicatorForView:self.msgcontent_root];
    [manager generalNetwork:serverurl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        
        if (error == nil && dict[@"data"]!=nil && dict[@"data"][@"msg"]!=nil) {
            [self saveChatListToLocal:dict];
            [self initializeChatView];
            
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [CGlobal stopIndicatorForView:self.msgcontent_root];
        });
        
    } method:@"post"];
}

-(void)processSending:(NSString*)message Mode:(int)mode{
    AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate.reachability currentReachabilityStatus] == NotReachable) {
        // alert something
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return;
    }else{
        NSString* msg = message;
        msg = [msg stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
        if (msg.length>0) {
            // can send
            EnvVar*env = [CGlobal sharedId].env;
            NSString* myid = [NSString stringWithFormat:@"%d",env.lastLogin];
            NSString* name = env.fname;
            NSMutableDictionary*dict = [[NSMutableDictionary alloc] init];
            [dict setValue:_lastChat?_lastChat.time_val:@"0" forKey:@"last_t"];
            [dict setValue:@"msg_send" forKey:@"action"];
            [dict setValue:myid forKey:@"custId"];
            [dict setValue:name forKey:@"name"];
            [dict setValue:msg forKey:@"msg"];
            [dict setValue:_challengeInfo.challenge_id forKey:@"ch_id"];
            [dict setValue:@"1" forKey:@"convert"];
            
            
            
            // add chat
            TblChat*model = [[TblChat alloc] init];
            model.user_id = myid;
            model.user_name = name;
            model.msg = msg;
            model.time_val = [NSString stringWithFormat:@"%f", [[NSDate date] timeIntervalSince1970]];
            model.ch_id = _challengeInfo.challenge_id;
            
            NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"ChatCells" owner:self options:nil];
            ChatRight*view  = customViews[1];
            [view setDataWithRow:model delegate:self type:_challengeType];
            [self.viewScrollContainer addOneView:view];
            nIndexLastView = self.viewScrollContainer.views.count - 1;
            
            
            [self processHeightChanges];
            [self gotoBottom];
            
            
            NetworkParser* manager = [NetworkParser sharedManager];
            NSString*serverurl = g_baseUrl;
            NSLog(@"%@",dict);
            [manager generalNetwork:serverurl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
                if (error == nil && dict[@"data"]!=nil && dict[@"data"][@"msg"]!=nil) {
                    [self saveChatListToLocal:dict];
                    if(dict[@"data"][@"msg_row"]!=nil){
                        id idict = dict[@"data"][@"msg_row"];
                        TblChat *ach = [[TblChat alloc] initWithDictionaryABC:idict Encode:true];
                        [ach makeSeen];
                        [view setDataWithRow:ach delegate:self type:_challengeType];
                    }
                }
                
            } method:@"post"];
            
            if (mode == 1) {
                self.textView.text = @"";
                _chat_msg.text = @"";
                [self.view endEditing:true];
                _inputToolbar.hidden = true;
                //                _originalToolbar.hidden = false;
            }else if(mode == 2){
                _chat_msg.text = @"";
            }
        }
    }
    
    
    if(false)
    {
        NSString* jsonString = @"{\"aps\":{\"alert\":\"hello this is test chat messsage4\",\"sound\":\"default\",\"type\":\"4\",\"r\":{\"i\":\"3\",\"u\":\"2\",\"n\":\"huangbo\",\"t\":\"1533008762\",\"c\":\"323\"}}}";
        
        NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
        id json = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
        [delegate processNotification:json];
    }
}

-(void)scrollToBottom{
    
    CGPoint bottomOffset = CGPointMake(0, _scrollView.contentSize.height - _scrollView.bounds.size.height);
    [_scrollView setContentOffset:bottomOffset animated:YES];
    NSLog(@"bottomOffset y = %f",bottomOffset.y);
    
    
}
- (IBAction)clickSendKeyBoard:(id)sender {
    [self processSending:_textView.text Mode:1];
    
}
- (IBAction)clickSend:(id)sender {
    [self processSending:_chat_msg.text Mode:2];
    
}
- (IBAction)clickInput:(id)sender {
    if (_isEditChat) {
        return;
    }
    [_textView becomeFirstResponder];
    
    _inputToolbar.hidden = false;
}
-(void)textViewDidChangeHeight:(GrowingTextView *)textView height:(CGFloat)height{
    [_manager textViewDidChangeHeight:textView height:height];
    NSLog(@"textViewDidChangeHeight 111");
}
- (IBAction)tapPlusChat:(id)sender {
    [self clickInput:sender];
}
-(IBAction)toggleChatView:(id)sender{
    if (self.viewNumberContainer.hidden) {
        [self showNumberContent];
    }else{
        [self hideNumberContent];
    }
}
- (void)showNumberContent {
    [self.view layoutIfNeeded];
    
    
    [UIView animateWithDuration:0.4 animations:^{
        self.viewNumberContainer.hidden = false;
        self.viewToolRightContainer.hidden = false;
        self.viewCloseContainer.hidden = false;
        self.viewChatCloseContainer.hidden = true;
        
        
        _constraint_MessageContent_Height.constant = _historyHeight_MessageContent;
        _constraint_Msgcontent_TopMargin.constant = _history_FlexHeight;
        
        [self.viewNumberContainer setNeedsUpdateConstraints];
        [self.msgcontent_root setNeedsUpdateConstraints];
        [self.viewScrollContainer setNeedsUpdateConstraints];
        
        
        [self.view layoutIfNeeded]; // Called on parent view
    } completion:^(BOOL finished) {
        if (finished) {
            self.scrollView.scrollEnabled = true;
            self.viewHeadCell1.hidden = false;
            [self scrollViewDidScroll:self.scrollView];
            
        }
    }];
}
-(void)gotoBottomForRootScroll{
    CGPoint bottomOffset = CGPointMake(0, self.scrollView.contentSize.height - self.scrollView.bounds.size.height);
    [self.scrollView setContentOffset:bottomOffset animated:YES];
}
-(void)gotoTopForRootScroll{
    CGPoint bottomOffset = CGPointMake(0, 0);
    [self.scrollView setContentOffset:bottomOffset animated:YES];
}
- (void)hideNumberContent {
    [self.view layoutIfNeeded];
    
    self.viewHeadCell1.hidden = true;
    self.scrollView.scrollEnabled = false;
    
    [UIView animateWithDuration:0.4
                     animations:^{
                         self.viewNumberContainer.hidden = true;
                         self.viewToolRightContainer.hidden = true;
                         self.viewCloseContainer.hidden = true;
                         self.viewChatCloseContainer.hidden = false;
                         
                         
                         self.constraint_MessageContent_Height.constant = _expandedHeight_MsgBox;
                         self.constraint_Msgcontent_TopMargin.constant = 0;
                         
                         [self.msgcontent_root setNeedsUpdateConstraints];
                         //    [self.msgcontent_root layoutIfNeeded];
                         
                         [self.viewNumberContainer setNeedsUpdateConstraints];
                         [self.msgcontent_root setNeedsUpdateConstraints];
                         [self.viewScrollContainer setNeedsUpdateConstraints];
                         [self.view_scrollroot layoutIfNeeded];
                         
                         
                         [self.view layoutIfNeeded]; // Called on parent view
                     } ];
    //completion:^(BOOL finished) {
    //    //                         if (finished) {
    //    //                             dispatch_async(dispatch_get_main_queue(), ^{
    //    //                                 [self gotoTopForRootScroll];
    //    //                             });
    //    //
    //    //                         }
    //}
    
}
-(void)tapUserImage:(UITableViewCell*)cell{
    
    if ([self.view viewWithTag:401]!=nil) {
        ChallengeVsDialog* helpView = [self.view viewWithTag:401];
        [helpView removeFromSuperview];
    }
    NSString* targetId = @"";
    if ([cell isKindOfClass:[MainDetailTableViewCell class]]) {
        MainDetailTableViewCell*thiscell = cell;
        targetId = thiscell.invitee.custid;
        
    }else if ([cell isKindOfClass:[MainDetailAimTableViewCell class]]) {
        
        MainDetailAimTableViewCell*thiscell = cell;
        targetId = thiscell.invitee.custid;
    }
    
    EnvVar* env = [CGlobal sharedId].env;
    
    if (targetId == nil) {
        return;
    }
    if ([targetId intValue] == env.lastLogin) {
        
        return;
    }
    
    
    
    self.dialog = [[MyPopupDialog alloc] init];
    NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"HelpDialog" owner:self options:nil];
    ChallengeVsDialog* helpView = (ChallengeVsDialog*)customViews[1];
    
    CGFloat sc_width = [UIScreen mainScreen].bounds.size.width;
    CGFloat sc_height = [UIScreen mainScreen].bounds.size.height;
    
    //        helpView.frame = CGRectMake(0, 0, fmaxf(sc_width - 50,300), fmaxf(sc_height - 170,450));
    
    
    helpView.frame = CGRectMake(0, 0, sc_width, sc_height);
    [helpView firstProcess:helpView.frame Vc:self];
    [self.viewMaskBackground setHidden:NO];
    [self.viewMaskBackground_Head setHidden:NO];
    [self.viewTemp setHidden:NO];
//    helpView.frame = CGRectMake(0, 0, sc_width, sc_height);
    
//    UIBlurEffect *blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
//    UIVisualEffectView *blurEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
//    [blurEffectView setFrame:helpView.frame];
    
//    helpView.backgroundColor  = [UIColor redColor];
    [helpView setData:helpView.frame Vc:self TargetId:targetId];
    
    [self.view addSubview:helpView];
    [self.view bringSubviewToFront:helpView];
    helpView.center = self.view.center;
    helpView.tag = 401;
    
    
}
-(void)viewDidAppear:(BOOL)animated{
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        
        if (self.viewNumberContainer.hidden) {
            self.viewHeadCell1.hidden = true;
        }else{
            self.viewHeadCell1.hidden = false;
        }
        
        [self scrollViewDidScroll:self.scrollView];
        
    });
    
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.timerLoadingMessages invalidate];
    self.timerLoadingMessages = nil;
}
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    if (self.viewHeadCell1.hidden == false) {
        //CGRect frame = [self.viewRoot convertRect:self.tableView.frame fromView:self.tableView_Container];
        CGRect frame = [self.viewRoot convertRect:self.view_top3.frame fromView:self.tableView_Container];
        NSLog(@"tableview Top %f",frame.origin.y);
        
        CGFloat realtop = frame.origin.y;   // - 40-34;
        
        if (realtop>0) {
            self.constraint_viewHeadCell1_Top.constant = realtop;
        }else{
            self.constraint_viewHeadCell1_Top.constant = 0;
        }
        
        [self.viewHeadCell1 setNeedsUpdateConstraints];
        [self.viewHeadCell1 layoutIfNeeded];
    }
}
@end
