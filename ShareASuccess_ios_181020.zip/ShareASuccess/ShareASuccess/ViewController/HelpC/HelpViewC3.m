//
//  HelpViewC3.m
//  ShareASuccess
//
//  Created by BoHuang on 11/15/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import "HelpViewC3.h"
#import "CGlobal.h"
@implementation HelpViewC3

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
-(void)firstProcess{
    _constraint_Height.constant = topPadding_help;
    NSString*name = [[NSBundle mainBundle] localizedStringForKey:@"help_sc1" value:@"" table:nil];
    _imgContent.image = [UIImage imageNamed:name];
    
}
@end
