//
//  HelpViewC5.m
//  ShareASuccess
//
//  Created by BoHuang on 11/28/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import "HelpViewC5.h"
#import "CGlobal.h"
@implementation HelpViewC5

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
-(void)firstProcess{
    _constraint_Height.constant = topPadding_help;
    if ([CGlobal checkIphoneSe]) {
        NSString* txt1 = [[NSBundle mainBundle] localizedStringForKey:@"help5_aim_head" value:@"" table:nil];
        NSString* txt2 = [[NSBundle mainBundle] localizedStringForKey:@"help5_aim_head1" value:@"" table:nil];
        NSString* txt3 = [[NSBundle mainBundle] localizedStringForKey:@"help5_aim_head2" value:@"" table:nil];
        self.headLine.text = txt1;
        self.headLine1.text = txt2;
        self.headLine2.text = txt3;
    }else{
        self.headLine.hidden = false;
        self.headLine1.hidden = false;
        self.headLine2.hidden = true;
    }
//    self.headLine2.hidden = true;
}
-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    if ([_delegate respondsToSelector:@selector(gestureSwipe:)]) {
        NSString*action = @"right";
        [_delegate performSelector:@selector(gestureSwipe:) withObject:action];
    }
}
@end
