//
//  HelpViewC3.h
//  ShareASuccess
//
//  Created by BoHuang on 11/15/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpViewC3 : UIView
@property (weak, nonatomic) IBOutlet UIImageView *imgContent;

-(void)firstProcess;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint* constraint_Height;

@property (nonatomic,weak) IBOutlet UILabel* headLine;

@property (nonatomic,weak) IBOutlet UILabel* lblMessage1;
@end
