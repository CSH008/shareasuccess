//
//  HelpViewC4.m
//  ShareASuccess
//
//  Created by BoHuang on 11/15/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import "HelpViewC4.h"
#import "CGlobal.h"
@implementation HelpViewC4

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */
-(void)firstProcess{
    
    _constraint_Height.constant = topPadding_help;
   
    if ([CGlobal checkIphoneSe]) {
        NSString* txt1 = [[NSBundle mainBundle] localizedStringForKey:@"help4_aim_c" value:@"" table:nil];
        NSString* txt2 = [[NSBundle mainBundle] localizedStringForKey:@"help4_aim_c1" value:@"" table:nil];
        NSString* txt3 = [[NSBundle mainBundle] localizedStringForKey:@"help4_aim_c2" value:@"" table:nil];
        self.lblC.text = txt1;
        self.lblC1.text = txt2;
        self.lblC2.text = txt3;
    }else{
        self.lblC.hidden = false;
        self.lblC1.hidden = false;
        self.lblC2.hidden = true;
        
        self.lblC2.text = @"";
    }
}
-(void)setStyleForView:(UIView*)view{
    CGRect screenRect= [UIScreen mainScreen].bounds;
    CGRect rect = CGRectMake(0, 0, screenRect.size.width-12*2, 113);
    
    CGFloat borderWidth = 1.0;
    
    // This creates a testing view to test the theory, in your case this will be your UILabel
    
    view.layer.borderColor = [[CGlobal colorWithHexString:@"7F7F82" Alpha:1.0f] CGColor ];
    //    view.layer.borderColor = [[UIColor blackColor] CGColor];
    view.layer.borderWidth = borderWidth;
    
    
    UIView* mask = [[UIView alloc] initWithFrame:CGRectMake(0, borderWidth,rect.size.width, rect.size.height-borderWidth)];
    mask.backgroundColor = [UIColor blackColor];
    view.layer.mask = mask.layer;
}
@end
