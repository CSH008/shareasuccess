//
//  HelpViewC2.m
//  ShareASuccess
//
//  Created by BoHuang on 11/15/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import "HelpViewC2.h"
#import "CGlobal.h"
@implementation HelpViewC2

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

-(void)firstProcess{
    //    NSArray* array = [[NSArray alloc] initWithObjects:_view1,_view2,_view3,_view4, nil];
    
    _constraint_Height.constant = topPadding_help;
    
    NSString*name = [[NSBundle mainBundle] localizedStringForKey:@"help_ch" value:@"" table:nil];
    _imgContent.image = [UIImage imageNamed:name];
    
    
//    UIBezierPath *shadowPath = [UIBezierPath bezierPathWithRect:_scrollview.bounds];
//    _scrollview.layer.masksToBounds = NO;
//    _scrollview.layer.shadowColor = [UIColor blackColor].CGColor;
//    _scrollview.layer.shadowOffset = CGSizeMake(1.0f, 1.0f);
//    _scrollview.layer.shadowOpacity = 0.2f;
//    _scrollview.layer.shadowPath = shadowPath.CGPath;
//
//    CGFloat borderWidth = 1.0f;
//    
////    _scrollview.frame = CGRectInset(_scrollview.frame, -borderWidth, -borderWidth);
//    _scrollview.layer.borderColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.1].CGColor;
//    _scrollview.layer.borderWidth = borderWidth;
//    
//    _scrollview.layer.shadowOffset = CGSizeMake(0, 2.0f);
//    _scrollview.layer.shadowColor = [UIColor grayColor].CGColor;
//    _scrollview.layer.shadowOpacity = 1.0f;
//    _scrollview.layer.shadowRadius = 0.0f;
}
@end
