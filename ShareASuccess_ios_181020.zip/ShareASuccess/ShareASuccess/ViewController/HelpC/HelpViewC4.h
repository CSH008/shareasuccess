//
//  HelpViewC4.h
//  ShareASuccess
//
//  Created by BoHuang on 11/15/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpViewC4 : UIView
@property (weak, nonatomic) IBOutlet UILabel *lblC;
@property (weak, nonatomic) IBOutlet UILabel *lblC1;
@property (weak, nonatomic) IBOutlet UILabel *lblC2;
//@property (nonatomic,weak) IBOutlet UITextField* textField1;
//@property (nonatomic,weak) IBOutlet UITextField* textField2;
//@property (nonatomic,weak) IBOutlet UITextField* textField3;

//@property (nonatomic,weak) IBOutlet UIView* viewBottom1;

-(void)firstProcess;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint* constraint_Height;

@property (nonatomic,weak) IBOutlet UILabel* headLine;

//@property (nonatomic,weak) IBOutlet UILabel* lblMessage1;
//@property (nonatomic,weak) IBOutlet UILabel* lblMessage2;
//@property (nonatomic,weak) IBOutlet UILabel* lblMessage3;
//@property (nonatomic,weak) IBOutlet UILabel* lblMessage4;
//@property (nonatomic,weak) IBOutlet UILabel* lblUp;
@end
