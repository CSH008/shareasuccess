//
//  HelpViewC5.h
//  ShareASuccess
//
//  Created by BoHuang on 11/28/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelpViewC5 : UIView

-(void)firstProcess;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint* constraint_Height;

@property (nonatomic,weak) IBOutlet UILabel* headLine;
@property (nonatomic,strong) id delegate;

@property (weak, nonatomic) IBOutlet UILabel *headLine1;
@property (weak, nonatomic) IBOutlet UILabel *headLine2;


@end
