//
//  SwiftCodeManager.swift
//  test
//
//  Created by BoHuang on 8/1/18.
//  Copyright © 2018 BoHuang. All rights reserved.
//

import UIKit

//private let _networkUtil = SwiftCodeManager()

@objc public class SwiftCodeManager:NSObject,GrowingTextViewDelegate{
    
    @objc public var vc:UIViewController?
    
    @objc public var keyboardHeight:CGFloat = 0.0
    
    
    @objc public func viewDidLoad(){
        //vc.textView.layer.cornerRadius = 4.0;
        if let vc = self.vc as? ChallengeDetailViewController{
            vc.textView.layer.cornerRadius = 4.0
            
            // *** Listen to keyboard show / hide ***
            NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillChangeFrame), name: NSNotification.Name.UIKeyboardWillChangeFrame, object: nil)
            
            // *** Hide keyboard when tapping outside ***
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapGestureHandler(gesture:)))
            vc.view.addGestureRecognizer(tapGesture)
            
            //UIApplication.shared.applicationIconBadgeNumber = 5
            
            //            vc.textView.delegate = self
            //            vc.chat_msg.delegate = self
            
        }
        
    }
    
    @objc private func keyboardWillChangeFrame(_ notification: Notification) {
        if let vc = self.vc as? ChallengeDetailViewController{
            if let endFrame = (notification.userInfo?[UIKeyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
                var keyboardHeight = UIScreen.main.bounds.height - endFrame.origin.y
                if #available(iOS 11, *) {
                    if keyboardHeight > 0 {
                        keyboardHeight = keyboardHeight - vc.view.safeAreaInsets.bottom
                    }
                }
                vc.textViewBottomConstraint.constant = keyboardHeight
                vc.inputToolbar.setNeedsUpdateConstraints()
                
                if(keyboardHeight>0){
                    vc.constraint_MsgContent_toBottom.constant = keyboardHeight + vc.inputToolbar.frame.size.height
                    if vc.viewNumberContainer.isHidden {
                        vc.viewHeadCloseForKeyboardShow.isHidden = false;
                    }else{
                        vc.viewHeadCloseForKeyboardShow.isHidden = true;
                    }
                    
                }else{
                    vc.constraint_MsgContent_toBottom.constant = vc.bottomOffset_input; // vc.inputToolbar.frame.size.height +
                    vc.viewHeadCloseForKeyboardShow.isHidden = true;
                }
                
                self.keyboardHeight = keyboardHeight
                
                vc.view.layoutIfNeeded()
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    //debugPrint("originalToolbarHeight")
                    //debugPrint(vc.originalToolbar.frame.size.height)
                    
                    debugPrint("scrollview contentsize kk")
                    debugPrint(vc.scrollView.contentSize)
                    
                    DispatchQueue.main.async {
                        vc.scrollToBottom()
                    }
                }
                
                
            }
        }
        
    }
    
    func checkTableView(gesture:UITapGestureRecognizer) ->(UITableViewCell?) {
        if let vc = self.vc as? ChallengeDetailViewController{
            let point = gesture.location(in: vc.tableView)
            if let cell = vc.tableView.indexPathForRow(at: point) {
                if let cell = cell as? MainDetailTableViewCell {
                    return (cell)
                }else if let cell = cell as? MainDetailTableViewCell {
                    return (cell)
                }
            }
        }
        return (nil)
    }
    
    @objc func tapGestureHandler(gesture:UITapGestureRecognizer) {
        if let vc = self.vc as? ChallengeDetailViewController{
            
            if self.keyboardHeight>0 {
                // showing keyboard
                
                vc.view.endEditing(true)
                //vc.chat_msg.text = vc.textView.text
                //vc.textView.text = nil
                vc.inputToolbar.isHidden = true;
                //            vc.originalToolbar.isHidden = false;
                
                // close keyboard
            }else{
                
                // not showing keyboard
                // check whether popup is showing
                if let popup = vc.view.viewWithTag(401) {
                    //popup.removeFromSuperview()
                }else{
                    
                    // detect whether chat cell is tapped
                    let point = gesture.location(in: vc.msgcontent_root)
                    if vc.msgcontent_root.hitTest(point, with: nil) != nil{
                        // view existing
                        debugPrint("Inside Message Area")
                        
                        if !vc.viewNumberContainer.isHidden {
                            
                            vc.hideNumberContent();
                            
                        }else{
                            vc.showNumberContent();
                            
                        }
                        
                    }else{
                        // view non existing
                        debugPrint("Not Inside Message Area")
                        
                        // test for tableview
                        //                    if let cell = self.checkTableView(gesture: gesture){
                        //                        if let cell = cell as? MainDetailTableViewCell {
                        //                            vc.tap(cell)
                        //                        }else if let cell = cell as? MainDetailTableViewCell {
                        //                            vc.tap(cell)
                        //                        }
                        //                    }
                    }
                }
                
            }
            
        }
        
    }
    
    public func textViewDidChangeHeight(_ textView: GrowingTextView, height: CGFloat) {
        if let vc = self.vc as? ChallengeDetailViewController {
            vc.constraint_H_textview.constant = height
            vc.inputToolbar.setNeedsUpdateConstraints()
            
            UIView.animate(withDuration: 0.3, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 0.7, options: [.curveLinear], animations: { () -> Void in
                vc.view.layoutIfNeeded()
                debugPrint("scrollview contentsize")
                debugPrint(vc.scrollView.contentSize)
                
                if(vc.textViewBottomConstraint.constant>0){
                    vc.constraint_MsgContent_toBottom.constant = vc.textViewBottomConstraint.constant + vc.inputToolbar.frame.size.height
                }else{
                    vc.constraint_MsgContent_toBottom.constant = vc.bottomOffset_input; // vc.inputToolbar.frame.size.height +
                }
            }, completion: { (result) in
                
                
                debugPrint("inputToolbarHeight")
                debugPrint(vc.inputToolbar.frame.size.height)
                debugPrint("scrollview contentsize")
                debugPrint(vc.scrollView.contentSize)
                
                DispatchQueue.main.async {
                    vc.scrollToBottom()
                }
                
            })
            
            
        }
    }
    
    
    
}
