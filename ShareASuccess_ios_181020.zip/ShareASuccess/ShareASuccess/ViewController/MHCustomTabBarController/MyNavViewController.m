//
//  MyNavViewController.m
//  Fit
//
//  Created by Twinklestar on 7/8/16.
//
//

#import "MyNavViewController.h"

@implementation MyNavViewController

-(void)setContainerConstraints:(NSValue*)rectValue Parent:(UIView*)container{
    CGRect rect = [rectValue CGRectValue];
    CGSize size = rect.size;
    _constraint_viewheight = [NSLayoutConstraint constraintWithItem:self.view attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:size.height];
    _constraint_viewwidth = [NSLayoutConstraint constraintWithItem:self.view attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1 constant:size.width];
    _constraint_viewleading = [NSLayoutConstraint constraintWithItem:self.view attribute:NSLayoutAttributeLeading relatedBy:NSLayoutRelationEqual toItem:container attribute:NSLayoutAttributeLeading multiplier:1.0 constant:0];
    _constraint_viewtop = [NSLayoutConstraint constraintWithItem:self.view attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:container attribute:NSLayoutAttributeTop multiplier:1.0 constant:0];
    
    self.view.translatesAutoresizingMaskIntoConstraints = false;
    [NSLayoutConstraint activateConstraints:[[NSArray alloc] initWithObjects:_constraint_viewheight,_constraint_viewwidth,_constraint_viewleading,_constraint_viewtop, nil]];
    
    self.view.frame = rect;
    [self.view layoutIfNeeded];
    
}
@end
