/*
 * Copyright (c) 2015 Martin Hartl
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#import "MHCustomTabBarController.h"

#import "MHTabBarSegue.h"
#import "CGlobal.h"
#import "AppDelegate.h"

NSString *const MHCustomTabBarControllerViewControllerChangedNotification = @"MHCustomTabBarControllerViewControllerChangedNotification";
NSString *const MHCustomTabBarControllerViewControllerAlreadyVisibleNotification = @"MHCustomTabBarControllerViewControllerAlreadyVisibleNotification";

@interface MHCustomTabBarController ()

@property (nonatomic, strong) NSMutableDictionary *viewControllersByIdentifier;
@property (strong, nonatomic) NSString *destinationIdentifier;
@property (nonatomic) IBOutletCollection(UIButton) NSArray *buttons;

@end

@implementation MHCustomTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.viewControllersByIdentifier = [NSMutableDictionary dictionary];
    EnvVar*env = [CGlobal sharedId].env;
    if (env.lastChallengeCount>0) {
        [self setToolbarHidden:false];
    }else{
        [self setToolbarHidden:true];
    }

    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvNoti:) name:NOTIFICATION_TOOLBAR_CHANGE object:nil];
    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvBadge:) name:NOTIFICATION_TOOLBAR_BADGE object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvCommonNoti:) name:NOTIFICATION_MAIN_COMMON_NOTI object:nil];
    
    
    
    _view_badge.layer.cornerRadius = 10;
    _view_badge.backgroundColor = [UIColor redColor];
    [_view_badge setTextColor:[UIColor whiteColor]];
    _view_badge.layer.masksToBounds = true;
    
    _view_badge.hidden = true;
    if (self.childViewControllers.count < 1) {
        [self performSegueWithIdentifier:@"viewController2" sender:nil];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncChangeStatus:) name:GLOBALNOTIFICATION_SYNC_CHANGESTATUS object:nil];
}
-(void)syncChangeStatus:(NSNotification*)noti{
    NSDictionary*userinfo = noti.object;
    if (userinfo!=nil) {
        int status = [userinfo[@"status"] intValue];
        switch (status) {
            case GLOBAL_SYNC_INITIAL:
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    [CGlobal stopIndicator:self Tag:@"5001"];
//                    if (sync_collect_start!= nil  && sync_collect_done!=nil && sync_push_start!=nil && sync_push_done!=nil && sync_save_start!=nil && sync_save_done!=nil ) {
//                        NSString* detail = [NSString stringWithFormat:@"collect  %@-%@   push %@-%@  save %@-%@ ",sync_collect_start,sync_collect_done,sync_push_start,sync_push_done,sync_save_start,sync_save_done];
//                        [CGlobal AlertMessage:detail Title:@"Sync Period"];
//                    }
                });
                break;
            }
            case GLOBAL_SYNC_COLLECTING:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    if(g_indicator_mode == 1){
                        [CGlobal showIndicator:self Tag:@"5001"];
                    }
                    
                });
                
                break;
            }
            case GLOBAL_SYNC_COLLECTING_DONE:{
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    EnvVar* env = [CGlobal sharedId].env;
                    if (env.lastSyncStatus == GLOBAL_SYNC_COLLECTING_DONE) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [CGlobal stopIndicator:self Tag:@"5001"];
                        });
                    }
                });
                
                break;
            }
            case GLOBAL_SYNC_PUSHING:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    if(g_indicator_mode == 1){
                        [CGlobal showIndicator:self Tag:@"5001"];
                    }
                });
                break;
            }
            case GLOBAL_SYNC_PUSHING_DONE:{
                // aadded
                dispatch_async(dispatch_get_main_queue(), ^{
                    if(g_indicator_mode == 1){
                        [CGlobal showIndicator:self Tag:@"5001"];
                    }
                });
                break;
            }
            case GLOBAL_SYNC_GETTING_MYINFO:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    if(g_indicator_mode == 1){
                        [CGlobal showIndicator:self Tag:@"5001"];
                    }
                });
                break;
            }
            case GLOBAL_SYNC_IMPORTING:{
                dispatch_async(dispatch_get_main_queue(), ^{
                    if(g_indicator_mode == 1){
                        [CGlobal showIndicator:self Tag:@"5001"];
                    }
                });
                break;
            }
            default:
                break;
        }
    }
}
-(void)recvBadge:(NSNotification*)noti{
    NSString* obj = noti.object;
    if (obj!=nil) {
        int count = [obj intValue];
        if (count>0) {
            _view_badge.hidden = false;
            _view_badge.text = obj;
            
            
             //show dialogs
            
        }else{
            _view_badge.hidden = true;
        }
        
    }
    NSLog(@"recvBadge");
}
-(void)recvNoti:(NSNotification*)noti{
    NSString* obj = noti.object;
    if (obj!=nil) {
        int hidden = [obj intValue];
        if (hidden == 1) {
            [self setToolbarHidden:true];
        }else{
            [self setToolbarHidden:false];
        }
    }
}
-(void)recvCommonNoti:(NSNotification*)noti{
    NSDictionary* obj = noti.object;
    if (obj!=nil) {
        NSString* type = obj[@"type"];
        if ([type isEqualToString:@"customsegue"]) {
            NSString* segue = obj[@"segue"];
            [self performSegueWithIdentifier:segue sender:nil];
        }
    }
}
-(void) dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
-(void)setToolbarHidden:(BOOL)hidden{
    _view_bottombar.hidden = hidden;
    _view_bottombar_mask.hidden = !hidden;
}

-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    AppDelegate * delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [delegate registerDeviceUUID];
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    self.destinationViewController.view.frame = self.container.bounds;
}

-(void)showInviteDialog{
    
}

#pragma mark - Segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
   
    if (![segue isKindOfClass:[MHTabBarSegue class]]) {
        [super prepareForSegue:segue sender:sender];
        return;
    }
    
    self.oldViewController = self.destinationViewController;
    
    //if view controller isn't already contained in the viewControllers-Dictionary
    if (![self.viewControllersByIdentifier objectForKey:segue.identifier]) {
        [self.viewControllersByIdentifier setObject:segue.destinationViewController forKey:segue.identifier];
    }
    
    [self.buttons setValue:@NO forKeyPath:@"selected"];
//    [sender setSelected:YES];
//    self.selectedIndex = [self.buttons indexOfObject:sender];

    self.destinationIdentifier = segue.identifier;
    self.destinationViewController = [self.viewControllersByIdentifier objectForKey:self.destinationIdentifier];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:MHCustomTabBarControllerViewControllerChangedNotification object:nil]; 

    NSArray*array = [NSArray arrayWithObjects:@"viewController1",@"viewController2",@"viewController3", nil];
    self.selectedIndex = [array indexOfObject:segue.identifier];
    [self setMenuImage];
    
}
-(void)setMenuImage{
    switch (_selectedIndex) {
        case 0:
        {
            _img_first.image = [UIImage imageNamed:@"tab_first_hover.png"];
            _img_second.image = [UIImage imageNamed:@"tab_second_normal.png"];
            _img_third.image = [UIImage imageNamed:@"tab_third_normal.png"];
            break;
        }
        case 1:{
            _img_first.image = [UIImage imageNamed:@"tab_first_normal.png"];
            _img_second.image = [UIImage imageNamed:@"tab_second_hover.png"];
            _img_third.image = [UIImage imageNamed:@"tab_third_normal.png"];
            break;
        }
        case 2:{
            _img_first.image = [UIImage imageNamed:@"tab_first_normal.png"];
            _img_second.image = [UIImage imageNamed:@"tab_second_normal.png"];
            _img_third.image = [UIImage imageNamed:@"tab_third_hover.png"];
            break;
        }
        default:
            break;
    }
}

- (BOOL)shouldPerformSegueWithIdentifier:(NSString *)identifier sender:(id)sender {
    if ([self.destinationIdentifier isEqual:identifier]) {
        //Dont perform segue, if visible ViewController is already the destination ViewController
        [[NSNotificationCenter defaultCenter] postNotificationName:MHCustomTabBarControllerViewControllerAlreadyVisibleNotification object:nil];
        if (_selectedIndex == 1) {
            UINavigationController*nav = (UINavigationController*)self.destinationViewController;
            [nav popToRootViewControllerAnimated:true];
            
        }
        
        return NO;
    }
    
    return YES;
}

#pragma mark - Memory Warning

- (void)didReceiveMemoryWarning {
    [[self.viewControllersByIdentifier allKeys] enumerateObjectsUsingBlock:^(NSString *key, NSUInteger idx, BOOL *stop) {
        if (![self.destinationIdentifier isEqualToString:key]) {
            [self.viewControllersByIdentifier removeObjectForKey:key];
        }
    }];
    [super didReceiveMemoryWarning];
}

@end
