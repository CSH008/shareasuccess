//
//  MyNavViewController.h
//  Fit
//
//  Created by Twinklestar on 7/8/16.
//
//

#import <UIKit/UIKit.h>

@interface MyNavViewController : UINavigationController

@property (strong,nonatomic) NSLayoutConstraint *constraint_viewwidth;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewheight;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewleading;
@property (strong,nonatomic) NSLayoutConstraint *constraint_viewtop;

-(void)setContainerConstraints:(NSValue*)rectValue Parent:(UIView*)container;
@end
