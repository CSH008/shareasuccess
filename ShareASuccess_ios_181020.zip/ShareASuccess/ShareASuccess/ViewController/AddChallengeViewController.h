//
//  AddChallengeViewController.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
#import "GCPlaceholderTextView.h"
#import "TblChallenge.h"
#import "UIComboBox.h"

/**
 Screen corresponds to Add or Edit the Challenge.
 **/
@class RoundCornerButton;
@class ColoredView;

@interface InviteControl : NSObject
@property (strong, nonatomic) UITextField *textFieldEmail;
@property (strong, nonatomic) UIButton *btnMinus;
@property (strong, nonatomic) UIImageView *imageStatus;
@end

@interface AddChallengeViewController : UIViewController <UITextFieldDelegate,UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate>

@property (strong, nonatomic) GetChallengeDetail *getchallengeDetail;
@property (strong, nonatomic) TblChallenge *challengeInfo;

@property (weak, nonatomic) IBOutlet RoundCornerButton *btnChallenging;
@property (weak, nonatomic) IBOutlet RoundCornerButton *btnAim;
@property (weak, nonatomic) IBOutlet UIStackView *stackChallenging;
@property (weak, nonatomic) IBOutlet UIStackView *stackAim;


@property (weak, nonatomic) IBOutlet UITextField *labelChallengeName;
@property (weak, nonatomic) IBOutlet GCPlaceholderTextView *labelChallengeDesc;
@property (weak, nonatomic) IBOutlet UISwitch *switchSteps;
@property (weak, nonatomic) IBOutlet UISwitch *switchWalking;
@property (weak, nonatomic) IBOutlet UISwitch *switchStanding;
@property (weak, nonatomic) IBOutlet UISwitch *switchActive;
@property (weak, nonatomic) IBOutlet UISwitch *switchCycling;
@property (weak, nonatomic) IBOutlet UISwitch *switchFlights;
@property (weak, nonatomic) IBOutlet UISwitch *switchSwiming;

@property (weak, nonatomic) IBOutlet UISwitch *switchStepsAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchWalkingAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchStandingAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchActiveAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchCyclingAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchFlightsAim;
@property (weak, nonatomic) IBOutlet UISwitch *switchSwimingAim;

@property (weak, nonatomic) IBOutlet UIButton *btnStepsAim;
@property (weak, nonatomic) IBOutlet UIButton *btnWalkingAim;
@property (weak, nonatomic) IBOutlet UIButton *btnStandingAim;
@property (weak, nonatomic) IBOutlet UIButton *btnActiveAim;
@property (weak, nonatomic) IBOutlet UIButton *btnCyclingAim;
@property (weak, nonatomic) IBOutlet UIButton *btnFlightsAim;
@property (weak, nonatomic) IBOutlet UIButton *btnSwimingAim;
@property (weak, nonatomic) IBOutlet UIButton *btnAimtype;

@property (weak, nonatomic) IBOutlet UILabel *lblStepsAim;
@property (weak, nonatomic) IBOutlet UILabel *lblWalkingAim;
@property (weak, nonatomic) IBOutlet UILabel *lblStandingAim;
@property (weak, nonatomic) IBOutlet UILabel *lblActiveAim;
@property (weak, nonatomic) IBOutlet UILabel *lblCyclingAim;
@property (weak, nonatomic) IBOutlet UILabel *lblFlightsAim;
@property (weak, nonatomic) IBOutlet UILabel *lblSwimingAim;
@property (weak, nonatomic) IBOutlet UILabel *lblAimtype;

@property (weak, nonatomic) IBOutlet UILabel *lblStepsAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblWalkingAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblStandingAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblActiveAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblCyclingAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblFlightsAim_;
@property (weak, nonatomic) IBOutlet UILabel *lblSwimingAim_;

@property (weak, nonatomic) IBOutlet UILabel *lblSteps_;
@property (weak, nonatomic) IBOutlet UILabel *lblWalking_;
@property (weak, nonatomic) IBOutlet UILabel *lblStanding_;
@property (weak, nonatomic) IBOutlet UILabel *lblActive_;
@property (weak, nonatomic) IBOutlet UILabel *lblCycling_;
@property (weak, nonatomic) IBOutlet UILabel *lblFlights_;
@property (weak, nonatomic) IBOutlet UILabel *lblSwiming_;
//@property (weak, nonatomic) IBOutlet UILabel *lblAimtype_;


@property (weak, nonatomic) IBOutlet UIView *vnStepsAim;
@property (weak, nonatomic) IBOutlet UIView *vnWalkingAim;
@property (weak, nonatomic) IBOutlet UIView *vnStandingAim;
@property (weak, nonatomic) IBOutlet UIView *vnActiveAim;
@property (weak, nonatomic) IBOutlet UIView *vnCyclingAim;
@property (weak, nonatomic) IBOutlet UIView *vnFlightsAim;
@property (weak, nonatomic) IBOutlet UIView *vnSwimingAim;
@property (weak, nonatomic) IBOutlet UIView *vnAimtype;

@property (weak, nonatomic) IBOutlet ColoredView *cvStepsAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvWalkingAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvStandingAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvActiveAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvCyclingAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvFlightsAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvSwimingAim;
@property (weak, nonatomic) IBOutlet ColoredView *cvAimtype;

@property (weak, nonatomic) IBOutlet UIPickerView *pkStepsAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkWalkingAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkStandingAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkActiveAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkCyclingAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkFlightsAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkSwimingAim;
@property (weak, nonatomic) IBOutlet UIPickerView *pkAimtype;


@property (weak, nonatomic) IBOutlet UITextField *textFieldEmail;
@property (weak, nonatomic) IBOutlet UIButton *btnPlus;
@property (weak, nonatomic) IBOutlet UIButton *btnSave;
@property (weak, nonatomic) IBOutlet UIButton *btnStop;

@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (weak, nonatomic) IBOutlet UIView* view_scrollroot;
@property (weak, nonatomic) IBOutlet UIScrollView* scrollview;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_right;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool1;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool2;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool3;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint* constraint_tableheight;




@property (weak, nonatomic) IBOutlet UIView *view_description;

@property (strong, nonatomic) NSString* presentMode; //  nil navigation   1  present

@property (nonatomic,strong) IBOutlet UITableView *autocompleteTable;
@property (nonatomic,strong) IBOutlet UIView *viewAutoComplete;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading1;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing1;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_bottom;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top_title;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;

@property (nonatomic,weak) IBOutlet UILabel*lbl_header1;


@property (weak, nonatomic) IBOutlet UIImageView *img_aim_steps;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_walking;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_cycling;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_swimming;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_stand;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_stair;
@property (weak, nonatomic) IBOutlet UIImageView *img_aim_energy;

    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_steps;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_walking;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_cycling;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_swimming;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_stand;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_stair;
    @property (weak, nonatomic) IBOutlet UIImageView *img_ch_energy;
@end
