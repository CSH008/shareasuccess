//
//  NewUserViewController.m
//  ShareASuccess
//
//  Created by BoHuang on 9/11/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import "NewUserViewController.h"
#import "AppDelegate.h"
#import "Utils.h"
#import "inc.h"
#import "CGlobal.h"
#import "NetWorkParser.h"
#import "ResetPasswordViewController.h"
#import "NewUserViewController.h"

@interface NSString (emailValidation)
- (BOOL) isValidEmail;
@end

@interface NewUserViewController ()

@end


@implementation NewUserViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = APP_COLOR_PRIMARY;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)ClickView:(UIView*)sender{
    int tag = sender.tag;
    if (tag == 899) {
        [self.navigationController popViewControllerAnimated:true];
    }
}
-(void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
// when user click create button.
- (IBAction)onTapCreateAccountButton:(id)sender {
    
    
    AppDelegate* appDelegate = [[UIApplication sharedApplication] delegate];
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (self.textFieldSignupFirstName.text.length == 0 || self.textFieldSignupLastName.text.length == 0 || self.textFieldSignupScreenName.text.length == 0 || self.textFieldSignupEmail.text.length == 0 || self.textFieldSignupReEmail.text.length == 0 || self.textFieldSignupPassword.text.length == 0) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_INFORMATION_EMPTY value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (![self.textFieldSignupEmail.text isValidEmail]) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_INVALID_EMAIL value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (![self.textFieldSignupEmail.text isEqualToString:self.textFieldSignupReEmail.text]) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_EMAIL_DIFFERENT value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    NSString *firstname = self.textFieldSignupFirstName.text;
    NSString *lastname = self.textFieldSignupLastName.text;
    NSString *screenname = self.textFieldSignupScreenName.text;
    NSString *email = self.textFieldSignupEmail.text;
    NSString *password = self.textFieldSignupPassword.text;
    
    NSString *publicdata = [NSString stringWithFormat:@"%d",(self.SwitchData.isOn ? 1:0)];
    NSString *push_enabled = [NSString stringWithFormat:@"%d",(self.SwitchPush.isOn ? 1:0)];
    NSString * language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    NSString * timezone = [[NSTimeZone localTimeZone] name];
    
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    [dict setValue:firstname forKey:@"Firstname"];
    [dict setValue:lastname forKey:@"Lastname"];
    [dict setValue:email forKey:@"emailAddress"];
    [dict setValue:password forKey:@"pwd"];
    [dict setValue:screenname forKey:@"screen"];
    [dict setValue:publicdata forKey:@"public_share"];
    [dict setValue:language forKey:@"language"];
    [dict setValue:timezone forKey:@"user_timezone"];
    [dict setValue:push_enabled forKey:@"push_enabled"];
    
    [dict setValue:@"saveUser" forKey:@"action"];
    
    NetworkParser* manager = [NetworkParser sharedManager];
    [CGlobal showIndicator:self Tag:nil];
    
    [manager generalNetwork:g_baseUrl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            UIStoryboard* main = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            UIViewController* vc = [main instantiateViewControllerWithIdentifier:@"UserSetupViewController"];
            NSArray* vc_list = self.navigationController.viewControllers;
            NSMutableArray* list = [[NSMutableArray alloc] initWithArray:vc_list];
            [list removeLastObject];
            [list addObject:vc];
            [self.navigationController setViewControllers:list];
            
            
        }else{
            NSString*error = (NSString*)[dict objectForKey:@"res"];
            if (error != nil) {
                [CGlobal AlertMessage:[BaseModel decodeString:error] Title:nil];
            }
        }
        [CGlobal stopIndicator:self Tag:nil];
    } method:@"POST"];
    
}
@end

@implementation NSString (emailValidation)

-(BOOL) isValidEmail
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:self];
}

@end
