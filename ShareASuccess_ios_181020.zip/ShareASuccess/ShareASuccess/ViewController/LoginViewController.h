//
//  LoginViewController.h
//  Fit
//
//  Created by Denis on 10/9/15.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

/**
 Login Screen.
 **/
@interface LoginViewController : UIViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *textFieldSigninEmail;
@property (weak, nonatomic) IBOutlet UITextField *textFieldSigninPassword;

@property (nonatomic,weak) IBOutlet UIButton* btn_url1;
@property (nonatomic,weak) IBOutlet UIButton* btn_url2;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;
@end
