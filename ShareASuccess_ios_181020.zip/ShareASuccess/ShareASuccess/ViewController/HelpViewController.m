//
//  HelpViewController.m
//  PageApp
//
//  Created by Rafael Garcia Leiva on 10/06/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import "HelpViewController.h"
#import "HelpView1.h"
#import "HelpView2.h"
#import "HelpView3.h"
#import "HelpView4.h"
#import "HelpView5.h"
#import "HelpIndicator.h"
#import "CGlobal.h"
#import "UIView+Animation.h"
#import "HelpRootView.h"

@interface HelpViewController ()
@property (assign,nonatomic) long curpage;
@property (assign,nonatomic) CGPoint lastOffset;
@property (assign,nonatomic) CGRect scrollViewRect;

@property (strong,nonatomic) NSArray* helpViews;
//@property (strong,nonatomic) HelpIndicator* helpIndicator;
@end

@implementation HelpViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _constraint_leading.constant = status_leading;
    _constraint_trailing.constant = status_leading;
    
    _constraint_toolbar_bottom.constant = bottom_space;
    _constraint_toolbar_top_title.constant = top_space_toolbar_title;
    _constraint_first_top.constant = top_space- statusbar_gap1;
    
    _constraint_menu_height.constant = g_menuHeight;
    
    
    [_tool_btn_left addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _tool_btn_left.tag = 999;
    
    [_btnNext addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _btnNext.tag = 101;
    
    NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"HelpView" owner:self options:nil];
    NSArray* customViews2= [[NSBundle mainBundle] loadNibNamed:@"HelpRootView" owner:self options:nil];
    //HelpView1*view1 = (HelpView1*)customViews[0]; [view1 firstProcess];
    HelpView2*view2 = (HelpView2*)customViews[1]; [view2 firstProcess];
    HelpView3*view3 = (HelpView3*)customViews[2]; [view3 firstProcess];
    HelpView4*view4 = (HelpView4*)customViews[3]; [view4 firstProcess];
    HelpView5*view5 = (HelpView5*)customViews[4]; [view5 firstProcess];
    HelpRootView* view6 = (HelpRootView*)customViews2[0]; [view6 firstProcess];
//    _helpIndicator = (HelpIndicator*)customViews[5]; [_helpIndicator firstProcess];
    
    
    CGFloat statusHeight =  [[UIApplication sharedApplication] statusBarFrame].size.height;
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    
    CGFloat restHeight = statusHeight + _constraint_menu_height.constant;
    CGRect viewRootRect = CGRectMake(0, 0, screenRect.size.width, screenRect.size.height-restHeight);
    _scrollViewRect = viewRootRect;
    
    _helpViews = [[NSArray alloc] initWithObjects:view2,view3,view4,view5,view6 ,nil];


    for (int i=0; i< [_helpViews count]; i++) {
        UIView* view = _helpViews[i];
        CGRect rect = CGRectMake(0, 0, viewRootRect.size.width, viewRootRect.size.height);
        view.frame = rect;
        
        
        [_viewRoot addSubview:view];
        
        view.hidden = true;
        view.backgroundColor = APP_COLOR_PRIMARY;
    }
    
    _curpage = 0;
    [self setToolbarTitle:_curpage];
    view2.hidden = false;
    
    [view2 layoutIfNeeded];
    
    UISwipeGestureRecognizer*swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeRight:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionLeft];
    [_viewRoot addGestureRecognizer:swipe];
    
    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeLeft:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [_viewRoot addGestureRecognizer:swipe];
    
    _viewRoot.backgroundColor = view2.backgroundColor;
    _viewRootSuper.backgroundColor = view2.backgroundColor;
    
    UIImage*image = self.imgCross.image;
    self.imgCross.image = [CGlobal getColoredImageFromImage:image Color:APP_COLOR_RED];
    
    
}
-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    _curpage = _curpage -1;
    if (_curpage <0) {
        _curpage = _helpViews.count-1;
        [self.navigationController popViewControllerAnimated:true];
        return;
    }
    long snappage = _curpage;
    [_viewRoot slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *view in _helpViews) {
            view.hidden = true;
        }
        UIView*view = _helpViews[snappage];
        view.hidden = false;
        _stackNext.hidden = false;
        
        [self setToolbarTitle:snappage];
    });
}
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture{
    _curpage = _curpage + 1;
    if (_curpage>=_helpViews.count) {
        _curpage = _helpViews.count -1;
        return;
    }
    if (_curpage>= _helpViews.count - 1) {
        long snappage = _curpage;
        [_viewRoot slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
        dispatch_async(dispatch_get_main_queue(), ^{
            for (UIView *view in _helpViews) {
                view.hidden = true;
            }
            UIView*view = _helpViews[snappage];
            view.hidden = false;
            
            _stackNext.hidden = true;
            
            
            [self setToolbarTitle:snappage];
            
            
        });
        
        NSArray* vcs =  self.navigationController.viewControllers;
        NSMutableArray* new_vcs = [[NSMutableArray alloc] init];
        for (int i=0; i<vcs.count; i++) {
            [new_vcs addObject:vcs[i]];
        }
        [self.navigationController setViewControllers:new_vcs animated:true];
        return;
    }
    long snappage = _curpage;
    [_viewRoot slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    dispatch_async(dispatch_get_main_queue(), ^{
        for (UIView *view in _helpViews) {
            view.hidden = true;
        }
        UIView*view = _helpViews[snappage];
        view.hidden = false;
        
        [self setToolbarTitle:snappage];
    });
}
-(void)setToolbarTitle:(long)index{
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Hilfe %d/%d" value:@"" table:nil];
    
    _tool_lbl_title1.text = @"";
//    _tool_lbl_title1.text = [NSString stringWithFormat:temp,index+1,_helpViews.count];
    
}
- (void)didReceiveMemoryWarning {
    
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

-(void)ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    switch (tag) {
        case 999:
        {
//            [self.navigationController popViewControllerAnimated:true];
            [self.navigationController popToRootViewControllerAnimated:true];
            break;
        }
        case 101:{
            [self gestureSwipeRight:nil];
            break;
        }
        default:
            break;
    }
}
-(void) scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    
    if(scrollView == _scrollview){
        CGPoint point = [_scrollview contentOffset];
        _curpage = (point.x )/_scrollViewRect.size.width;
        [self setToolbarTitle:_curpage];
        
        
        if (_curpage == 0 && _lastOffset.x<0) {
            NSLog(@"LEEEEEFT");
            CGFloat x = _scrollview.contentSize.width - _scrollViewRect.size.width;
            [_scrollview setContentOffset:CGPointMake(x, 0) animated:TRUE];
        }else if(_curpage == _helpViews.count-1 && _lastOffset.x > _scrollview.contentSize.width - _scrollViewRect.size.width){
            NSLog(@"RIIIIIIGHT");
            CGFloat x = 0;
            [_scrollview setContentOffset:CGPointMake(x, 0) animated:TRUE];
        }
    }
}
-(void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView{
    if(scrollView == _scrollview){
        CGPoint point = [_scrollview contentOffset];
        
        _lastOffset = point;
        
    }
}
-(void)gestureSwipe:(NSString*)action{
    if ([action isEqualToString:@"left"]) {
        CGFloat x = _scrollViewRect.size.width* _helpViews.count;
        [_scrollview setContentOffset:CGPointMake(x, 0) animated:TRUE];
    }else if ([action isEqualToString:@"right"]) {
        CGFloat x = 0;
        [_scrollview setContentOffset:CGPointMake(x, 0) animated:TRUE];
    }
    NSLog(@"swipe performed %@",action);
}
@end
