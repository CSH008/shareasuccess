//
//  ProfileViewController.m
//  Fit
//
//  Created by Denis on 10/8/15.
//
//

#import "ProfileViewController.h"
#import "Utils.h"
#import "inc.h"
#import "CGlobal.h"
#import "NetworkParser.h"

@interface ProfileViewController ()

@end

@interface NSString (emailValidation)
- (BOOL) isValidEmail;
@end

@implementation ProfileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = APP_COLOR_PRIMARY;
//    self.navigationController.navigationController.navigationBarHidden = YES;
    _constraint_leading.constant = status_leading;
    _constraint_trailing.constant = status_trailing;

    
    _constraint_toolbar_bottom.constant = bottom_space;
    _constraint_toolbar_top_title.constant = top_space_toolbar_title;
    _constraint_first_top.constant = top_space- statusbar_gap1;
    
    _constraint_menu_height.constant = g_menuHeight;
        
    appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
    
    
    //[CGlobal makeStyle1:_btn_action Mode:0];
//    [CGlobal makeStyle1:_btn_import];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    tap.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tap];
    
    NSArray* allTextFields = [self findAllTextFieldsInView:[self view]];
    
    for(int i=0;i<allTextFields.count;i++){
        UITextField* textfield =(UITextField*)allTextFields[i];
        //        textfield.autocapitalizationType = UITextAutocapitalizationTypeSentences;
        textfield.delegate = self;
    }
    EnvVar* env = [CGlobal sharedId].env;
    
    self.textFieldFirstName.text = env.fname;
    self.textFieldLastName.text = env.lname;
    self.textFieldScreenName.text = env.screen;
    self.textFieldEmail.text = env.email;
    self.textFieldPassword.text = env.password;
    //    self.textFieldConfirmPassword.text = appDelegate.custInfo.password;
    self.textFieldScreenName.enabled = NO;
    
    if ([appDelegate.custInfo.publicdata isEqualToString:@"0"]) {
        [self.SwitchData setOn:NO];
    }else{
        [self.SwitchData setOn:YES];
    }
    
    if ([env.push_enabled isEqualToString:@"0"]) {
        [self.SwitchPushNoti setOn:NO];
    }else{
        [self.SwitchPushNoti setOn:YES];
    }
    
//    [self.tabBarController setSelectedIndex:1];
    [_btn_url1 addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    [_btn_url2 addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    [_tool_btn_left addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    _btn_url1.tag = 100;
    _btn_url2.tag = 101;
    _tool_btn_left.tag = 300;
    
    [_tool_btn_right addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    _tool_btn_right.tag = 200;
    
//    env.lastLogin
    
}
// handle button clicking on the screen.
-(IBAction)ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    switch (tag) {
        case 100:
        {
            NSString*path = @"http://www.share-a-success.com";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            break;
        }
        case 101:{
            NSString*path = @"http://www.share-a-success.com/tc.php?lang=";
            
            NSString *langID = [[NSLocale preferredLanguages] objectAtIndex:0];
            NSString *lang = [[NSLocale currentLocale] displayNameForKey:NSLocaleCountryCode value:langID];
            if (langID != nil && [langID length] >=2) {
                langID = [langID substringToIndex:2];
                path = [path stringByAppendingString:langID];
            }else{
                path = [path stringByAppendingString:@"en"];
            }
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            
            break;
        }
        case 200:{
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Alert" message:@"Do you want to log out?" preferredStyle:UIAlertControllerStyleAlert];
            
            UIAlertAction *ok = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action)
                                 {
                                     [self onTapLogoutButton:sender];
                                 }];
            UIAlertAction *cancel = [UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil];
            [alert addAction:cancel];
            [alert addAction:ok];
            [self presentViewController:alert animated:YES completion:nil];
            break;
        }
        case 300:{
            [self.navigationController popViewControllerAnimated:true];
            break;
        }
        default:
            break;
    }
}
-(void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = true;
    

    
   
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSArray*)findAllTextFieldsInView:(UIView*)view{
    NSMutableArray* textfieldarray = [[NSMutableArray alloc] init];
    for(id x in [view subviews]){
        if([x isKindOfClass:[UITextField class]])
            [textfieldarray addObject:x];
        
        if([x respondsToSelector:@selector(subviews)]){
            // if it has subviews, loop through those, too
            [textfieldarray addObjectsFromArray:[self findAllTextFieldsInView:x]];
        }
    }
    return textfieldarray;
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
// logout callback
- (IBAction)onTapLogoutButton:(id)sender {
    
    [appDelegate logOut];
}
// when user update his information.

- (IBAction)onTapSubmitButton:(id)sender {
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (self.textFieldFirstName.text.length == 0 || self.textFieldLastName.text.length == 0 || self.textFieldScreenName.text.length == 0 || self.textFieldEmail.text.length == 0 || self.textFieldPassword.text.length == 0 ) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_INFORMATION_EMPTY value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (![self.textFieldEmail.text isValidEmail]) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_INVALID_EMAIL value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    EnvVar* env = [CGlobal sharedId].env;
    
    NSString *firstname = self.textFieldFirstName.text;
    NSString *lastname = self.textFieldLastName.text;
    NSString *screenname = self.textFieldScreenName.text;
    NSString *email = self.textFieldEmail.text;
    NSString *password = self.textFieldPassword.text;
    
    NSString *publicdata = [NSString stringWithFormat:@"%d",(self.SwitchData.isOn ? 1:0)];
    NSString *push_enabled = [NSString stringWithFormat:@"%d",(self.SwitchPushNoti.isOn ? 1:0)];
    NSString * language = [[NSLocale preferredLanguages] objectAtIndex:0];
    
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    [dict setValue:env.custId forKey:@"custId"];
    [dict setValue:firstname forKey:@"Firstname"];
    [dict setValue:lastname forKey:@"Lastname"];
    [dict setValue:email forKey:@"emailAddress"];
    [dict setValue:password forKey:@"pwd"];
    [dict setValue:screenname forKey:@"screen"];
    [dict setValue:publicdata forKey:@"public_share"];
    [dict setValue:language forKey:@"language"];
    [dict setValue:push_enabled forKey:@"push_enabled"];
    [dict setValue:@"saveUser" forKey:@"action"];
    

    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager = [NetworkParser sharedManager];
    
    [manager generalNetwork:g_baseUrl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            // delete invite row
            EnvVar* env = [CGlobal sharedId].env;
            env.fname = firstname;
            env.lname = lastname;
            env.screen = screenname;
            env.email = email;
            env.password = password;
            env.public_share = publicdata;
            env.push_enabled = push_enabled;
            
            [env saveDefaults:@"fname" value:env.fname];
            [env saveDefaults:@"lname" value:env.lname];
            [env saveDefaults:@"password" value:env.password];
            [env saveDefaults:@"public_share" value:env.public_share];
            [env saveDefaults:@"screen" value:env.screen];
            
            [CGlobal AlertMessage:@"Save Success" Title:nil];
        }else{
            NSLog(@"Error Accept Invite");
        }
        [CGlobal stopIndicator:self Tag:nil];
    } method:@"POST"];
    
}

@end

@implementation NSString (emailValidation)

-(BOOL) isValidEmail
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:self];
}

@end
