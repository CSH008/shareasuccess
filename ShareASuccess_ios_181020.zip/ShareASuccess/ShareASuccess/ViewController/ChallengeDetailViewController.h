//
//  ChallengeDetailViewController.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

#import "TblChallenge.h"
#import "TblHealthData.h"
#import "ViewScrollContainer.h"

@class GrowingTextView;
/**
 Challenge Detail Screen
 **/
@interface ChallengeDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIAlertViewDelegate>

@property (weak, nonatomic) IBOutlet UIView *viewBar;
@property (weak, nonatomic) IBOutlet UIView *viewBarClone;


@property (strong, nonatomic) TblChallenge *challengeInfo;
@property (nonatomic,assign) CGFloat cellHeight;
@property (nonatomic,assign) int challengeType;
@property (nonatomic,strong) TblWinnerInfo *winnerinfo;

@property (strong, nonatomic) NSMutableDictionary *group_data;
@property (strong, nonatomic) NSMutableArray *listData;
@property (strong, nonatomic) TblHealthData *my_data;
@property (weak, nonatomic) IBOutlet UIView *viewGreen;

@property (weak, nonatomic) IBOutlet UIImageView *img_prev;
@property (weak, nonatomic) IBOutlet UIImageView *img_next;

@property (weak, nonatomic) IBOutlet UIImageView *imgSyncComplete;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol1;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol2;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol3;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol4;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol5;

@property (weak, nonatomic) IBOutlet UIView *viewSymbol1;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol2;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol3;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol4;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol5;

@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol1_c;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol2_c;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol3_c;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol4_c;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol5_c;

@property (weak, nonatomic) IBOutlet UIView *viewSymbol1_c;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol2_c;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol3_c;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol4_c;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol5_c;

@property (weak, nonatomic) IBOutlet UIView *viewAim1;
@property (weak, nonatomic) IBOutlet UIView *viewAim2;
@property (weak, nonatomic) IBOutlet UIView *viewAim3;
@property (weak, nonatomic) IBOutlet UIView *viewAim4;
@property (weak, nonatomic) IBOutlet UIView *viewAim5;
@property (weak, nonatomic) IBOutlet UIView *viewAim;

@property (weak, nonatomic) IBOutlet UILabel *labelAim;
@property (weak, nonatomic) IBOutlet UILabel *labelAim1;
@property (weak, nonatomic) IBOutlet UILabel *labelAim2;
@property (weak, nonatomic) IBOutlet UILabel *labelAim3;
@property (weak, nonatomic) IBOutlet UILabel *labelAim4;
@property (weak, nonatomic) IBOutlet UILabel *labelAim5;

@property (weak, nonatomic) IBOutlet UIView *viewAim1_c;
@property (weak, nonatomic) IBOutlet UIView *viewAim2_c;
@property (weak, nonatomic) IBOutlet UIView *viewAim3_c;
@property (weak, nonatomic) IBOutlet UIView *viewAim4_c;
@property (weak, nonatomic) IBOutlet UIView *viewAim5_c;
@property (weak, nonatomic) IBOutlet UIView *viewAim_c;

@property (weak, nonatomic) IBOutlet UILabel *labelAim_c;
@property (weak, nonatomic) IBOutlet UILabel *labelAim1_c;
@property (weak, nonatomic) IBOutlet UILabel *labelAim2_c;
@property (weak, nonatomic) IBOutlet UILabel *labelAim3_c;
@property (weak, nonatomic) IBOutlet UILabel *labelAim4_c;
@property (weak, nonatomic) IBOutlet UILabel *labelAim5_c;

@property (weak, nonatomic) IBOutlet UILabel *labelDesc;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITableView *tableView2;

@property (weak, nonatomic) IBOutlet UIButton *btnEdit;
@property (weak, nonatomic) IBOutlet UIImageView *imgEdit;
@property (weak, nonatomic) IBOutlet UIButton *btnDisable;
@property (weak, nonatomic) IBOutlet UIButton *btnNextDate;
@property (weak, nonatomic) IBOutlet UIButton *btnPrevDate;
@property (weak, nonatomic) IBOutlet UIButton *btnClose;
@property (weak, nonatomic) IBOutlet UIImageView *imgClose;

@property (weak, nonatomic) IBOutlet UIButton *btnPlusChat;
// 5C719C

@property (nonatomic,assign) BOOL can_goleft;
@property (nonatomic,assign) BOOL can_goright;


@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_right;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool1;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool2;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool3;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint* constraint_tableheight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint* constraint_scrollrootheight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint* constraint_topviewheight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_tableTopSpace;


@property (weak, nonatomic) IBOutlet UIView *viewRoot;

@property (weak, nonatomic) IBOutlet UIView* view_scrollroot;
@property (weak, nonatomic) IBOutlet UIView* view_top1;

@property (weak, nonatomic) IBOutlet UIView* contentView;

@property (nonatomic,copy) NSString *minDay;
@property (nonatomic,copy) NSString *maxDay;

@property (nonatomic,weak) IBOutlet UIButton* btn_setting;
@property (nonatomic,weak) IBOutlet UIButton* btn_editchat;

@property (nonatomic,weak) IBOutlet UIButton* btn_lock;
@property (nonatomic,weak) IBOutlet UIImageView* img_lock;
@property (nonatomic,weak) IBOutlet UIImageView* img_setting;
@property (weak, nonatomic) IBOutlet UIView *view_editchat;

@property (nonatomic,strong) IBOutlet UIButton* btnToday;
@property (nonatomic,strong) IBOutlet UIImageView* imgToday;


@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_bottom;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top_title;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top_for_keyboard_show;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top_for_keyboard_show_leading;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;

@property (nonatomic,weak) IBOutlet UILabel* lbl_headline0;
@property (nonatomic,weak) IBOutlet UILabel* lbl_headline1;
@property (nonatomic,weak) IBOutlet UILabel* lbl_headline2;
@property (nonatomic,weak) IBOutlet UILabel *lbl_headline3;
    
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;
@property (weak, nonatomic) IBOutlet UILabel *lbl_Type;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_aimBarHeight;



@property (weak, nonatomic) IBOutlet ViewScrollContainer *viewScrollContainer;
@property (weak, nonatomic) IBOutlet UIView *msgcontent_root;


@property (weak, nonatomic) IBOutlet UIView *inputToolbar;
@property (weak, nonatomic) IBOutlet GrowingTextView *textView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *textViewBottomConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_H_textview;
@property (weak, nonatomic) IBOutlet UIView *originalToolbar;

@property (weak, nonatomic) IBOutlet GrowingTextView *chat_msg;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_MsgContent_toBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_MessageContent_Height;

-(void)scrollToBottom;
@property (nonatomic,assign) CGFloat bottomOffset_input;

@property (weak, nonatomic) IBOutlet UIView *view_top2;
@property (weak, nonatomic) IBOutlet UIView *view_top3;
@property (weak, nonatomic) IBOutlet UIView *view_top3_clone;

@property (weak, nonatomic) IBOutlet UILabel *lbl_top_challenge;
@property (weak, nonatomic) IBOutlet UIView *viewNumberContainer;

@property (weak, nonatomic) IBOutlet UIView *viewCloseContainer;
@property (weak, nonatomic) IBOutlet UIView *viewToolRightContainer;
@property (weak, nonatomic) IBOutlet UIView *viewChatCloseContainer;
@property (weak, nonatomic) IBOutlet UIView *viewHeadCell1;

- (void)showNumberContent;
- (void)hideNumberContent;

@property (weak, nonatomic) IBOutlet UIStackView *tableView_Container;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_viewHeadCell1_Top;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_Msgcontent_TopMargin;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_viewHeadCell1_Height;


-(void)tapTableViewCell:(UITableViewCell*)cell;
-(void) updateData;

-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture;
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture;
@property (weak, nonatomic) IBOutlet UIImageView *toolbar_rightclose;
@property (weak, nonatomic) IBOutlet UIView *viewBack_plussign;

@property (weak, nonatomic) IBOutlet UIView *viewHeadCloseForKeyboardShow;
@property (weak, nonatomic) IBOutlet UIView *viewMaskBackground;
@property (weak, nonatomic) IBOutlet UIView *viewMaskBackground_Head;
@property (weak, nonatomic) IBOutlet UIView *viewTemp;


@property NSTimer *timerLoadingMessages;
@end






