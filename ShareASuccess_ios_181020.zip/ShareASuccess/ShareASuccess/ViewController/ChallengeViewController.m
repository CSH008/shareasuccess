	

//
//  ChallengeViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "ChallengeViewController.h"
#import "ChallengeDetailViewController.h"
#import "AddChallengeViewController.h"
#import "AddChallengeViewController.h"
#import "ChallengeCell.h"
#import "Utils.h"
#import "inc.h"
#import "AppDelegate.h"
#import "CGlobal.h"
#import "NetworkParser.h"
#import "BaseModel.h"
#import "ResponseMyInfo.h"
#import "TblHealthData.h"
#import "TblChallenge.h"
#import "TblInvitee.h"
#import "UIView+Animation.h"
#import "RefreshContent.h"
#import "InviteDialog.h"
#import "ProfileViewController.h"
#import "ChallengeOverTableViewCell.h"
#import "ShareASuccess-Swift.h"
#import "IQKeyboardManager.h"

#import "MyPopupDialog.h"
#import "HelpDialog.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <Photos/Photos.h>
#import <SDWebImage/UIImageView+WebCache.h>

@interface ChallengeViewController()

//  current main challenge day
@property (nonatomic,strong) NSMutableArray *listData;
@property (nonatomic,strong) TblHealthData *my_data;
@property (nonatomic,strong) NSMutableDictionary *group_data;
@property (nonatomic,assign) int nSelectedIndex;

@property (nonatomic,copy) NSString *minDay;
@property (nonatomic,copy) NSString *maxDay;

@property (nonatomic,assign) CGFloat startPosY;
@property (nonatomic,strong) RefreshContent*refreshContent;
@property (nonatomic,strong) UIView* noticeSync1;
@property (nonatomic,strong) UIView* noticeSync2;
@property (nonatomic,strong) UIView* noticeSync3;

@property (nonatomic,strong) InviteDialog* inviteDialog;

@property (nonatomic,assign) long challengeCountWithInvitees;
@property (nonatomic,strong) UIImage* selectedImage;


@property (nonatomic,strong) MyPopupDialog* dialog;
@end

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

@implementation ChallengeViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    
    
    _constraint_leading.constant = status_leading ;
    _constraint_trailing.constant = status_trailing;
//    _constraint_toolbar_bottom.constant = bottom_space+7.5;
    _constraint_toolbar_bottom.constant = (g_menuHeight - 24 ) /2;
    _constraint_toolbar_top_title.constant = top_space_toolbar_title;
    _constraint_first_top.constant = top_space - statusbar_gap1;
    
    _constraint_menu_height.constant = g_menuHeight;
    
    // update local db first
    
    [_lbl_headline1 setFont:defaultFont_Headline_Bold];
    [_lbl_headline2 setFont:defaultFont_Headline];
    //init vars
    _startPosY = 0;
    _activityIndicator.hidden = true;
    _imgSyncComplete.hidden = true;
    
    
    curDate = [NSDate date];
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Challenge" value:@"" table:nil];
    _tool_lbl_title1.text = temp;
    _tool_lbl_title1.text = @"";
    
    UINib* nib = [UINib nibWithNibName:@"ChallengeOverTableViewCell" bundle:nil];
    [_tableView registerNib:nib forCellReuseIdentifier:@"cell"];
    
    [_tableView setDelegate:self];
    _tableView.editing = true;
    [_tableView setDataSource:self];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(syncChangeStatus:) name:GLOBALNOTIFICATION_SYNC_CHANGESTATUS object:nil];
    
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    NSString*date_str = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    _listData = [delegate.dbManager getChallenges:date_str];
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(challengeListChanged:) name:GLOBALNOTIFICATION_CHALLENGELIST_CHANGED object:nil];
    
    UISwipeGestureRecognizer*swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeLeft:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionLeft];
    [_tableView addGestureRecognizer:swipe];
    
    swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeRight:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [_tableView addGestureRecognizer:swipe];
    
    UITapGestureRecognizer* tap1 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapTableView:)];
    [_tableView addGestureRecognizer:tap1];
    
    _refreshControl = [[UIRefreshControl alloc] init];
    _refreshControl.backgroundColor = [UIColor whiteColor];

    [_tableView addSubview:_refreshControl];
    
    [self loadCustomContent];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvNotice:) name:GLOBALNOTIFICATION_NOTICE object:nil];
    
    _label_startchallenge.text = [[NSBundle mainBundle] localizedStringForKey:@"Start here to create a new Challenge and to invite your friends." value:@"" table:nil];
    
    _can_goleft = true;
    _can_goright = true;
    _img_next.hidden = true;
    _img_prev.hidden = true;
    
    _img_refresh.hidden = true;
    _tool_btn_tool2.hidden = true;
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(customAppDidBecomeActive:) name:UIApplicationDidBecomeActiveNotification object:nil];
    
    _img_lock.hidden = true;
    
    _btnToday.hidden = true;
    _imgToday.hidden = true;
    [_btnToday addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    _btnToday.tag = 402;
    
    
    
    //[self checkHelpPage];
    
//    _lbl_b_Edit.text = [[NSBundle mainBundle] localizedStringForKey:@"b_Edit" value:@"" table:nil];
//    _lbl_b_Plus.text = [[NSBundle mainBundle] localizedStringForKey:@"b_Plus" value:@"" table:nil];
//    _lbl_b_Help.text = [[NSBundle mainBundle] localizedStringForKey:@"b_Help" value:@"" table:nil];
//    _lbl_b_Setting.text = [[NSBundle mainBundle] localizedStringForKey:@"b_Setting" value:@"" table:nil];
    
    _lbl_b_Edit.text = @" ";
    _lbl_b_Plus.text = @" ";
    _lbl_b_Help.text = @" ";
    _lbl_b_Setting.text = @" ";
    
    _tableView.backgroundColor = APP_COLOR_PRIMARY;
    
    EnvVar* env = [CGlobal sharedId].env;
    
    
    UIImage* image = [CGlobal localUserImage:env.custId];
    if (image!=nil) {
        _user_image.image = image;
        
        UIImageOrientation orient = image.imageOrientation;
        switch(orient) {
                
            case UIImageOrientationUp: //EXIF = 1
                
                break;
                
            case UIImageOrientationUpMirrored: //EXIF = 2
                
                break;
                
            case UIImageOrientationDown: //EXIF = 3
                
                break;
                
            case UIImageOrientationDownMirrored: //EXIF = 4
                
                break;
                
            case UIImageOrientationLeftMirrored: //EXIF = 5
                
                break;
                
            case UIImageOrientationLeft: //EXIF = 6
                
                break;
                
            case UIImageOrientationRightMirrored: //EXIF = 7
               
                break;
                
            case UIImageOrientationRight: //EXIF = 8
                
                break;
                
            default:
                break;
                
        }
    }
    
    
    [CGlobal getUserImage:env.custId Callback:^(UIImage *ret) {
        dispatch_async(dispatch_get_main_queue(), ^{
            _user_image.image = ret;
        });
    }];
    _lbl_name.text = env.screen;
     // APP_COLOR_BUTTON_PRIMARY
    [_btn_setting setImage:[CGlobal getColoredImage:@"ico_setting.png" Color:nil] forState:UIControlStateNormal];
    [_btn_help setImage:[CGlobal getColoredImage:@"ico_help.png" Color:nil] forState:UIControlStateNormal];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(recvMsg:) name:NOTIFICATION_RECEIVEMSG object:nil];
    
    self.view.backgroundColor = APP_COLOR_PRIMARY;
}
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NSLog(@"MAIN RRRRRRRRRRRRRR");
}
-(void)recvMsg:(NSNotification*)noti{
    NSLog(@"received Msg");
    if (noti.object!=nil) {
        if (noti.object[@"chat_model"]!=nil) {
            TblChat* model = noti.object[@"chat_model"];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                [self updateData];
            });
            
            
        }
    }
}
-(void)checkHelpPage{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    EnvVar* env = [CGlobal sharedId].env;
    NSString* h_version = env.historyVersion;
    
    //version = @"";
    if ([version isEqualToString:h_version]) {
        // same
    }else{
        // launch help
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        UIViewController*vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"HelpViewMixViewController"];
        [self.navigationController pushViewController:vc animated:true];
        env.historyVersion = version;
    }
    
}
// callback when App wake up
-(void)customAppDidBecomeActive:(NSNotification*)noti{
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    [delegate trySyncStart];
}
-(void)tapTableView:(UITapGestureRecognizer*)gesture{
    CGPoint touchPt = [gesture locationInView:self.tableView];
    NSIndexPath* path  = [self.tableView indexPathForRowAtPoint:touchPt];
    if (path!= nil) {
        [self tableView:self.tableView didSelectRowAtIndexPath:path];
    }
    
}
-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{
    if (_can_goright) {
        [self moveRight];
    }
}
-(void)gestureSwipeRight:(UISwipeGestureRecognizer*)gesture{
    if (_can_goleft) {
        [self moveLeft];
    }
}
-(void)viewDidAppear:(BOOL)animated{
    //
    AppDelegate* delegate = [UIApplication sharedApplication].delegate;
    if (delegate.launchData) {
        NSDictionary* userInfo = delegate.launchData;
        if (userInfo[@"aps"][@"type"]==nil) {
            return;
        }else{
            // {"aps":{"alert":"hello this is test chat messsage4","sound":"default","type":"4","r":{"i":"3","u":"2","n":"huangbo","t":"1533008762","c":"323"}}}
            int type = [userInfo[@"aps"][@"type"] intValue];
            if (type == 4) {
                //            long origin = UIApplication.sharedApplication.applicationIconBadgeNumber;
                //            UIApplication.sharedApplication.applicationIconBadgeNumber = origin + 1;
                
                id dict = userInfo[@"aps"][@"r"];
                TblChat *chat_model = [[TblChat alloc] initWithDictionaryABC:dict Encode:false];
                chat_model.msg = userInfo[@"aps"][@"alert"];
                [chat_model makeNotSeen];
                
                NSString*date_str = [CGlobal getDayPart1FromNSDate:[NSDate date] isGmt:useGmt];
                NSMutableArray*list = [delegate.dbManager getChallenges:date_str];
                TblChallenge* challenge = nil;
                for (int i=0; i<list.count; i++) {
                    TblChallenge* model = list[i];
                    if ([model.challenge_id intValue] == [chat_model.ch_id intValue]) {
                        // when equal save it
                        challenge = model;
                        break;
                    }
                }
                
                if (challenge!=nil) {
                    UIStoryboard* ms = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    
                    ChallengeDetailViewController *detail = [ms instantiateViewControllerWithIdentifier:@"ChallengeDetailViewController"];
                    
                    detail.challengeInfo = challenge;
                    
                    [self.navigationController pushViewController:detail animated:NO];
                }
            }
        }
        
        delegate.launchData = nil;
    }
    
    // off flag
    dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC);
    dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
        AppDelegate* delegate = [UIApplication sharedApplication].delegate;
        delegate.willShowChatWindow = false;
    });
}
- (void) viewWillAppear:(BOOL)animated {
    
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = true;
    
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
    
    EnvVar*env = [CGlobal sharedId].env;
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    
    if (delegate.launchData == nil) {
        switch (env.lastSyncStatus) {
            case GLOBAL_SYNC_FIRSTTIME:{
                g_indicator_mode = 1;
                [delegate getUserInformationFromServer];
                break;
            }
            default:{
                [self updateData];
                if (appDidBecomeActive_Status == 1) {
                    
                    appDidBecomeActive_Status = 2;
                    [delegate trySyncStart];
                }
                break;
            }
        }
        
        int tip_step = (int)env.tip_step;
        NSLog(@"Main viewWillAppear tipstep = %d",tip_step);
        switch (tip_step) {
            case 1:
            {
                if ([_noticeSync1 superview] == nil) {
                    [self showNotice:2];
                }
                break;
            }
            case 2:{
                if ([_noticeSync2 superview] == nil) {
                    [self showNotice:3];
                }
                break;
            }
            default:{
                //            [self showNotice:1];
                break;
            }
        }
    }
    
    
    
    
}
// callback When Sync Status Changed. Refresh the Views 
-(void)syncChangeStatus:(NSNotification*)noti{
    NSDictionary*userinfo = noti.object;
    if (userinfo!=nil) {
        int status = [userinfo[@"status"] intValue];
        switch (status) {
            case GLOBAL_SYNC_INITIAL:
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (_refreshControl.refreshing) {
                        [_refreshControl endRefreshing];
                        _refreshContent.labelSecond.text = @"";
                        _refreshContent.labelFirst.text = @"";
                    }
                    [self updateData];
                });
                break;
            }
            case GLOBAL_SYNC_COLLECTING:{
                break;
            }
            case GLOBAL_SYNC_COLLECTING_DONE:{
                dispatch_time_t popTime = dispatch_time(DISPATCH_TIME_NOW, 3 * NSEC_PER_SEC);
                dispatch_after(popTime, dispatch_get_main_queue(), ^(void){
                    EnvVar* env = [CGlobal sharedId].env;
                    if (env.lastSyncStatus == GLOBAL_SYNC_COLLECTING_DONE) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                            if (_refreshControl.refreshing) {
                                [_refreshControl endRefreshing];
                                _refreshContent.labelSecond.text = @"";
                                _refreshContent.labelFirst.text = @"";
                            }
                            [self updateData];
                        });
                    }
                });
                break;
            }
            case GLOBAL_SYNC_PUSHING:{
                break;
            }
            case GLOBAL_SYNC_PUSHING_DONE:{
                break;
            }
            case GLOBAL_SYNC_GETTING_MYINFO:{
                break;
            }
            default:
                break;
        }
    }
}

- (UIImage *)imageFromView:(UIView *)view cropSize:(CGSize)cropSize{
    UIGraphicsBeginImageContextWithOptions(cropSize, NO, [[UIScreen mainScreen] scale]);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextMoveToPoint(context, 0, 50);
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

// move the Date to previous and Refresh the View
-(void)moveLeft{
    curDate = [curDate dateByAddingTimeInterval:-24*60*60];
    [self setImageForSwipe];
    [self updateData];
    
    [_tableView slideInFromLeft:0.5 Delegate:nil Bounds:CGRectZero];
    
}
-(void)setImageForSwipe{
    CGFloat size_w = [UIScreen mainScreen].bounds.size.width;
    CGFloat size_h = [UIScreen mainScreen].bounds.size.height - 200 - _constraint_menu_height.constant;
    if (!self.navigationController.navigationBar.isHidden) {
        size_h = size_h - self.navigationController.navigationBar.frame.size.height;
    }
    CGSize size = CGSizeMake(size_w, size_h);
    UIImage* image = [self imageFromCollectionView:self.tableView cropSize:size];
    //    ((UIImageView*)self.view).image = image;
    self.imageForSwipe.image = image;
}
- (UIImage *)imageFromCollectionView:(UITableView *)view cropSize:(CGSize)cropSize{
    CGPoint contentOffset = view.contentOffset;
    UIGraphicsBeginImageContextWithOptions(cropSize, NO, [[UIScreen mainScreen] scale]);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextTranslateCTM(context, 0, -contentOffset.y);
    
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return image;
}

- (void)animationDidStop:(CAAnimation *)theAnimation finished:(BOOL)flag
{
    //do what you need to do when animation ends...
    if (flag) {
        NSLog(@"flag true");
    }
}
// move the Date to next and Refresh the View
-(void)moveRight{
    curDate = [curDate dateByAddingTimeInterval:24*60*60];
    [self setImageForSwipe];
    [self updateData];
    [_tableView slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    
//    UIImage* image = [self imageFromView:self.tableView cropSize:self.imgSnapView_ForTableView.frame.size];
//    self.imgSnapView_ForTableView.image = image;
//    [self.tableview_Container bringSubviewToFront:self.imgSnapView_ForTableView];
//    [self.imgSnapView_ForTableView slideInFromRight:0.5 Delegate:nil Bounds:CGRectZero];
    
}
// Click Function of the View Collections
-(IBAction) ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    switch (tag) {
        case 100:
        {
            //left
            [self moveLeft];
            break;
        }
        case 101:
        {
            [self moveRight];
            
            break;
        }
        case 200:{
            [_noticeSync1 removeFromSuperview];
            _noticeSync1.alpha = 0.0;
            break;
        }
        case 201:{
            [_noticeSync2 removeFromSuperview];
            _noticeSync2.alpha = 0.0;
            
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            [delegate trySyncStart];
            break;
        }
        case 202:{
            [_noticeSync3 removeFromSuperview];
            _noticeSync3.alpha = 0.0;
            
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            [delegate trySyncStart];
            break;
        }
        case 300:{
            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                     bundle: nil];
            
            UIViewController*vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"ProfileViewController"];
            [self.navigationController pushViewController:vc animated:true];
            
            
            break;
        }
        case 400:{
            //accept
            [self doInviteProcess:@"1"];
            
            break;
        }
        case 401:{
            //reject
            [self doInviteProcess:@"2"];
            
            break;
        }
        case 402:{
            curDate = [NSDate date];
            dispatch_async(dispatch_get_main_queue(), ^{
                [_tableview_Container slideInFromRight:0.3 Delegate:nil Bounds:CGRectZero];
                [self updateData];
            });
            break;
        }
        case 500:{

            self.dialog = [[MyPopupDialog alloc] init];
            NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"HelpDialog" owner:self options:nil];
            HelpDialog* helpView = (HelpDialog*)customViews[0];
            
            CGFloat sc_width = [UIScreen mainScreen].bounds.size.width;
            CGFloat sc_height = [UIScreen mainScreen].bounds.size.height;
            
            helpView.frame = CGRectMake(0, 0, fmaxf(sc_width - 50,300), fmaxf(sc_height - 170,450));
            NSLog(@"helpview width = %f height = %f",helpView.frame.size.width,helpView.frame.size.height);
            [helpView firstProcess:helpView.frame];
            [self.dialog setup:helpView backgroundDismiss:true backgroundColor:[CGlobal colorWithHexString:@"aaaaaa" Alpha:0.5]];
            
            [self.dialog showPopup:self.view];
            
            
            
//
//            UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
//                                                                     bundle: nil];
//
//            UIViewController*vc = [mainStoryboard instantiateViewControllerWithIdentifier:@"HelpViewMixViewController"];
//            [self.navigationController pushViewController:vc animated:true];
            
            
            break;
        }
        default:
            break;
    }
}
// When user accpet or reject invite, This is the process with the Server.
-(void)doInviteProcess:(NSString*)isAccept{
    
    TblInviteInfoData *inviteInfo = _inviteDialog.inviteData;
    TblInviteInfoData* clone = [TblInviteInfoData cloneThis:inviteInfo];
    
    NSString *url = [NSString stringWithFormat:@"https://share-a-success.com/tpw72betk/webservices.php?reqId=%@&status=%@&action=updateInvitationStatus", inviteInfo.reqId, isAccept];
    
    [_inviteDialog removeFromSuperview];
    
    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager = [NetworkParser sharedManager];
    [manager ontemplateGeneralRequestWithRawUrl:nil Path:url withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            // delete invite row
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            [delegate.dbManager deleteInviteeInfo:clone];
            
            NSMutableArray *array = [delegate.dbManager getInviteeInfo];
            if ([array count] == 0) {
                [delegate getUserInformationFromServer];
            }else{
                [_inviteDialog setData:array[0]];
                
                // add with effect
                [self.view addSubview:_inviteDialog];
                [self.view bringSubviewToFront:_inviteDialog];
                
                [UIView animateWithDuration:1 animations:^{
                    _inviteDialog.constraint_space_tobottom.constant = 0;
                    [_inviteDialog.view_root layoutIfNeeded];
                }];
            }
            
        }else{
            NSLog(@"Error Accept Invite");
        }
        [CGlobal stopIndicator:self Tag:nil];
    }];
}
// update the Screen based on the Current Selected Day.
-(void) updateData{
    NSLog(@"challengeviewcontroller updatedata");
    EnvVar* env = [CGlobal sharedId].env;
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    NSString*date_str = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    _listData = [delegate.dbManager getChallenges:date_str];
    _challengeCountWithInvitees = [delegate.dbManager getChallengeCountWithInvitees:date_str];
    
    _my_data = [delegate.dbManager getHealthData:curDate CustId:env.custId];
    if (_my_data == nil) {
        _my_data = [[TblHealthData alloc] initNull:env.custId Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
    }
    TblHealthData*my_data_t = [delegate.dbManager getHealthDataTo:curDate CustId:env.custId Mode:0];
    if (my_data_t!=nil) {
        _my_data.t_steps = my_data_t.steps;
        _my_data.t_walking = my_data_t.walking;
        _my_data.t_cycling = my_data_t.cycling;
        _my_data.t_standing = my_data_t.standing;
        _my_data.t_flights = my_data_t.flights;
        _my_data.t_active_cal = my_data_t.active_cal ;
        _my_data.t_swim = my_data_t.swim;
    }
    
    _group_data = [[NSMutableDictionary alloc] init];
    NSMutableArray* groupdids = [CGlobal getGroupIds:_listData];
    
    for (int i=0; i< [groupdids count]; i++) {
        NSString*custid = groupdids[i];
        TblHealthData*healthdata = [delegate.dbManager getHealthData:curDate CustId:custid];
        if (healthdata == nil) {
            healthdata = [[TblHealthData alloc] initNull:custid Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
        }
        TblHealthData*healthdata_t = [delegate.dbManager getHealthDataTo:curDate CustId:custid Mode:0];
        if (healthdata_t!=nil) {
            
            healthdata.t_steps = healthdata_t.steps;
            healthdata.t_walking = healthdata_t.walking;
            healthdata.t_cycling = healthdata_t.cycling;
            healthdata.t_standing = healthdata_t.standing;
            healthdata.t_flights = healthdata_t.flights;
            healthdata.t_active_cal = healthdata_t.active_cal ;
            healthdata.t_swim = healthdata_t.swim;
        }
        [healthdata checkForUse];
        [_group_data setValue:healthdata forKey:custid];
    }
    [_my_data checkForUse];
    
    
    //NSArray* my_float = [_my_data getHealthValues];
    const float my_CGFLOAT_MIN = -1000;
    
    for (int i=0; i<[_listData count]; i++) {
        TblChallenge* item = _listData[i];
        
        int type = [item.type intValue];
        if (type == 0) {
            // challenge
            NSLog(@"Challenging");
            NSArray* mydata_float = [_my_data getHealthValues];
            
            NSMutableArray* minValue_float = [[NSMutableArray alloc] initWithArray:@[[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX],[NSNumber numberWithFloat:CGFLOAT_MAX]]];
            
            NSMutableArray* maxValue_float = [[NSMutableArray alloc] initWithArray:@[[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN]]];
            
            NSMutableArray*otherids = [[NSMutableArray alloc] init];
            for (int j=0; j< [item.invitees count]; j++) {
                TblInvitee *invitee = item.invitees[j];
                if ([invitee.custid isEqualToString:env.custId]) {
                    continue;
                }
                [otherids addObject:invitee.custid];
            }
            if (![item.custId isEqualToString:env.custId]) {
                [otherids addObject:item.custId];
            }
            
            NSArray* item_series_int = [item getChallengeValues];
            for (int j=0; j<[otherids count]; j++) {
                NSString*cur_custid = otherids[j];
                TblHealthData*iData = [_group_data objectForKey:cur_custid];
                if (![item.custId isEqualToString:cur_custid]) {
                    for (int k=0; k<[item.invitees count]; k++) {
                        TblInvitee*invitee =  item.invitees[k];
                        if ([invitee.custid isEqualToString:cur_custid]) {
                            if ([invitee.status isEqualToString:@"0"]) {
                                iData = [[TblHealthData alloc] initNull:env.custId Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
                                NSLog(@"challengeid = %@  custid = %@",item.challenge_id,cur_custid);
                            }
                            break;
                        }
                    }
                }
                NSArray* idata_float = [iData getHealthValues];
                
                for (int p=0; p<item_series_int.count; p++) {
                    if ([item_series_int[p] intValue] == 1) {
                        float ivalue = [idata_float[p] floatValue];
                        if (ivalue>0) {
                            float minval = [minValue_float[p] floatValue];
                            float maxval = [maxValue_float[p] floatValue];
                            if (minval > ivalue) {
                                minval = ivalue;
                                minValue_float[p] = [NSNumber numberWithFloat:minval];
                            }
                            if (maxval < ivalue) {
                                maxval = ivalue;
                                maxValue_float[p] = [NSNumber numberWithFloat:maxval];
                            }
                        }
                    }
                    
                }
                
            }
            item.colors_my = [TblHealthData getDefaultColorsIndex];
            item.colors_gr = [TblHealthData getDefaultColorsIndex];
            
            if ([item.invitees count]>0) {
                for (int p=0; p<item_series_int.count; p++) {
                    if ([item_series_int[p] intValue] == 1) {
                        float ivalue = [mydata_float[p] floatValue];
                        float maxv = [maxValue_float[p] floatValue];
                        float minv = [minValue_float[p] floatValue];
                        if (maxv == my_CGFLOAT_MIN) {
                            item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                            if (ivalue>0) {
                                item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                            }else{
                                item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                            }
                            
                        }else{
                            if (minv == maxv) {
                                if (ivalue > maxv) {
                                    item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                    if (maxv>0) {
                                        item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_RED];
                                    }else{
                                        item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                                    }
                                    
                                }else if(ivalue< minv){
                                    if (ivalue>0) {
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_RED];
                                    }else{
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                                    }
                                    item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                }else{
                                    if (ivalue>0) {
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                        item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                    }else{
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                                        item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                                    }
                                    
                                }
                            }else{
                                if (ivalue >= maxv) {
                                    item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                    
                                    item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_RED];
                                }else if(ivalue<= minv){
                                    if (ivalue>0) {
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_RED];
                                    }else{
                                        item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                                    }
                                    item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                }else{
                                    item.colors_my[p] = [NSNumber numberWithInt:GLOBAL_COLOR_YELLOW];
                                    item.colors_gr[p] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                                }
                            }
                        }
                    }
                }
                
                
            }else{
                //item.colors_gr stay as it is
                for (int i=0; i< mydata_float.count; i++) {
                    if ([mydata_float[i] floatValue] <= 0) {
                        item.colors_my[i] = [NSNumber numberWithInt:GLOBAL_COLOR_NOCOLOR];
                    }else{
                        item.colors_my[i] = [NSNumber numberWithInt:GLOBAL_COLOR_GREEN];
                    }
                }
            }
        }else{
            // aim
            NSLog(@"Aim");
            
            int aim_type = [item.aim_type intValue];
            NSArray* aim_Values_float = [item getAimValues];
            
            
            NSMutableArray*otherids = [[NSMutableArray alloc] init];
            for (int j=0; j< [item.invitees count]; j++) {
                TblInvitee *invitee = item.invitees[j];
                if ([invitee.custid isEqualToString:env.custId]) {
                    continue;
                }
                [otherids addObject:invitee.custid];
            }
            if (![item.custId isEqualToString:env.custId]) {
                [otherids addObject:item.custId];
            }
            
            NSMutableArray* maxValues_float = [[NSMutableArray alloc] initWithArray:@[[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN],[NSNumber numberWithFloat:my_CGFLOAT_MIN]]];
            
            
            for (int j=0; j<[otherids count]; j++) {
                NSString*cur_custid = otherids[j];
                TblHealthData*iData = [_group_data objectForKey:cur_custid];
                if (![item.custId isEqualToString:cur_custid]) {
                    for (int k=0; k<[item.invitees count]; k++) {
                        TblInvitee*invitee =  item.invitees[k];
                        if ([invitee.custid isEqualToString:cur_custid]) {
                            if ([invitee.status isEqualToString:@"0"]) {
                                iData = [[TblHealthData alloc] initNull:env.custId Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
                                NSLog(@"challengeid = %@  custid = %@",item.challenge_id,cur_custid);
                            }
                            break;
                        }
                    }
                }
                NSArray*iValues_float;
                if (aim_type == 0) {
                    iValues_float = [iData getHealthValues];
                }else{
                    iValues_float = [iData getTotalHealthValues];
                }
                for (int k = 0; k<iValues_float.count; k++) {
                    float ivalue = [iValues_float[k] floatValue];
                    float mvalue = [maxValues_float[k] floatValue];
                    if (mvalue < ivalue) {
                        maxValues_float[k] = [NSNumber numberWithFloat:ivalue];
                    }
                }
            }
            
            NSArray* my_Values_float;
            if (aim_type == 0) {
                my_Values_float = [_my_data getHealthValues];
            }else{
                my_Values_float = [_my_data getTotalHealthValues];
            }
            
            
            NSArray* color_my_values = [ChallengeViewController calculateColorForAim:my_Values_float Aim:aim_Values_float];
            NSArray* color_gr_values = [ChallengeViewController calculateColorForAim:maxValues_float Aim:aim_Values_float];
            
            if ([item.invitees count]>0) {
                item.colors_my = [[NSMutableArray alloc] initWithArray:color_my_values];
                item.colors_gr = [[NSMutableArray alloc] initWithArray:color_gr_values];
            }else{
                
                item.colors_my = [[NSMutableArray alloc] initWithArray:color_my_values];
                item.colors_gr = [TblHealthData getDefaultColorsIndex];
                
            }
            
        }
        
        
    }
    NSMutableArray* maxminDays = [delegate.dbManager getMaxMinDay];
    if ([maxminDays count] == 2) {
        _maxDay = maxminDays[0];
        _minDay = maxminDays[1];
        
        _maxDay = [CGlobal getDayPart1:_maxDay];
        _minDay = [CGlobal getDayPart1:_minDay];
    }
    NSString* challenge_startday = nil;
    for (TblChallenge* item in _listData) {
        if (challenge_startday == nil) {
            if ([item.custId isEqualToString:env.custId]) {
                challenge_startday = [CGlobal getDayPart1:item.date_added];
            }else{
                for (TblInvitee*invitee in item.invitees) {
                    if ([invitee.custid isEqualToString:env.custId]) {
                        challenge_startday = [CGlobal getDayPart1:invitee.accepted_date];
                        break;
                    }
                }
                
            }
            continue;
        }
        NSString* day = nil;
        if ([item.custId isEqualToString:env.custId]) {
            day = [CGlobal getDayPart1:item.date_added];
        }else{
            for (TblInvitee*invitee in item.invitees) {
                if ([invitee.custid isEqualToString:env.custId]) {
                    day = [CGlobal getDayPart1:invitee.accepted_date];
                    break;
                }
            }
            
        }
        if ([day compare:challenge_startday] == NSOrderedAscending) {
            challenge_startday = day;
        }
    }
    if ([_minDay compare:challenge_startday] == NSOrderedAscending) {
        _minDay = challenge_startday;
    }
    
    
    [self updateToolBar];
    
    [self updateToolbarApperance];
    
    
    NSMutableArray*invite_array = [delegate.dbManager getInviteeInfo];
    if ([invite_array count] > 0) {
        NSLog(@"INVITE COUNT %lu",(unsigned long)invite_array.count);
        TblInviteInfoData* inviteData = invite_array[0];
        [_inviteDialog setData:inviteData];
        if ([_inviteDialog superview] != nil) {
            [_inviteDialog setData:inviteData];
        }else{
            [_inviteDialog setData:inviteData];
            
            // add with effect
            [self.view addSubview:_inviteDialog];
            [self.view bringSubviewToFront:_inviteDialog];
            
            [UIView animateWithDuration:1 animations:^{
                _inviteDialog.constraint_space_tobottom.constant = 0;
                [_inviteDialog.view_root layoutIfNeeded];
            }];
        }
    }else{
        if ([_inviteDialog superview]!=nil) {
            [_inviteDialog removeFromSuperview];
        }
    }
    
    [_tableView reloadData];
}
// Update Top Toolbar visible or unvisible, because if no challenges, show another Toolbar.
-(void)updateToolbarApperance{
    if (_challengeCountWithInvitees == 0) {
        _view_toolbar2.hidden = true;
        _view_root1.hidden = true;
        _view_root2.hidden = false;
        
        // blue                 5C719C
        // toolbartint          A8B7AA
        _view_top.backgroundColor = [CGlobal colorWithHexString:@"A8B7AA" Alpha:1.0f];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_TOOLBAR_CHANGE object:@"1"];
        
    }else{
        _view_toolbar2.hidden = false;
        _view_root1.hidden = false;
        _view_root2.hidden = true;
        
        _view_top.backgroundColor = [CGlobal colorWithHexString:@"5C719C" Alpha:1.0f];
        [[NSNotificationCenter defaultCenter] postNotificationName:NOTIFICATION_TOOLBAR_CHANGE object:@"0"];
    }
    EnvVar* env = [CGlobal sharedId].env;
    env.lastChallengeCount = _challengeCountWithInvitees;
}
// Update the status whether can swipe right or left. and Challenge Day Text on the toolbars.
-(void)updateToolBar{
    NSString* day = [CGlobal getDayPart1FromNSDate:curDate isGmt:useGmt];
    if ([day compare:_maxDay] == NSOrderedAscending) {
        _can_goright = true;
        _img_next.image = [UIImage imageNamed:@"btn_next"];
    }else{
        _can_goright = false;
        _img_next.image = [UIImage imageNamed:@"btn_next_disabled"];
    }
    
    if ([day compare:_minDay] == NSOrderedDescending) {
        _can_goleft = true;
        _img_prev.image = [UIImage imageNamed:@"btn_prev"];
    }else{
        _can_goleft = false;
        _img_prev.image = [UIImage imageNamed:@"btn_prev_disabled"];
    }
    
    
    _tool_lbl_title1.text = @"";
    
    day = [CGlobal getDayPart2FromNSDate:curDate isGmt:useGmt];
    NSString* dayofweek = [CGlobal getDayofWeekFromNSDate:curDate isGmt:useGmt];
    _lbl_headline1.text = [[NSBundle mainBundle] localizedStringForKey:@"Overview" value:@"" table:nil];
//    _lbl_headline1.text = @"";
    _lbl_headline2.text = [NSString stringWithFormat:@"%@ %@",dayofweek,day];
    _lbl_weekday.text = dayofweek;
    _lbl_date.text = day;
   
    // update img lock
    NSDate*date = [NSDate date];
    NSDate*monday = [CGlobal getFirstDay:date isGmt:useGmt];
    monday = [monday dateByAddingTimeInterval:-1*24*60*60];
    NSTimeInterval interval = [curDate timeIntervalSinceDate:monday];
    if (interval>0) {
        _img_lock.hidden = true;
    }else{
        _img_lock.hidden = false;
//        _img_lock.backgroundColor = [UIColor blackColor];
    }
    
    if([CGlobal isToday:curDate isGmt:useGmt]){
        _btnToday.hidden = true;
        _imgToday.hidden = true;
    }else{
        _btnToday.hidden = false;
        _imgToday.hidden = false;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onTapRefreshButton:(id)sender {
    AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
    [delegate trySyncStart];
}
-(void)challengeListChanged:(NSNotification*)noti{
    NSLog(@"challengeListChanged");
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateData];
    });
}
// Function to show Guide Views when the app is at the first time.
-(void) showNotice:(int)number{
    return;
    switch (number) {
        case 1:
        {
            [_view_root1 addSubview:_noticeSync1];
            [_view_root1 bringSubviewToFront:_noticeSync1];
            
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationCurve:1.5];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            
            [_noticeSync1 setAlpha:1.0];
            
            [UIView commitAnimations];
            
            EnvVar* env = [CGlobal sharedId].env;
            env.tip_step = 1;
            break;
            
        }
        case 2:{
            [_view_root1 addSubview:_noticeSync2];
            [_view_root1 bringSubviewToFront:_noticeSync2];
            
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationCurve:1.5];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            
            [_noticeSync2 setAlpha:1.0];
            
            [UIView commitAnimations];
            
            EnvVar* env = [CGlobal sharedId].env;
            env.tip_step = 2;
            break;
        }
        case 3:{
            [_view_root1 addSubview:_noticeSync3];
            [_view_root1 bringSubviewToFront:_noticeSync3];
            
            [UIView beginAnimations:nil context:nil];
            [UIView setAnimationCurve:1.5];
            [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
            
            [_noticeSync3 setAlpha:1.0];
            
            [UIView commitAnimations];
            
            
            EnvVar* env = [CGlobal sharedId].env;
            env.tip_step = 3;
        }
        default:
            break;
    }
}
// When user click + button on the Toolbar.
- (IBAction)onTapAddButton:(id)sender {
    if ([_listData count] == 0) {
        UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"Main"
                                                                 bundle: nil];
        
        AddChallengeViewController*navigationController = (AddChallengeViewController *)[mainStoryboard instantiateViewControllerWithIdentifier:@"AddChallengeViewController"];
        
        navigationController.presentMode = @"1";
        [self presentViewController:navigationController animated:false completion:^{
            
        }];
    }else{
        [self performSegueWithIdentifier:SEGUE_CHALLENGE_TO_ADDCHALLENGE sender:self];
    }
    
}
#pragma mark - SCroll delegate
// Scroll View Scroll Delegate.  When user reaches to top, we sync the system.
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (_refreshControl.refreshing) {
        EnvVar* env = [CGlobal sharedId].env;
        if (env.lastSyncStatus == GLOBAL_SYNC_INITIAL || env.lastSyncStatus == GLOBAL_SYNC_COLLECTING_DONE) {
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            if (env.lastMySyncDay == nil) {
                [delegate pushLocalDbToServer];
                [_refreshControl endRefreshing];
                return;
            }else{
                NSLog(@"It's time!!");
                
                NSString*syncTime = [CGlobal getDayofWeekFromNSString:env.lastMySyncDay isGmt:useGmt];
                NSString* localized_lastsync = [[NSBundle mainBundle] localizedStringForKey:@"Last sync: %@" value:@"" table:nil];
                NSString* localized_syncing = [[NSBundle mainBundle] localizedStringForKey:@"Syncing" value:@"" table:nil];
                //
                _refreshContent.labelFirst.text = [NSString stringWithFormat:localized_lastsync,syncTime];
                _refreshContent.labelSecond.text = localized_syncing;
                //
                
                [delegate trySyncStart];
            }
        }
        
        
    }
    
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return _listData.count;   //TODO: Need to change this to be dynamic
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ChallengeOverTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    TblChallenge *challengeInfo = _listData[indexPath.row];
    
    [cell setDataForTblChallenge:challengeInfo];
    
//    cell.showsReorderControl = YES;
    if ([challengeInfo.type intValue] == 0) {
        cell.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
    }else{
        cell.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
    }
    
//    UIImage *background = [self cellBackgroundForRowAtIndexPath:indexPath];
//    UIImageView *cellBackgroundView = [[UIImageView alloc] initWithImage:background];
//    cellBackgroundView.image = background;
//    cell.backgroundView = cellBackgroundView;
    
    return cell;
}
- (UIImage *)cellBackgroundForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger rowCount = [self tableView:[self tableView] numberOfRowsInSection:0];
    NSInteger rowIndex = indexPath.row;
    UIImage *background = nil;
    
//    if (rowIndex == 0) {
//        background = [UIImage imageNamed:@"cell_top.png"];
//    } else if (rowIndex == rowCount - 1) {
//        background = [UIImage imageNamed:@"cell_bottom.png"];
//    } else {
//        background = [UIImage imageNamed:@"cell_middle.png"];
//    }
    background = [UIImage imageNamed:@"ico_new.png"];
    
    return background;
}
-(CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    //return 143;
    //return 143 - 25;
    return 144;
}
- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    _nSelectedIndex = indexPath.row;
    [self performSegueWithIdentifier:SEGUE_CHALLENGE_TO_CHALLENGEDETAIL sender:self];
}
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return YES;
}
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)sourceIndexPath toIndexPath:(NSIndexPath *)destinationIndexPath {
    id stringToMove = [self.listData objectAtIndex:sourceIndexPath.row];
    [self.listData removeObjectAtIndex:sourceIndexPath.row];
    [self.listData insertObject:stringToMove atIndex:destinationIndexPath.row];
    
    [self onSortDone:nil];
//    _didChanged = true;
}
- (IBAction)onSortDone:(id)sender {
    
    EnvVar* env = [CGlobal sharedId].env;
    
    NSURLComponents *components = [NSURLComponents componentsWithString:@"https://share-a-success.com/tpw72betk/webservices.php?"];
    
    NSMutableArray *queryItems = [NSMutableArray array];
    [queryItems addObject:[NSURLQueryItem queryItemWithName:@"custId" value:[NSString stringWithFormat:@"%@",env.custId]]];
    [queryItems addObject:[NSURLQueryItem queryItemWithName:@"action" value:@"SetChallengeListForSorting"]];
    
    for (int i =0 ; i < self.listData.count; i++) {
        TblChallenge* item = self.listData[i];
        NSString *keyData = [NSString stringWithFormat:@"data[%i][id]",i];
        NSString *valueData = item.challenge_id;
        
        NSString *keyData1 = [NSString stringWithFormat:@"data[%i][display_order]",i];
        NSString *valueData1 = [NSString stringWithFormat:@"%i",i+1];
        
        [queryItems addObject:[NSURLQueryItem queryItemWithName:keyData value:valueData]];
        [queryItems addObject:[NSURLQueryItem queryItemWithName:keyData1 value:valueData1]];
    }
    components.queryItems = queryItems;
    NSURL *url = components.URL;
    NSString* urlString = [url absoluteString];
    
    NetworkParser* manager = [NetworkParser sharedManager];
    [manager ontemplateGeneralRequestWithRawUrl:nil Path:urlString withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            AppDelegate* delegate = UIApplication.sharedApplication.delegate;
            for (int i =0 ; i < self.listData.count; i++) {
                TblChallenge* item = self.listData[i];
                TblSortInfo*info = [[TblSortInfo alloc] init];
                info.display_order = i;
                info.id = item.challenge_id;
                
                
                NSString*query = [BaseModel getUpdateSql:info TableName:@"tbl_order" WhereField:@"id" WhereValue:info.id];
                [delegate.dbManager executeQuery:query];
            }
        }else{
            
        }
    }];
}
- (void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    TblChallenge *challengeInfo = _listData[indexPath.row];
    for(UIView* view in cell.subviews)
    {
        NSLog(@"%@",[[view class] description]);
        NSString* desc = [[view class] description];
        if([[[view class] description] isEqualToString:@"UITableViewCellReorderControl"])
        {
            
            CGSize iconsize = CGSizeMake(22, 19);
            CGSize moveRight = CGSizeMake(0, 0);
            for(UIImageView* viewFive in view.subviews) {
                
                
                CGRect imgRect = viewFive.frame;
                NSLog(@"x=%f y=%f width=%f  height=%f",imgRect.origin.x,imgRect.origin.y,imgRect.size.width,imgRect.size.height);
                imgRect.size.width = iconsize.width;
                imgRect.size.height = iconsize.height;
                imgRect.origin.y = 0;
                //viewFive.image = [CGlobal getColoredImageFromImage:viewFive.image Color:[UIColor redColor]];
                
                viewFive.frame = imgRect;
                viewFive.hidden = true;
                
                UIView* superview1 = [viewFive superview];
                CGRect superRect = superview1.frame;
                NSLog(@"ReorderControl x=%f y=%f width=%f  height=%f",superRect.origin.x,superRect.origin.y,superRect.size.width,superRect.size.height);
                
                moveRight = CGSizeMake(superRect.size.width - imgRect.origin.x - imgRect.size.width, 0);
                
                NSLog(@"Offset width=%f  height=%f",moveRight.width,moveRight.height);
            }
            
            
            // Creates a new subview the size of the entire cell
            CGRect rt1 = CGRectMake(0, 0, CGRectGetMaxX(view.frame), CGRectGetMaxY(view.frame));
            rt1.size.height = 22;
            rt1.origin.y = 6;
//            rt1.origin.y = 64;
            CGRect rt2 = view.frame;
            UIView *movedReorderControl = [[UIView alloc] initWithFrame:rt1];
            // Adds the reorder control view to our new subview
            [movedReorderControl addSubview:view];
            // Adds our new subview to the cell
            [cell addSubview:movedReorderControl];
//            movedReorderControl.backgroundColor = [CGlobal colorWithHexString:@"ff0000" Alpha:0.7];
//            movedReorderControl.backgroundColor = [UIColor colorWithRed:1.0 green:1.0 blue:0 alpha:0.7];
            movedReorderControl.backgroundColor = [UIColor clearColor];
            
            CGAffineTransform transform = CGAffineTransformIdentity;
            transform = CGAffineTransformTranslate(transform, moveRight.width - status_leading, moveRight.height);
            // Performs the transform
            [movedReorderControl setTransform:transform];
            
//            if ([challengeInfo.type intValue] == 0) {
//                view.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
//            }else{
//                view.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
//            }
        }
        
//        if ([desc isEqualToString:@"UITableViewCellContentView"]) {
//            view.backgroundColor = [UIColor colorWithRed:0 green:0.0 blue:1.0 alpha:0.7];
////            view.frame = CGRectMake(-100, 0, cell.frame.size.width,cell.frame.size.height);
////            NSLog(@"");
//        }else if ([desc isEqualToString:@"_UITableViewCellSeparatorView"]) {
//            view.backgroundColor = [UIColor colorWithRed:0 green:1.0 blue:1.0 alpha:0.7];
//        }else if ([desc isEqualToString:@"UITableViewCellEditControl"]) {
//            view.backgroundColor = [UIColor colorWithRed:0 green:1.0 blue:0 alpha:0.7];
////            [cell sendSubviewToBack:view];
//        }else if ([desc isEqualToString:@"UIView"]) {
//            view.backgroundColor = [UIColor colorWithRed:1.0 green:0 blue:0 alpha:0.7];
//        }

        view.backgroundColor = [UIColor clearColor];

        NSLog(@"%f %f %f %f",view.frame.origin.x,view.frame.origin.y,view.frame.size.width,view.frame.size.height);
    }
    
    NSLog(@"hi");
    
//    if ([challengeInfo.type intValue] == 0) {
//        cell.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
//    }else{
//        cell.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
//    }
}
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleNone;
}
#pragma -mark - Segue
- (void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:SEGUE_CHALLENGE_TO_CHALLENGEDETAIL]) {
        ChallengeDetailViewController *detail = (ChallengeDetailViewController *)segue.destinationViewController;
        //NSLog(@"%@",[challengeArray objectAtIndex:nSelectedIndex]);
        detail.challengeInfo = _listData[_nSelectedIndex];
        detail.group_data = _group_data;
        
        
    } else if ([segue.identifier isEqualToString:SEGUE_CHALLENGE_TO_ADDCHALLENGE]) {
        AddChallengeViewController *add = (AddChallengeViewController *)segue.destinationViewController;
        
    }
}

#pragma -mark -refresh
// initialize the views like guide views, invite dialog from xib.
-(void)loadCustomContent{
    NSArray* customViews= [[NSBundle mainBundle] loadNibNamed:@"RefreshContent" owner:self options:nil];
    
    _refreshContent = (RefreshContent*)customViews[0];
    _refreshContent.frame = _refreshControl.bounds;
    
    [_refreshControl addSubview:_refreshContent];
    
    _refreshContent.backgroundColor = APP_COLOR_PRIMARY;
    
    _refreshContent.labelFirst.text = @"";
    _refreshContent.labelSecond.text = @"";
    
    customViews =[[NSBundle mainBundle] loadNibNamed:@"NoticeSync" owner:self options:nil];
    
    _noticeSync1 = customViews[0];
    _noticeSync2 = customViews[1];
    _noticeSync3 = customViews[2];

    _noticeSync1.alpha = 0.0;
    _noticeSync2.alpha = 0.0;
    _noticeSync3.alpha = 0.0;
    
    CGRect rect = [[UIScreen mainScreen] bounds];
    
    CGPoint center = CGPointMake(rect.size.width/2, (rect.size.height-g_menuHeight)/2);
    _noticeSync1.frame = CGRectMake(0, 0, rect.size.width, rect.size.height-g_menuHeight);
    _noticeSync1.center = center;
    
    _noticeSync2.frame = CGRectMake(0, 0, rect.size.width, rect.size.height-g_menuHeight);
    _noticeSync2.center = center;
    
    _noticeSync3.frame = CGRectMake(0, 0, rect.size.width, rect.size.height-g_menuHeight);
    _noticeSync3.center = center;
    
    UIButton* button = (UIButton*) [_noticeSync1 viewWithTag:200];
    [button addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = 200;
    [ChallengeViewController makeStyle1:button];
    
    button = (UIButton*) [_noticeSync2 viewWithTag:200];
    [button addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = 201;
    [ChallengeViewController makeStyle1:button];
    
    button = (UIButton*) [_noticeSync3 viewWithTag:200];
    [button addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    button.tag = 202;
    [ChallengeViewController makeStyle1:button];
    
    
    customViews =[[NSBundle mainBundle] loadNibNamed:@"InviteDialog" owner:self options:nil];
    _inviteDialog = customViews[0];
    
    
    CGFloat statusbar_height = [[UIApplication sharedApplication] statusBarFrame].size.height;
    _inviteDialog.frame = CGRectMake(0, statusbar_height, rect.size.width, rect.size.height - statusbar_height);
    
    [_inviteDialog initProc];
    _inviteDialog.btn_accept.tag = 400;
    _inviteDialog.btn_reject.tag = 401;
    
    [CGlobal makeStyle1:_inviteDialog.btn_accept Mode:0];
    [CGlobal makeStyle1:_inviteDialog.btn_reject Mode:0];
    
    [_inviteDialog.btn_accept addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    [_inviteDialog.btn_reject addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
}
+ (void)makeStyle1:(UIView*)controller{
    CGRect rect = controller.frame;
    CGFloat halfheight = rect.size.height/2;
    controller.layer.cornerRadius = halfheight;
    controller.layer.masksToBounds = true;
    controller.layer.backgroundColor = [[CGlobal colorWithHexString:@"4F6386" Alpha:1.0f] CGColor];//5C719C 4F6386
}
-(void)recvNotice:(NSNotification*) noti{
    id obj = noti.object;
    if (obj!=nil && [obj isKindOfClass:[NSDictionary class]]) {
        NSDictionary* obj_dict = (NSDictionary*)obj;
        NSString* notice = obj_dict[@"notice"];
        int notice_val = [notice intValue];
        [self showNotice:notice_val];
    }
}

+(NSArray*)calculateColorForAim:(NSArray*)myValues Aim:(NSArray*)aimValues{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    for (int i=0; i<myValues.count; i++) {
        float myValue = [myValues[i] floatValue];
        float aimValue = [aimValues[i] floatValue];
        
        float aim80Value = aimValue*0.8;
        int color = 0;
        if (myValue>0 && myValue <= aim80Value) {
            color = GLOBAL_COLOR_RED;
        }else if(myValue>aim80Value && myValue< aimValue){
            color = GLOBAL_COLOR_YELLOW;
        }else if(myValue >= aimValue){
            color = GLOBAL_COLOR_GREEN;
        }else{
            color = GLOBAL_COLOR_NOCOLOR;
        }
        
        [ret addObject:[NSNumber numberWithInt:color]];
    }
    return ret;
}
+(NSArray*)calculateBackColorForAim:(NSArray*)myValues Aim:(NSArray*)aimValues{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    for (int i=0; i<myValues.count; i++) {
        float myValue = [myValues[i] floatValue];
        float aimValue = [aimValues[i] floatValue];
        
        float aim80Value = aimValue*0.8;
        UIColor* color = APP_COLOR_DETAIL3;
        if (myValue>0 && myValue <= aim80Value) {
            color = APP_COLOR_DETAIL_BACKRED;
        }else if(myValue>aim80Value && myValue< aimValue){
            color = APP_COLOR_DETAIL_BACKYELLOW;
        }else if(myValue >= aimValue){
            color = APP_COLOR_DETAIL_BACKGREEN;
        }else{
            color = APP_COLOR_DETAIL3;
        }
        
        [ret addObject:color];
    }
    return ret;
}
- (IBAction)tapAvatar:(id)sender {
    UIAlertController* uac = [[UIAlertController alloc] init];
    UIAlertAction* ac1 = [UIAlertAction actionWithTitle:@"Take a Photo" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self clickCamera:nil];
    }];
    
    UIAlertAction* ac2 = [UIAlertAction actionWithTitle:@"Choose from Gallery" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        [self clickGallery:nil];
    }];
    
    UIAlertAction* ac3 = [UIAlertAction actionWithTitle:@"Close" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
    }];
    
    [uac addAction:ac1];
    [uac addAction:ac2];
    [uac addAction:ac3];
    
    [self presentViewController:uac animated:true completion:nil];
}

#pragma -mark ImagePicker
-(void)goImage:(UIImage*)image{
    AppDelegate* delegate = (AppDelegate*)[UIApplication sharedApplication].delegate;
    NetworkStatus internetStatus = [delegate.reachability currentReachabilityStatus];
    if (internetStatus == NotReachable) {
        return;
    }
    
    
    NSString* filename = [NSString stringWithFormat:@"user%ld.jpg",[CGlobal sharedId].env.lastLogin];
    
    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager = [NetworkParser sharedManager];
    [manager uploadImage:image FileName:filename withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            // update user image
            [self updateProfileImage:filename];
            return;
        }else{
            
        }
        [CGlobal stopIndicator:self Tag:nil];
    }];
}
-(void)updateProfileImage:(NSString*)filename{
    EnvVar* env = [CGlobal sharedId].env;
    
    NetworkParser* manager = [NetworkParser sharedManager];
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    [dict setValue:env.custId forKey:@"custId"];
    [dict setValue:filename forKey:@"filename"];
    
    [manager generalNetwork:g_baseUrl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            // delete invite row
            EnvVar* env = [CGlobal sharedId].env;
            env.profile_image = filename;
            self.user_image.image = _selectedImage;
            
            NSString* filename = [NSString stringWithFormat:@"user%@.jpg",env.custId ];
            [CGlobal saveImage:_selectedImage FileName:filename];
            //[CGlobal AlertMessage:@"Save Success" Title:nil];
        }else{
            NSLog(@"Error Accept Invite");
        }
        [CGlobal stopIndicator:self Tag:nil];
    } method:@"POST"];
}
-(void) imagePickerController:(UIImagePickerController*) picker didFinishPickingMediaWithInfo:(nonnull NSDictionary<NSString *,id> *)info
{
    
    UIImage * pickedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    
    if (pickedImage == nil) {
        NSURL* url = [info objectForKey:UIImagePickerControllerReferenceURL];
        
        ALAssetsLibrary *assetLibrary=[[ALAssetsLibrary alloc] init];
        [assetLibrary assetForURL:url resultBlock:^(ALAsset *asset) {
            ALAssetRepresentation *rep = [asset defaultRepresentation];
            
            CGImageRef iref = [rep fullScreenImage];
            if (iref) {
                UIImage* image = [UIImage imageWithCGImage:iref];
                _selectedImage = image;
                
                [picker dismissViewControllerAnimated:YES completion:nil];
                
                [self goImage:_selectedImage];
                
            }
        } failureBlock:^(NSError *err) {
            NSLog(@"Error: %@",[err localizedDescription]);
        }];
    }else{
        _selectedImage = pickedImage;
        
        [picker dismissViewControllerAnimated:YES completion:nil];
        
        [self goImage:_selectedImage];
        
    }
    
}
-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [picker dismissViewControllerAnimated:true completion:nil];
}
- (IBAction)clickCamera:(id)sender {
    [CGlobal grantedPermissionCamera:^(BOOL ret) {
        if (ret) {
            UIImagePickerController *picker = [[UIImagePickerController alloc] init];
            if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
                picker.allowsEditing = false;
                picker.sourceType = UIImagePickerControllerSourceTypeCamera;
                picker.cameraCaptureMode = UIImagePickerControllerCameraCaptureModePhoto;
                picker.delegate = self;
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self presentViewController:picker animated:true completion:nil];
                });
                
            }else{
                [CGlobal AlertMessage:@"No Camera" Title:nil];
            }
        }else{
            [CGlobal AlertMessage:@"To continue ,please enable ShareASuccess's access to your Device Camera" Title:nil];
        }
    }];
}
- (IBAction)clickGallery:(id)sender {
    BOOL authrozied = false;
    if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"8.0")) {
        if([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusAuthorized){
            authrozied = true;
        }else if([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusDenied){
            authrozied = false;
        }else if([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusNotDetermined){
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
                
                [self doSelectAlbum:status == PHAuthorizationStatusAuthorized];
            }];
            return;
        }
    }else{
        authrozied = true;
    }
    
    [self doSelectAlbum:authrozied];
}
-(void)doSelectAlbum:(BOOL)authrozied{
    if (authrozied) {
        //gallery
        //picture
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeSavedPhotosAlbum]) {
            picker.allowsEditing = false;
            //            picker.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
            picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate = self;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self presentViewController:picker animated:true completion:nil];
            });
            
        }else{
            [CGlobal AlertMessage:@"No PhotoLibrary" Title:nil];
        }
    }else{
        
        [CGlobal AlertMessage:@"To continue ,please enable ShareASuccess's access to your Photo Album" Title:nil ];
    }
}
@end



