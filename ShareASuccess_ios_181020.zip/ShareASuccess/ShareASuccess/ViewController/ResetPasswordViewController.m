//
//  ResetPasswordViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "ResetPasswordViewController.h"
#import "Utils.h"
#import "CGlobal.h"
#import "inc.h"
#import "NetworkParser.h"
@interface NSString (emailValidation)
- (BOOL) isValidEmail;
@end

@implementation ResetPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    appDelegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
   
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    tap.numberOfTapsRequired = 1;
    [self.view addGestureRecognizer:tap];
    
    NSArray* allTextFields = [self findAllTextFieldsInView:[self view]];
    
    for(int i=0;i<allTextFields.count;i++){
        UITextField* textfield =(UITextField*)allTextFields[i];
        //textfield.autocapitalizationType = UITextAutocapitalizationTypeSentences;
        textfield.delegate = self;
    }
    
    
    NSArray* array = [CGlobal findAllTextFieldsInView:self.view];
//    for (int i=0; i< [array count]; i++) {
//        UIView* view = [array objectAtIndex:i];
//        [CGlobal makeStyle1:view Mode:0];
//    }

    self.view.backgroundColor = APP_COLOR_PRIMARY;
    _textFieldEmail.text = _email;
}
-(void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSArray*)findAllTextFieldsInView:(UIView*)view{
    NSMutableArray* textfieldarray = [[NSMutableArray alloc] init];
    for(id x in [view subviews]){
        if([x isKindOfClass:[UITextField class]])
            [textfieldarray addObject:x];
        
        if([x respondsToSelector:@selector(subviews)]){
            // if it has subviews, loop through those, too
            [textfieldarray addObjectsFromArray:[self findAllTextFieldsInView:x]];
        }
    }
    return textfieldarray;
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
// When user click submit button.
- (IBAction)onTapSubmitButton:(id)sender {
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return;
    }
    
    if (self.textFieldEmail.text.length == 0) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_EMAIL_REQUIRE value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if(![self.textFieldEmail.text isValidEmail]){
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:@"Please input the email address." value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return;
    }
    NSString *email = [self.textFieldEmail.text stringByReplacingOccurrencesOfString:@" " withString:@"%20"];
    
    NSString *url = [NSString stringWithFormat:@"https://share-a-success.com/tpw72betk/webservices.php?Email=%@&action=resetUser", email];
    
    
    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager = [NetworkParser sharedManager];
    [manager ontemplateGeneralRequestWithRawUrl:nil Path:url withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            // delete invite row
            NSLog(@"No error");
        }else{
            NSLog(@"Error Accept Invite");
        }
        [self.navigationController popViewControllerAnimated:true];
        [CGlobal stopIndicator:self Tag:nil];
    }];
}
-(IBAction)ClickView:(UIView*)sender{
    int tag = sender.tag;
    switch (tag) {
        case 100:
        {
            NSString*path = @"http://www.share-a-success.com";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            break;
        }
        case 101:{
            NSString*path = @"http://www.share-a-success.com/impressum.php";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            break;
        }
        case 899:{
            [self.navigationController popViewControllerAnimated:true];
            break;
        }
        default:
            break;
    }
}
@end

@implementation NSString (emailValidation)

-(BOOL) isValidEmail
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:self];
}

@end
