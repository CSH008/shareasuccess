//
//  HelpRootViewController.swift
//  ShareASuccess
//
//  Created by BoHuang on 2/22/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

import UIKit

class HelpRootViewController: UIViewController {

    
    @IBOutlet weak var lblHead: UILabel!
    @IBOutlet weak var imgCross: UIImageView!
    @IBOutlet weak var btn0: UIButton!
    @IBOutlet weak var btn1: UIButton!
    
    //@IBOutlet weak var constraint_tableview_cointainer_height: NSLayoutConstraint!
    @IBOutlet weak var constraint_leading: NSLayoutConstraint!
    //@IBOutlet weak var constraint_trailing: NSLayoutConstraint!
    @IBOutlet weak var constraint_toolbar_bottom: NSLayoutConstraint!
    @IBOutlet weak var constraint_toolbar_top_title: NSLayoutConstraint!
    
    //@IBOutlet weak var constraint_first_top: NSLayoutConstraint!
    @IBOutlet weak var constraint_menu_height: NSLayoutConstraint!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        constraint_toolbar_top_title.constant = top_space_toolbar_title;
        
        constraint_menu_height.constant = g_menuHeight;
        
        self.view.backgroundColor = APP_COLOR_PRIMARY;
        if let image = imgCross.image {
            
            imgCross.image = CGlobal.getColoredImage(from: image, color: APP_COLOR_PRIMARY)
        }
        
        CGlobal.setCheckMark();
        
        lblHead.font = defaultFont_Headline_Bold;
        // Do any additional setup after loading the view.
    }

//    @IBAction func clickBtn0(_ sender: Any) {
//        let ms = UIStoryboard.init(name: "Main", bundle: nil);
//        DispatchQueue.main.async {
//            let viewcon = ms.instantiateViewController(withIdentifier: "HelpViewController") as! HelpViewController;
//            if let navc = self.navigationController {
//                navc.pushViewController(viewcon, animated: true)
//            }
//        }
//    }
    
    @IBAction func backPressed(_ sender: Any) {
        if let navc = self.navigationController{
            navc.popViewController(animated: true)
        }
    }
    @IBAction func clickBtn1(_ sender: Any) {
        let ms = UIStoryboard.init(name: "Main", bundle: nil);
        DispatchQueue.main.async {
            let viewcon = ms.instantiateViewController(withIdentifier: "HelpViewCController") as! HelpViewCController;
            if let navc = self.navigationController {
                navc.pushViewController(viewcon, animated: true)
            }
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
