//
//  UserSetupViewController.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>

/**
 New Member Screen
 **/
@interface UserSetupViewController : UIViewController

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_right;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool1;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool2;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool3;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;
@end
