//
//  ProfileViewController.h
//  Fit
//
//  Created by Denis on 10/8/15.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

/**
 Profiel Screen
 **/
@interface ProfileViewController : UIViewController <UITextFieldDelegate> {
    AppDelegate *appDelegate;
    
}
@property (weak, nonatomic) IBOutlet UISwitch *SwitchPushNoti;

@property (weak, nonatomic) IBOutlet UITextField *textFieldFirstName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldLastName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldScreenName;
@property (weak, nonatomic) IBOutlet UITextField *textFieldEmail;
@property (weak, nonatomic) IBOutlet UITextField *textFieldPassword;
//@property (weak, nonatomic) IBOutlet UITextField *textFieldConfirmPassword;
@property (weak, nonatomic) IBOutlet UISwitch *SwitchData;

@property (assign) NSTimer *repeatingTimer;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_right;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool1;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool2;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool3;

@property (nonatomic,weak) IBOutlet UIButton* btn_action;

@property (nonatomic,weak) IBOutlet UIButton* btn_url1;
@property (nonatomic,weak) IBOutlet UIButton* btn_url2;

//@property (nonatomic,weak) IBOutlet UIButton* btn_import;
//@property (nonatomic,weak) IBOutlet UIButton* btn_logout;

//@property (nonatomic,weak) IBOutlet UIButton* btn_logout;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_bottom;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top_title;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top;

@property (nonatomic,weak) IBOutlet UILabel*lbl_header1;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;

@end
