//
//  ResetPasswordMessageViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "ResetPasswordMessageViewController.h"
#import "CGlobal.h"
@implementation ResetPasswordMessageViewController

-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = APP_COLOR_PRIMARY;
    
}
- (IBAction)onTapLoginButton:(id)sender {
    [self.navigationController popToRootViewControllerAnimated:YES];
}
-(void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
- (IBAction)tapClose:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}

@end
