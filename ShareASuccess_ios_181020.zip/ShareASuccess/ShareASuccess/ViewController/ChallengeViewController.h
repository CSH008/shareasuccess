//
//  ChallengeViewController.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>
@class ColoredLabel;
/**
 Main Challenge Home Screen.
 **/
@interface ChallengeViewController : UIViewController <UITableViewDataSource, UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate> 
// blue                 5C719C
// toolbartint          A8B7AA
@property (weak, nonatomic) IBOutlet UIImageView *img_prev;
@property (weak, nonatomic) IBOutlet UIImageView *img_next;

//@property (weak, nonatomic) IBOutlet UIButton *btnDate;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UIImageView *imgSyncComplete;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITableView *tableView2;

@property (weak, nonatomic) IBOutlet UIView *tableview_Container;
-(void)updateDataOnServer;
-(void)getOfflineChanllengesData;

@property (nonatomic,assign) BOOL can_goleft;
@property (nonatomic,assign) BOOL can_goright;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title1;
@property (nonatomic,weak) IBOutlet UILabel* tool_lbl_title2;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool1;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool2;
@property (nonatomic,weak) IBOutlet UIButton* tool_btn_tool3;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar1;
@property (nonatomic,weak) IBOutlet UIView* view_toolbar2;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar1;

@property (nonatomic,weak) IBOutlet UIView* view_top;

@property (nonatomic,weak) IBOutlet UIView* view_root1;
@property (nonatomic,weak) IBOutlet UIView* view_root2;

@property (nonatomic,weak) IBOutlet UIButton* btn_plus;

@property (nonatomic,strong) UIRefreshControl* refreshControl;

@property (nonatomic,weak) IBOutlet UILabel* label_startchallenge;


@property (nonatomic,weak) IBOutlet UIImageView* img_refresh;

@property (nonatomic,weak) IBOutlet UIButton* btn_setting;
@property (nonatomic,weak) IBOutlet UIButton* btn_help;

@property (nonatomic,weak) IBOutlet UIButton* btn_lock;
@property (nonatomic,weak) IBOutlet UIImageView* img_lock;

@property (nonatomic,strong) IBOutlet UIButton* btnToday;
@property (nonatomic,strong) IBOutlet UIImageView* imgToday;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_bottom;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *constraint_toolbar_height;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top_title;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_first_top;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;
@property (nonatomic,weak) IBOutlet UILabel* lbl_headline1;
@property (nonatomic,weak) IBOutlet UILabel* lbl_headline2;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;
@property (weak, nonatomic) IBOutlet UIImageView *imgPlus;

+(NSArray*)calculateColorForAim:(NSArray*)myValues Aim:(NSArray*)aimValues;
+(NSArray*)calculateBackColorForAim:(NSArray*)myValues Aim:(NSArray*)aimValues;

@property (weak, nonatomic) IBOutlet ColoredLabel *lbl_b_Plus;
@property (weak, nonatomic) IBOutlet ColoredLabel *lbl_b_Edit;
@property (weak, nonatomic) IBOutlet ColoredLabel *lbl_b_Help;
@property (weak, nonatomic) IBOutlet ColoredLabel *lbl_b_Setting;

@property (weak, nonatomic) IBOutlet UIView *top_avatar_View;

@property (weak, nonatomic) IBOutlet UILabel *lbl_name;
@property (weak, nonatomic) IBOutlet UIImageView *user_image;
@property (weak, nonatomic) IBOutlet UILabel *lbl_weekday;
@property (weak, nonatomic) IBOutlet UILabel *lbl_date;

@property (weak, nonatomic) IBOutlet UIImageView *imageForSwipe;
//+(NSArray*)getFloatValuesFromStringSeries:(NSArray*)values;
//+(NSArray*)getIntValuesFromStringSeries:(NSArray*)values;
@end
