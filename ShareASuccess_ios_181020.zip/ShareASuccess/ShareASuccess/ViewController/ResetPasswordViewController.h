//
//  ResetPasswordViewController.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

/**
 Reset Password Screen
 **/
@interface ResetPasswordViewController : UIViewController <UITextFieldDelegate> {
    AppDelegate *appDelegate;
}

@property (weak, nonatomic) IBOutlet UITextField *textFieldEmail;

@property (nonatomic,weak) IBOutlet UIButton* tool_btn_left;

@property (nonatomic,strong) NSString* email;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_menu_height;

@end
