//
//  LoginViewController.m
//  Fit
//
//  Created by Denis on 10/9/15.
//
//

#import "LoginViewController.h"
#import "Utils.h"
#import "inc.h"
#import "CGlobal.h"
#import "NetWorkParser.h"
#import "ResetPasswordViewController.h"
#import "NewUserViewController.h"


@implementation LoginViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSArray* allTextFields = [self findAllTextFieldsInView:[self view]];
    
    for(int i=0;i<allTextFields.count;i++){
        UITextField* textfield =(UITextField*)allTextFields[i];
        //textfield.autocapitalizationType = UITextAutocapitalizationTypeSentences;
        textfield.delegate = self;
    }
    
    NSArray* array = [CGlobal findAllTextFieldsInView:self.view];
//    for (int i=0; i< [array count]; i++) {
//        UIView* view = [array objectAtIndex:i];
//        [CGlobal makeStyle1:view Mode:0];
//    }
    [_btn_url1 addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    [_btn_url2 addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
    
    _btn_url1.tag = 100;
    _btn_url2.tag = 101;
    self.view.backgroundColor = APP_COLOR_PRIMARY;
}
// handle Clicking the URL
-(IBAction)ClickView:(UIView*)sender{
    int tag = sender.tag;
    switch (tag) {
        case 100:
        {
            NSString*path = @"http://www.share-a-success.com";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            break;
        }
        case 101:{
            NSString*path = @"http://www.share-a-success.com/impressum.php";
            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:path]];
            break;
        }
        case 301:{
            // login
            [self onTapLoginButton:sender];
            break;
        }
        case 302:{
            // forgot password
            // ResetPasswordViewController
            UIStoryboard* main = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            ResetPasswordViewController*controller = [main instantiateViewControllerWithIdentifier:@"ResetPasswordViewController"];
            controller.email = _textFieldSigninEmail.text;
            [self.navigationController pushViewController:controller animated:true];
            break;
        }
        case 303:{
            // new user password
            UIStoryboard* main = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            NewUserViewController*controller = [main instantiateViewControllerWithIdentifier:@"NewUserViewController"];
            
            [self.navigationController pushViewController:controller animated:true];
            break;
            break;
        }
        default:
            break;
    }
}
- (void) viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.hidden = true;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSArray*)findAllTextFieldsInView:(UIView*)view{
    NSMutableArray* textfieldarray = [[NSMutableArray alloc] init];
    for(id x in [view subviews]){
        if([x isKindOfClass:[UITextField class]])
            [textfieldarray addObject:x];
        
        if([x respondsToSelector:@selector(subviews)]){
            // if it has subviews, loop through those, too
            [textfieldarray addObjectsFromArray:[self findAllTextFieldsInView:x]];
        }
    }
    return textfieldarray;
}

-(void)dismissKeyboard {
    [self.view endEditing:YES];
}

-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
// when user click forgot button.
- (IBAction)onTapForgotButton:(id)sender {
    [self performSegueWithIdentifier:SEGUE_LOGIN_TO_RESETPASSWORD sender:self];
}
// When user click login button.
- (IBAction)onTapLoginButton:(id)sender {
    AppDelegate* appDelegate = [[UIApplication sharedApplication] delegate];
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    if (self.textFieldSigninEmail.text.length == 0 || self.textFieldSigninPassword.text.length == 0) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_LOGIN_INFORMATION_EMPTY value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        
        return;
    }
    
    
    NSString *email = self.textFieldSigninEmail.text;
    NSString *password = self.textFieldSigninPassword.text;
    
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    [dict setValue:email forKey:@"email"];
    [dict setValue:password forKey:@"password"];
    [dict setValue:@"login" forKey:@"action"];
    
    
    
    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager = [NetworkParser sharedManager];
    [manager generalNetwork:g_baseUrl Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            [delegate onLogin:dict];
        }else{
            NSString*error = (NSString*)[dict objectForKey:@"res"];
            NSString *msg = [BaseModel decodeString:error ];
            if (msg != nil) {
                [CGlobal AlertMessage:msg Title:nil];
            }
            //            NSString* msg = [[NSBundle mainBundle] localizedStringForKey:@"Network Error" value:@"" table:nil];
            //            [CGlobal AlertMessage:msg Title:nil];
        }
        [CGlobal stopIndicator:self Tag:nil];
    } method:@"POST"];
   

}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:SEGUE_LOGIN_TO_MAIN]){
//        [((UITabBarController*)segue.destinationViewController) setSelectedIndex:1];
    }else if([segue.identifier isEqualToString:SEGUE_LOGIN_TO_RESETPASSWORD]){
        ResetPasswordViewController* controller = segue.destinationViewController;
        controller.email = _textFieldSigninEmail.text;
    }
}

@end


