//
//  AddChallengeViewController.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "AddChallengeViewController.h"
#import "Utils.h"
#import "inc.h"
#import "InviteEmailTableViewCell.h"
#import "CGlobal.h"
#import "NetworkParser.h"
#import <AddressBook/AddressBook.h>
#import "CellGeneral.h"
#import "ShareASuccess-Swift.h"
#import "IQKeyboardManager.h"
@interface NSString (emailValidation)
- (BOOL) isValidEmail;

@end

@implementation InviteControl

@end

@interface AddChallengeViewController() <UIPickerViewDelegate,UIPickerViewDataSource>
@property (nonatomic,strong) NSString* refreshStatus;
@property (nonatomic,strong) NSMutableArray* inviteEmailArray;
@property (nonatomic,copy) NSString* tempValue;
@property (nonatomic,strong) NSMutableArray* emailList;
@property (nonatomic,strong) NSMutableArray* mArrayFiltered;
@property (nonatomic,strong) NSArray* swList;

@property (nonatomic,assign) CGFloat cellcontent_width1;
@property (nonatomic,strong) UIFont *cellcontent_font1;

@property (nonatomic,copy) NSString* type;

@property (nonatomic,strong) NSArray* numbers_suffix;
@property (nonatomic,strong) NSArray* numbers_daily;
@property (nonatomic,strong) NSArray* numbers_weekly;
@property (nonatomic,strong) NSArray* aim_types;

@property (nonatomic,assign) int aim_type_index;
@property (nonatomic,strong) NSMutableArray* numbers_weekly_index;
@property (nonatomic,strong) NSMutableArray* numbers_daily_index;
@end

@implementation AddChallengeViewController
-(void) viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = true;
}
- (void) viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = APP_COLOR_PRIMARY;
    [[IQKeyboardManager sharedManager] setEnable:YES];
    [[IQKeyboardManager sharedManager] setEnableAutoToolbar:YES];
    [[IQKeyboardManager sharedManager] setShouldResignOnTouchOutside:YES];
    
    _constraint_leading.constant = status_leading;
    _constraint_trailing.constant = status_trailing;
    
    _constraint_toolbar_bottom.constant = bottom_space;
    _constraint_toolbar_top_title.constant = top_space_toolbar_title;
    //_constraint_first_top.constant = top_space- statusbar_gap1;
    
    
    _constraint_leading1.constant = status_leading;
    _constraint_trailing1.constant = status_trailing;
    
    _constraint_menu_height.constant = g_menuHeight;
    
    [_lbl_header1 setFont:defaultFont_Headline_Bold];
    
        
    [self requestAddressBookPermissions];
    //_labelChallengeDesc.placeholder = [[NSBundle mainBundle] localizedStringForKey:@"Description" value:@"" table:nil];
    
    _inviteEmailArray = [[NSMutableArray alloc] init];
    for (int i=0; i< [_challengeInfo.invitees count]; i++) {
        TblInvitee* invitee = _challengeInfo.invitees[i];
        [_inviteEmailArray addObject:invitee.email_address];
    }
    [_tableview setDataSource:self];
    [_tableview setDelegate:self];
    
    
    NSString *identifier = @"InviteEmailTableViewCell";
    [_tableview registerNib:[UINib nibWithNibName:identifier bundle:nil] forCellReuseIdentifier:identifier];
    _tableview.backgroundColor = [UIColor clearColor];
    _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    _aim_type_index = 1;
    AppDelegate* appDelegate = [[UIApplication sharedApplication] delegate];
    if (_challengeInfo==nil ) {
        [self setContentMode:0];
        // new challenge
        NSString *temp = [[NSBundle mainBundle] localizedStringForKey:@"New Challenge" value:@"" table:nil];
        _tool_lbl_title1.text = @"";
        _lbl_header1.text = temp;
        
        temp = [[NSBundle mainBundle] localizedStringForKey:@"Start Challenge!" value:@"" table:nil];
        [_btnStop setTitle:temp forState:UIControlStateNormal];
        _btnSave.hidden = true;
        _btnStop.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
        [_btnStop addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        _btnStop.tag = 100;     //  save new challenge
        
        [_btnChallenging addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        [_btnAim addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        
        _switchSteps.on = false;
        _switchCycling.on = false;
        _switchWalking.on = false;
        _switchStanding.on = false;
        _switchActive.on = false;
        _switchFlights.on = false;
        _switchSwiming.on = false;
        
        
        _switchStepsAim.on = false;
        _switchCyclingAim.on = false;
        _switchWalkingAim.on = false;
        _switchStandingAim.on = false;
        _switchActiveAim.on = false;
        _switchFlightsAim.on = false;
        _switchSwimingAim.on = false;
        
        NSArray* lblAimLabels = @[_lblAimtype,_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
        for (UILabel* lbl in lblAimLabels) {
            lbl.text = @"";
        }
    }
    else {
        // edit challenge
        
        [self setContentMode:[_challengeInfo.type intValue]];
        
        [self.navigationItem setTitle:_challengeInfo.challenge_name];
        
        self.labelChallengeName.text = _challengeInfo.challenge_name;
        
        if ([_challengeInfo.type intValue] == 0) {
            // challenge
            NSArray* array = [_challengeInfo getChallengeValues];
            NSArray* controls = @[_switchSteps,_switchWalking,_switchCycling,_switchStanding,_switchFlights,_switchActive,_switchSwiming];
            for (int i=0; i< array.count; i++) {
                UISwitch* sw = controls[i];
                if ([array[i] intValue] == 1) {
                    [sw setOn:true];
                }else{
                    [sw setOn:false];
                }
            }
            NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Edit Challenge" value:@"" table:nil];
            _tool_lbl_title1.text = @"";
            _lbl_header1.text = temp;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Stop Challenge" value:@"" table:nil];
            [_btnStop setTitle:temp forState:UIControlStateNormal];
            _btnStop.backgroundColor = APP_COLOR_DOT_RED;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Update Challenge" value:@"" table:nil];
            [_btnSave setTitle:temp forState:UIControlStateNormal];
        }else{
            // aim
            NSArray* array = [_challengeInfo getAimValues];
            NSArray* controls = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
            for (int i=0; i< array.count; i++) {
                UISwitch* sw = controls[i];
                if ([array[i] floatValue] > 0 ) {
                    [sw setOn:true];
                }else{
                    [sw setOn:false];
                }
            }
            NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Edit Aim" value:@"" table:nil];
            _tool_lbl_title1.text = @"";
            _lbl_header1.text = temp;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Stop Aim" value:@"" table:nil];
            [_btnStop setTitle:temp forState:UIControlStateNormal];
            _btnStop.backgroundColor = APP_COLOR_DOT_RED;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Update Aim" value:@"" table:nil];
            [_btnSave setTitle:temp forState:UIControlStateNormal];
        }
        
        
        _labelChallengeDesc.text = _challengeInfo.challenge_description;
        
        
        [_btnStop addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        _btnStop.tag = 101;             //  stop challenge
        
        
        [_btnSave addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        _btnSave.tag = 102;             //  save challenge
    }
    
    
    
    _view_description.layer.cornerRadius = default_textfield_radius;
    _view_description.layer.masksToBounds = true;
    _view_description.backgroundColor = [ UIColor clearColor];
    _view_description.layer.borderWidth = 1;
    _view_description.layer.borderColor = [[CGlobal colorWithHexString:@"#97AEA0" Alpha:1.0f] CGColor];
    
    _labelChallengeDesc.layer.borderColor = [[UIColor clearColor] CGColor];
    _labelChallengeDesc.layer.masksToBounds = true;
    
    _labelChallengeDesc.placeholderColor = [CGlobal colorWithHexString:@"ffffff" Alpha:1.0f];
    
//    _textFieldEmail.placeholder = [[NSBundle mainBundle] localizedStringForKey:@"Your friend's email address" value:@"" table:nil];
    NSString* tmp_str1 = [[NSBundle mainBundle] localizedStringForKey:@"Your friend's email address" value:@"" table:nil];
    _textFieldEmail.attributedPlaceholder = [[NSAttributedString alloc] initWithString:tmp_str1 attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    
    //
    [_textFieldEmail addTarget:self
                      action:@selector(textFieldDidChange:)
            forControlEvents:UIControlEventEditingChanged];
    [_autocompleteTable registerNib:[UINib nibWithNibName:@"CellGeneral" bundle:nil] forCellReuseIdentifier:@"CellGeneral"];
    
    
    
    _viewAutoComplete.hidden = true;
    
    [_autocompleteTable setDelegate:self];
    [_autocompleteTable setDataSource:self];
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    _cellcontent_width1 = screenRect.size.width - 75;      //hgv
    _cellcontent_font1 = [UIFont systemFontOfSize:15];
    
    _autocompleteTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    
    
    UISwipeGestureRecognizer*swipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(gestureSwipeLeft:)];
    [swipe setDirection:UISwipeGestureRecognizerDirectionRight];
    [_view_scrollroot addGestureRecognizer:swipe];
    
    
    _swList = [[NSArray alloc] initWithObjects:_switchSteps,_switchWalking,_switchCycling,_switchSwiming,_switchStanding,_switchFlights,_switchActive, nil];
    for (UISwitch*sw in _swList) {
        //[sw setOn:false];
        NSUInteger index = [_swList indexOfObject:sw];
        sw.tag = 100+index;
        [sw addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    }
    
    _swList = [[NSArray alloc] initWithObjects:_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchSwimingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim, nil];
    for (UISwitch*sw in _swList) {
        //[sw setOn:false];
        NSUInteger index = [_swList indexOfObject:sw];
        sw.tag = 200+index;
        [sw addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged];
    }
    
    
    if (([[[UIDevice currentDevice] systemVersion] compare:@"9.0" options:NSNumericSearch] != NSOrderedAscending)) {    // >=
        _switchStanding.enabled = true;
    }else{
        //[_switchStanding setOn:false animated:false];
        _switchStanding.enabled = false;
    }
    
    if (([[[UIDevice currentDevice] systemVersion] compare:@"10.0" options:NSNumericSearch] != NSOrderedAscending)) {   // >=
        _switchSwiming.enabled = true;
    }else{
        //[_switchSwiming setOn:false animated:false];
        _switchSwiming.enabled = false;
    }
    
    
    [_view_scrollroot bringSubviewToFront:_autocompleteTable];
    
    
    [self initCombobox];
    
    
    
    _btnChallenging.tag = 200;
    _btnAim.tag = 201;
    
    // change to white image
    NSArray* img_aim_views = @[_img_aim_steps,_img_aim_walking,_img_aim_cycling,_img_aim_swimming,_img_aim_stand,_img_aim_stair,_img_aim_energy];
    for (UIImageView* img in img_aim_views) {
        img.image = [CGlobal getColoredImageFromImage:img.image Color:[UIColor whiteColor]];
    }
    img_aim_views = @[_img_ch_steps,_img_ch_walking,_img_ch_cycling,_img_ch_swimming,_img_ch_stand,_img_ch_stair,_img_ch_energy];
    for (UIImageView* img in img_aim_views) {
        img.image = [CGlobal getColoredImageFromImage:img.image Color:[UIColor whiteColor]];
    }
}
-(void)initCombobox{
    NSArray* lblChLabels_ = @[_lblSteps_,_lblWalking_,_lblCycling_,_lblStanding_,_lblFlights_,_lblActive_,_lblSwiming_];
    
    
    NSArray* lblAimLabels = @[_lblAimtype,_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
    NSArray* lblAimLabels_ = @[_lblStepsAim_,_lblWalkingAim_,_lblCyclingAim_,_lblStandingAim_,_lblFlightsAim_,_lblActiveAim_,_lblSwimingAim_];
    
    NSArray* viewNumbers = @[_vnAimtype,_vnStepsAim,_vnWalkingAim,_vnCyclingAim,_vnStandingAim,_vnFlightsAim,_vnActiveAim,_vnSwimingAim];
    
    NSArray* viewColored = @[_cvAimtype,_cvStepsAim,_cvWalkingAim,_cvCyclingAim,_cvStandingAim,_cvFlightsAim,_cvActiveAim,_cvSwimingAim];
    
    NSArray* pkNumbers = @[_pkAimtype,_pkStepsAim,_pkWalkingAim,_pkCyclingAim,_pkStandingAim,_pkFlightsAim,_pkActiveAim,_pkSwimingAim];
    NSArray* btnNumbers = @[_btnAimtype,_btnStepsAim,_btnWalkingAim,_btnCyclingAim,_btnStandingAim,_btnFlightsAim,_btnActiveAim,_btnSwimingAim];
    
    
    
    UIFont* font = [UIFont systemFontOfSize:11.0f];
    for (UILabel* label in lblAimLabels) {
        label.text = @"";
        [label setFont:font];
        label.textColor = [UIColor whiteColor];
    }
    for (UILabel* label in lblChLabels_) {
        label.textColor = [UIColor whiteColor];
    }
    
    for (UILabel* label in lblAimLabels_) {
        label.textColor = [UIColor whiteColor];
    }
    
    _aim_types = @[@"daily",@"weekly"];
    NSArray* daily_steps = @[@"7000",@"8500",@"10000",@"15000",@"20000",@"25000",@"30000",@"35000",@"40000",@"50000",@"60000"];
    NSArray* weekly_steps = @[@"50000",@"60000",@"70000",@"105000",@"140000",@"175000",@"210000",@"245000",@"280000",@"350000",@"420000"];
    
    NSArray* daily_walking = @[@"7",@"8",@"10",@"15",@"20",@"25",@"30",@"35",@"40",@"50",@"60"];
    NSArray* weekly_walking = @[@"50",@"60",@"70",@"105",@"140",@"175",@"210",@"245",@"280",@"350",@"420"];
    
    NSArray* daily_cycling = @[@"10",@"20",@"30",@"40",@"50",@"75",@"100",@"150"];
    NSArray* weekly_cycling = @[@"70",@"140",@"210",@"280",@"350",@"525",@"700",@"1050"];
    
    NSArray* daily_swimming = @[@"1",@"1.5",@"2",@"2.5",@"3",@"5",@"7.5",@"10",@"15",@"20",@"25",@"30",@"35",@"40",@"45",@"50"];
    NSArray* weekly_swimming = @[@"1",@"1.5",@"2",@"2.5",@"3",@"5",@"7.5",@"10",@"15",@"20",@"25",@"30",@"35",@"40",@"45",@"50"];
    
    NSArray* daily_stand = @[@"10",@"11",@"12",@"13",@"14"];
    NSArray* weekly_stand = @[@"70",@"77",@"84",@"91",@"98"];
    
    NSArray* daily_flight = @[@"5",@"10",@"15",@"20",@"25",@"30",@"35",@"40",@"50",@"75",@"100"];
    NSArray* weekly_flight = @[@"35",@"70",@"105",@"140",@"175",@"210",@"245",@"280",@"350",@"525",@"700"];

    
    NSArray* daily_energy = @[@"250",@"260",@"280",@"300",@"350",@"400",@"450",@"500",@"550",@"600",@"650",@"700",@"750",@"800",@"850",@"900",@"950",@"1000",@"1100",@"1200",@"1300",@"1400",@"1500"];
    NSArray* weekly_energy = @[@"1500",@"1800",@"2000",@"2100",@"2450",@"2800",@"3150",@"3500",@"3850",@"4200",@"4550",@"4900",@"5250",@"5600",@"5950",@"6300",@"6650",@"7000",@"7700",@"8400",@"9100",@"9800",@"10500"];
    NSArray* controls = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
    
    _numbers_suffix = @[@"steps",@"km",@"km",@"hrs",@"stairs",@"kcal",@"km"];
    _numbers_daily = @[daily_steps,     daily_walking,  daily_cycling,  daily_stand,    daily_flight,   daily_energy,daily_swimming];
    _numbers_weekly = @[weekly_steps,   weekly_walking, weekly_cycling, weekly_stand,   weekly_flight,  weekly_energy,weekly_swimming];
    _numbers_weekly_index = [[NSMutableArray alloc] initWithArray:@[ [NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0] ]];
    _numbers_daily_index = [[NSMutableArray alloc] initWithArray:@[ [NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0],[NSNumber numberWithInt:0] ]];
    
    if (_challengeInfo!=nil && [_challengeInfo.type intValue] == 1) {
        // Edit Mode , Aim Type
        NSArray* aimValues = [_challengeInfo getAimValues];
        NSArray* aimStrValues = [_challengeInfo getStrAimValues];
        if ([_challengeInfo.aim_type intValue] == 0) {
            // daily
            _aim_type_index = 0;
            
            for (int i=0; i<_numbers_daily.count; i++) {
                NSArray* data = _numbers_daily[i];
                if ([aimValues[i] floatValue] > 0 ) {
                    NSUInteger index = NSNotFound;
                    for (NSString* val in data) {
                        
                        if ([val isEqualToString:aimStrValues[i]]) {
                            index = [data indexOfObject:val];
                            break;
                        }
                    }
                    if (index != NSNotFound) {
                        _numbers_daily_index[i] = [NSNumber numberWithInt:(int)index];
                    }
                }
            }
        }else{
            // weekly
            _aim_type_index = 1;
            for (int i=0; i<_numbers_weekly.count; i++) {
                NSArray* data = _numbers_weekly[i];
                if ([aimValues[i] floatValue] > 0 ) {
                    NSUInteger index = NSNotFound;
                    for (NSString* val in data) {
                        if ([val isEqualToString:aimStrValues[i]]) {
                            index = [data indexOfObject:val];
                            break;
                        }
                    }
                    if (index != NSNotFound) {
                        _numbers_weekly_index[i] = [NSNumber numberWithInt:(int)index];
                    }
                }
            }
            
            
            
        }
    }
    
    _numbers_daily = @[daily_steps,     daily_walking,  daily_cycling,  daily_stand,    daily_flight,   daily_energy,daily_swimming];
    // construct picker view
    CGRect screenRect= [UIScreen mainScreen].bounds;
    CGFloat y = (90 - 32 ) /2.0 - 0.5;
    for (int i=0; i< viewNumbers.count; i++) {
        UIView* view = viewNumbers[i];
        view.hidden = true;
        
        UIPickerView*pkView = pkNumbers[i];
        pkView.tag = 100 + i;
        pkView.delegate = self;
        pkView.dataSource = self;
        pkView.showsSelectionIndicator = false;
        
        NSArray* array = [[NSBundle mainBundle] loadNibNamed:@"PickerCell" owner:self options:nil];
        PickerCell* cell = array[0];
        cell.frame = CGRectMake(0, y, screenRect.size.width - 30, 33);
        [pkView addSubview:cell];
        
        UIButton*btn = btnNumbers[i];
        btn.tag = 300+i;
        [btn addTarget:self action:@selector(ClickView:) forControlEvents:UIControlEventTouchUpInside];
        
        // update the labels
        UILabel* label = lblAimLabels[i];
        if (i==0) {
            label.text = _aim_types[_aim_type_index];
        }else{
            int j = i-1;
            if (_aim_type_index == 0) {
                UISwitch* sw = controls[j];
                NSArray* data = _numbers_daily[j];
                NSArray* unit = _numbers_suffix[j];
                int index = [_numbers_daily_index[j] intValue];
                label.text = [NSString stringWithFormat:@"%@ %@",data[index],unit];
                if ([sw isOn]) {
                    label.hidden = false;
                }else{
                    label.hidden = true;
                }
                
                
            }else{
                UISwitch* sw = controls[j];
                NSArray* data = _numbers_weekly[j];
                NSArray* unit = _numbers_suffix[j];
                int index = [_numbers_weekly_index[j] intValue];
                label.text = [NSString stringWithFormat:@"%@ %@",data[index],unit];
                if ([sw isOn]) {
                    label.hidden = false;
                }else{
                    label.hidden = true;
                }
                
                
            }
        }
        
        
    }
    
    [_pkAimtype selectRow:1 inComponent:0 animated:false];
   
}


-(void)setContentMode:(int)mode{
    if (mode == 0) {
        _type = @"0";
        
        _stackChallenging.hidden = false;
        _stackAim.hidden = true;
//        _btnAim.backgroundColor = [UIColor clearColor];
//        _btnChallenging.backgroundColor = [UIColor darkGrayColor];
//        _btnAim.backMode = 1;
//        _btnChallenging.backMode = 0;
        
        if (_challengeInfo==nil ) {
            NSString *temp = [[NSBundle mainBundle] localizedStringForKey:@"New Challenge" value:@"" table:nil];
            _lbl_header1.text = temp;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Start Challenge!" value:@"" table:nil];
            [_btnStop setTitle:temp forState:UIControlStateNormal];
        }
        
        
        _labelChallengeName.placeholder = [[NSBundle mainBundle] localizedStringForKey:@"Challenge name" value:@"" table:nil];
        _labelChallengeName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:_labelChallengeName.placeholder attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
        
    }else{
        _type = @"1";
        
        _stackChallenging.hidden = true;
        _stackAim.hidden = false;
        
        if (_challengeInfo==nil ) {
            NSString *temp = [[NSBundle mainBundle] localizedStringForKey:@"New Aim" value:@"" table:nil];
            _lbl_header1.text = temp;
            
            temp = [[NSBundle mainBundle] localizedStringForKey:@"Start Aim!" value:@"" table:nil];
            [_btnStop setTitle:temp forState:UIControlStateNormal];
        }
        
        
        
        _labelChallengeName.placeholder = [[NSBundle mainBundle] localizedStringForKey:@"Aim name" value:@"" table:nil];
        _labelChallengeName.attributedPlaceholder = [[NSAttributedString alloc] initWithString:_labelChallengeName.placeholder attributes:@{NSForegroundColorAttributeName: [UIColor whiteColor]}];
    }
}
-(void)setStyleForView:(UIView*)view{
    CGRect screenRect= [UIScreen mainScreen].bounds;
    CGRect rect = CGRectMake(0, 0, screenRect.size.width-status_leading*2, 128);
    
    CGFloat borderWidth = 1.0;
    
    
    
    view.layer.borderColor = [[CGlobal colorWithHexString:@"ff0000" Alpha:1.0f] CGColor];
    //    view.layer.borderColor = [[UIColor blackColor] CGColor];
    view.layer.borderWidth = borderWidth;
    
    UIView* mask = [[UIView alloc] initWithFrame:CGRectMake(0, borderWidth,rect.size.width, rect.size.height-borderWidth)];
    mask.backgroundColor = [UIColor blackColor];
    view.layer.mask = mask.layer;
}
-(void)switchChanged:(UISwitch*)sender{
    
    int count = 0;
    if ([_type isEqualToString:@"0"]) {
        _swList = [[NSArray alloc] initWithObjects:_switchSteps,_switchWalking,_switchCycling,_switchSwiming,_switchStanding,_switchFlights,_switchActive, nil];
        for (UISwitch*sw in _swList) {
            if ([sw isOn]) {
                count++;
            }
        }
        if (count>5) {
            [sender setOn:false];
            
            NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:@"Only 5 activities possible" value:@"" table:nil];
            [CGlobal AlertMessage:localized_title Title:nil];
        }
    }else{
        _swList = [[NSArray alloc] initWithObjects:_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchSwimingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim, nil];
        for (UISwitch*sw in _swList) {
            if ([sw isOn]) {
                count++;
            }
        }
        if (count>5) {
            [sender setOn:false];
            
            NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:@"Only 5 activities possible" value:@"" table:nil];
            [CGlobal AlertMessage:localized_title Title:nil];
        }
        
        if (![sender isOn]) {
            NSArray* viewNumbers = @[_vnStepsAim,_vnWalkingAim,_vnCyclingAim,_vnStandingAim,_vnFlightsAim,_vnActiveAim,_vnSwimingAim];
            
            NSArray* switchList = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
            NSArray* lblAimLabels = @[_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
            NSUInteger findIndex = [switchList indexOfObject:sender];
            if (findIndex!=NSNotFound) {
                UIView* curView = viewNumbers[findIndex];
                curView.hidden = true;
                
                UILabel* label = lblAimLabels[findIndex];
                label.hidden = true;
                NSString* lab = label.text;
                NSLog(@"%@",lab);
            }
            
            
            
        }else{
            // on the switch
            NSArray* viewNumbers = @[_vnStepsAim,_vnWalkingAim,_vnCyclingAim,_vnStandingAim,_vnFlightsAim,_vnActiveAim,_vnSwimingAim];
            
            NSArray* switchList = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
            NSArray* lblAimLabels = @[_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
            NSUInteger findIndex = [switchList indexOfObject:sender];
            
            for (UIView* curView in viewNumbers){
                curView.hidden = true;
            }
            if (findIndex!=NSNotFound) {
                UIView* curView = viewNumbers[findIndex];
                curView.hidden = false;
                
                UILabel*label = lblAimLabels[findIndex];
                label.hidden = false;
                
                NSString*lab = label.text;
                NSLog(@"%@",lab);
            }
            
            // label
        }
    }
    
}
// handle swipe left gesture
-(void)gestureSwipeLeft:(UISwipeGestureRecognizer*)gesture{

    [self onTapCancelButton:nil];
    
}
- (void)requestAddressBookPermissions
{
    ABAddressBookRef addressBookRef = ABAddressBookCreateWithOptions(NULL, NULL);
    
    if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusNotDetermined) {
        ABAddressBookRequestAccessWithCompletion(addressBookRef, ^(bool granted, CFErrorRef error) {
            if (granted) {
                // First time access has been granted, add the contact
                _emailList = [CGlobal getEmailAddressFromAdressBook];
            } else {
                // User denied access
                // Display an alert telling user the contact could not be added
            }
        });
    }
    else if (ABAddressBookGetAuthorizationStatus() == kABAuthorizationStatusAuthorized) {
        // The user has previously given access, add the contact
        _emailList = [CGlobal getEmailAddressFromAdressBook];
    }
    else {
        // The user has previously denied access
        // Send an alert telling user to change privacy setting in settings app
    }
}
-(NSArray*)findAllTextFieldsInView:(UIView*)view{
    NSMutableArray* textfieldarray = [[NSMutableArray alloc] init];
    for(id x in [view subviews]){
        if([x isKindOfClass:[UITextField class]])
            [textfieldarray addObject:x];
        
        if([x respondsToSelector:@selector(subviews)]){
            // if it has subviews, loop through those, too
            [textfieldarray addObjectsFromArray:[self findAllTextFieldsInView:x]];
        }
    }
    return textfieldarray;
}
- (IBAction)onTapCancelButton:(id)sender {
    if (_presentMode == nil) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }else{
        [self dismissViewControllerAnimated:false completion:^{
            
        }];
    }
    
}
- (IBAction)onTapPlusButton:(id)sender {
    if (self.textFieldEmail.text.length == 0) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_email = [[NSBundle mainBundle] localizedStringForKey:ALERT_EMAIL_REQUIRE value:@"" table:nil];
        
        [Utils showAlert:localized_email title:localized_title];
        return;
    }
    
    if (![self.textFieldEmail.text isValidEmail]) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_email = [[NSBundle mainBundle] localizedStringForKey:ALERT_REGISTER_INVALID_EMAIL value:@"" table:nil];
        
        [Utils showAlert:localized_email title:localized_title];
        return;
    }
    
    [_inviteEmailArray addObject:self.textFieldEmail.text];
    self.textFieldEmail.text = @"";
    
    [_tableview reloadData];
    
}
- (void) onTapMinusButton:(UIButton*)sender {
    long row= sender.tag;
    [_inviteEmailArray removeObjectAtIndex:row];
    [_tableview reloadData];
    
}

#pragma mark - TableView

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _autocompleteTable) {
        CellGeneral *cell = [tableView dequeueReusableCellWithIdentifier:@"CellGeneral" forIndexPath:indexPath];
                
        [cell setData:_mArrayFiltered[indexPath.row] IndexPath:indexPath Size:_mArrayFiltered.count];
//        cell.backgroundColor = [UIColor lightGrayColor];
        return cell;
    }else{
        static  NSString *identifier = @"InviteEmailTableViewCell";
        InviteEmailTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
        
        long row = indexPath.row;
        TblInvitee * model = [_inviteEmailArray objectAtIndex:row];
        [cell setData:model];
        
        [cell.img_right addTarget:self action:@selector(onTapMinusButton:) forControlEvents:UIControlEventTouchUpInside];
        cell.img_right.tag = row;
        
        cell.viewRoot.backgroundColor = APP_COLOR_PRIMARY;
//        [CGlobal makeStyle1:cell.txt_email Mode:0];
        
        return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _autocompleteTable) {
        int row = indexPath.row;
        NSMutableDictionary* dict = _mArrayFiltered[row];
        NSString* email = dict[@"email"];
        _textFieldEmail.text = email;
        _viewAutoComplete.hidden = true;
        [_scrollview setScrollEnabled:true];
        [_autocompleteTable setScrollEnabled:false];
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == _autocompleteTable) {
        return [_mArrayFiltered count];
    }else{
        _constraint_tableheight.constant = 52* [_inviteEmailArray count];
        
        [_tableview setNeedsUpdateConstraints];
        [_view_scrollroot setNeedsUpdateConstraints];
        
        
        [_scrollview layoutIfNeeded];
        return [_inviteEmailArray count];
    }
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _autocompleteTable) {
//        CGFloat height = [CGlobal heightForView:_mArrayFiltered[indexPath.row] Font:_cellcontent_font1 Width:_cellcontent_width1];
        
        return 66;
    }else{
        return 53;
    }
    
}
-(IBAction)ClickView:(UIView*)sender{
    int tag = (int)sender.tag;
    EnvVar* env = [CGlobal sharedId].env;
    switch (tag) {
        case 100:
        {
            // new challenge add
            [self onTapSaveButton:sender];
            break;
        }
        case 101:{
            // stop challenge
            NSString* msg = @"";
            if ([_challengeInfo.type intValue] == 0) {
                msg = [[NSBundle mainBundle] localizedStringForKey:@"Do you want to stop this challenge?" value:@"" table:nil];
            }else{
                msg = [[NSBundle mainBundle] localizedStringForKey:@"Do you want to stop this aim?" value:@"" table:nil];
            }
            
            NSString*yes = [[NSBundle mainBundle] localizedStringForKey:@"Yes" value:@"" table:nil];
            NSString*no = [[NSBundle mainBundle] localizedStringForKey:@"No" value:@"" table:nil];
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:msg
                                                            message:@""
                                                           delegate:self
                                                  cancelButtonTitle:nil
                                                  otherButtonTitles:yes,no, nil];
            [alert show];
            
            break;
        }
        case 102:{
            //save challenge
            [self onTapSaveButton:sender];
            
            break;
        }
        case 200:{
            [self setContentMode:0];
            break;
        }
        case 201:{
            [self setContentMode:1];
            break;
        }
        default:{
            if (tag>=300 && tag<400) {
                
                NSArray* viewNumbers = @[_vnAimtype,_vnStepsAim,_vnWalkingAim,_vnCyclingAim,_vnStandingAim,_vnFlightsAim,_vnActiveAim,_vnSwimingAim];
                
                NSArray* pkNumbers = @[_pkAimtype,_pkStepsAim,_pkWalkingAim,_pkCyclingAim,_pkStandingAim,_pkFlightsAim,_pkActiveAim,_pkSwimingAim];
                NSArray* btnNumbers = @[_btnAimtype,_btnStepsAim,_btnWalkingAim,_btnCyclingAim,_btnStandingAim,_btnFlightsAim,_btnActiveAim,_btnSwimingAim];
                
                
                NSArray* switchList = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
                NSUInteger findIndex = [btnNumbers indexOfObject:sender];
                if (findIndex!=NSNotFound) {
                    UIView* curView = viewNumbers[findIndex];
                    if (findIndex == 0) {
                        if (curView.hidden) {
                            // hidden
                            for (int i=0; i<pkNumbers.count; i++) {
                                UIView* view = viewNumbers[i];
                                view.hidden = true;
                            }
                            curView.hidden = false;
                        }else{
                            curView.hidden = true;
                        }
                    }else{
                        UISwitch* sw = switchList[findIndex-1];
                        if ([sw isOn]) {
                            if (curView.hidden) {
                                for (int i=0; i<pkNumbers.count; i++) {
                                    UIView* view = viewNumbers[i];
                                    view.hidden = true;
                                }
                                curView.hidden = false;
                            }else{
                                curView.hidden = true;
                            }
                        }
                    }
                    
                    
                }

                
            }
            break;
        }
            
    }
}
// Callback when user delete or save a Challenge.
- (IBAction)onTapSaveButton:(id)sender {
    EnvVar* env = [CGlobal sharedId].env;
    AppDelegate* appDelegate = [[UIApplication sharedApplication] delegate];
    if ([appDelegate.reachability currentReachabilityStatus] == NotReachable) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_ERRORNOINTERNET value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return;
    }
    
    if (self.labelChallengeName.text.length == 0) {
        NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:ALERT_TITLE_DEFAULT value:@"" table:nil];
        NSString *localized_content = [[NSBundle mainBundle] localizedStringForKey:ALERT_CHALLENGE_NAME_REQUIRED value:@"" table:nil];
        
        [Utils showAlert:localized_content title:localized_title];
        return;
    }
    
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    if ([_type isEqualToString:@"0"]) {
        NSArray* array = @[_switchSteps,_switchWalking,_switchCycling,_switchStanding,_switchFlights,_switchActive,_switchSwiming];
        NSArray* key_series = @[@"steps",@"workdistance",@"cycling_distance",@"hours",@"climbed",@"energy",@"swim"];
        NSUInteger nc = 0;
        for (int i=0; i<array.count; i++) {
            UISwitch* sw = array[i];
            NSString* key = key_series[i];
            if (sw.on) {
                dict[key] = @"1";
                nc++;
                
            }else{
                dict[key] = @"0";
            }
            if (nc == 6) {
                NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:@"Only 5 activities possible" value:@"" table:nil];
                [CGlobal AlertMessage:localized_title Title:nil];
                return;
            }
        }
                
    }else{
        NSArray* array = @[_switchStepsAim,_switchWalkingAim,_switchCyclingAim,_switchStandingAim,_switchFlightsAim,_switchActiveAim,_switchSwimingAim];
        
        NSArray* lblNumbers = @[_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
        
        NSArray* key_series = @[@"aim_steps",@"aim_walking_running",@"aim_cycling_distance",@"aim_stand_hours",@"aim_flights_climbed",@"aim_active_energy",@"aim_swim"];
        NSUInteger nc = 0;
        for (int i=0; i<array.count; i++) {
            UISwitch* sw = array[i];
            NSString* key = key_series[i];
            UILabel* label = lblNumbers[i];
            if (sw.on) {
                NSString*val = label.text;
                NSArray* list = [val componentsSeparatedByString:@" "];
                if ([list count] ==2) {
                    dict[key] = list[0];
                }else{
                    dict[key] = @"0";
                }
                
                nc++;
                
            }else{
                dict[key] = @"0";
            }
            if (nc == 6) {
                NSString *localized_title = [[NSBundle mainBundle] localizedStringForKey:@"Only 5 activities possible" value:@"" table:nil];
                [CGlobal AlertMessage:localized_title Title:nil];
                return;
            }
        }
        dict[@"aim_type"] =  [NSString stringWithFormat:@"%lu",_aim_type_index];
        
    }
    [dict setValue:_type forKey:@"type"];
    
    NSString *name =self.labelChallengeName.text;
    NSString *description =self.labelChallengeDesc.text;
    [dict setValue:name forKey:@"challengename"];
    [dict setValue:description forKey:@"Description"];
    
    if (_challengeInfo == nil) {
        [dict setValue:env.custId forKey:@"custId"];
    } else {
        
        [dict setValue:_challengeInfo.challenge_id forKey:@"challengeId"];
        [dict setValue:_challengeInfo.custId forKey:@"custId"];
        [dict setValue:[NSString stringWithFormat:@"%li",_challengeInfo.display_order] forKey:@"display_order"];
    }
    
    NSString* emails = @"";
    for (int i = 0; i < _inviteEmailArray.count; i++) {
        id data = [_inviteEmailArray objectAtIndex:i];
        if ([data isKindOfClass:[NSDictionary class]]) {
            emails = [emails stringByAppendingString:data[@"email_address"]];
            emails = [emails stringByAppendingString:@","];
        }else if([data isKindOfClass:[NSString class]]){
            
            emails = [emails stringByAppendingString:data];
            emails = [emails stringByAppendingString:@","];
        }else if([data isKindOfClass:[TblInvitee class]]){
            TblInvitee* invitee = (TblInvitee*)data;
            
            emails = [emails stringByAppendingString:invitee.email_address];
            emails = [emails stringByAppendingString:@","];
        }
    }
    
    
    if(self.textFieldEmail.text != 0){
        emails = [emails stringByAppendingString:self.textFieldEmail.text];
        emails = [emails stringByAppendingString:@","];
    }
    if([emails length]>0){
        emails = [emails substringToIndex:[emails length]-1];
    }
    
    [dict setValue:emails forKey:@"emails"];
    if (_challengeInfo==nil) {
        
        [dict setValue:@"newChallenge" forKey:@"action"];
    } else {
        
        [dict setValue:@"updateChallenge" forKey:@"action"];
    }
    
    [CGlobal showIndicator:self Tag:nil];
    NetworkParser* manager= [NetworkParser sharedManager];
    
    [manager generalNetwork:@"https://share-a-success.com/tpw72betk/webservices.php" Data:dict withCompletionBlock:^(NSDictionary *dict, NSError *error) {
        if (error == nil) {
            id obj = dict;
            TblChallenge* ret;
            if (useGmt) {
                ret = [[TblChallenge alloc] initWithDictionary:obj];
            }else{
                ret = [[TblChallenge alloc] initWithDictionary:obj];
            }
            AppDelegate* delegate = [[UIApplication sharedApplication] delegate];
            [delegate.dbManager insertChallengeData:ret];
            
            TblSortInfo*sortinfo = [[TblSortInfo alloc] init];
            sortinfo.id = ret.challenge_id;
            sortinfo.display_order = ret.display_order;
            sortinfo.name = ret.challenge_name;
            
            if (_challengeInfo == nil) {
                NSString* msg = @"";
                NSString* msg2 = @"";
                if ([_type isEqualToString:@"0"]) {
                    msg = [[NSBundle mainBundle] localizedStringForKey:@"New Challenge added!" value:@"" table:nil];
                    msg2 = [[NSBundle mainBundle] localizedStringForKey:@"Success!" value:@"" table:nil];
                }else{
                    msg = [[NSBundle mainBundle] localizedStringForKey:@"New Aim added!" value:@"" table:nil];
                    msg2 = [[NSBundle mainBundle] localizedStringForKey:@"Success!" value:@"" table:nil];
                }
                
                UIAlertView *alert = [[UIAlertView alloc]
                                      initWithTitle:msg
                                      message:msg2
                                      delegate:nil
                                      cancelButtonTitle:@"Ok"
                                      otherButtonTitles:nil];
                alert.delegate = [[UIApplication sharedApplication] delegate];
                [alert show];
                
                NSMutableArray*array = [delegate.dbManager getChallenges:nil];
                EnvVar*env = [CGlobal sharedId].env;
                if(env.tip_step == 0 && [array count] <= 1){
                    alert.tag = 100;
                }
                
                
            }else{
                NSString* msg = [[NSBundle mainBundle] localizedStringForKey:@"Challenge edited." value:@"" table:nil];
                [CGlobal AlertMessage:msg Title:nil];
                
                NSString* display_order = [NSString stringWithFormat:@"%ld",_challengeInfo.display_order];
                sortinfo.id = display_order;
            }
            [delegate.dbManager insertSortInfo:sortinfo];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_CHALLENGELIST_CHANGED object:nil];
            
            [self onTapCancelButton:sender];
        }else{
            NSString* msg = [[NSBundle mainBundle] localizedStringForKey:@"msg_0001" value:@"" table:nil];
            [CGlobal AlertMessage:msg Title:nil];
        }
        [CGlobal stopIndicator:self Tag:nil];
    } method:@"POST"];
    
}
// Message callback of the user selection for Withdraw.
- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        
        NSString *url = [NSString stringWithFormat:@"https://share-a-success.com/tpw72betk/webservices.php?custId=%@&challengeId=%@&status=%i&action=updateChallengeStatus", _challengeInfo.custId, _challengeInfo.challenge_id,0];
        [CGlobal showIndicator:self  Tag:nil];
        NetworkParser* manager = [NetworkParser sharedManager];
        [manager ontemplateGeneralRequestWithRawUrl:nil Path:url withCompletionBlock:^(NSDictionary *dict, NSError *error) {
            if (error == nil) {
                
                AppDelegate * delegate = [[UIApplication sharedApplication] delegate];
                [delegate.dbManager deleteChallenge:_challengeInfo];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_CHALLENGELIST_CHANGED object:nil];
                [self onTapCancelButton:alertView];
            }else{
                NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Failed to withdraw" value:@"" table:nil];
                NSString* alert = [[NSBundle mainBundle] localizedStringForKey:@"Alert" value:@"" table:nil];
                [CGlobal AlertMessage:temp Title:alert];
            }
            [CGlobal stopIndicator:self Tag:nil];
        }];
    }
}
#pragma -mark textFields
-(void)textFieldDidChange:(UITextField*)textField{
    if (textField == _textFieldEmail) {
        NSString *str = textField.text;
        if (![str isEqualToString:@""]) {
            [self filterArray:str];
        }else{
            _viewAutoComplete.hidden = true;
            [_scrollview setScrollEnabled:true];
            [_autocompleteTable setScrollEnabled:false];
        }
    }
}
-(void)filterArray:(NSString*)containsString{
    
    NSPredicate* predicate = [NSPredicate predicateWithFormat:@"(email contains[cd] %@ or name contains[cd] %@)",containsString,containsString];
    _mArrayFiltered = [[_emailList filteredArrayUsingPredicate:predicate] mutableCopy];
    
    if ([_mArrayFiltered count] == 0) {
        _viewAutoComplete.hidden = true;
        
        [_scrollview setScrollEnabled:true];
        [_autocompleteTable setScrollEnabled:false];
    }else{
        _viewAutoComplete.hidden = false;
        [_scrollview setScrollEnabled:false];
        [_autocompleteTable setScrollEnabled:true];
    }
    [_autocompleteTable reloadData];
}

#pragma -mark pickerView

// The number of columns of data
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    int tag = (int)pickerView.tag;
    if (tag>=100) {
        int index = tag - 100;
        
        if (index == 0) {
            return _aim_types[row];
        }else{
            if (_aim_type_index == 0) {
                // daily
                NSArray* data = _numbers_daily[index-1];
                return data[row];
            }else{
                NSArray* data = _numbers_weekly[index-1];
                return data[row];
            }
        }
        
    }
    return @"";
}

- (NSAttributedString *)pickerView:(UIPickerView *)pickerView attributedTitleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    
    
    int tag = (int)pickerView.tag;
    NSString* str = @"";
    if (tag>=100) {
        int index = tag - 100;
        
        if (index == 0) {
            str = _aim_types[row];
        }else{
            if (_aim_type_index == 0) {
                // daily
                NSArray* data = _numbers_daily[index-1];
                str = data[row];
            }else{
                NSArray* data = _numbers_weekly[index-1];
                str = data[row];
            }
        }
        
    }
    NSAttributedString *attString =
    [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName:[CGlobal colorWithHexString:@"ffffff" Alpha:1.0]}];
    
    return attString;
}

-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    int tag = (int)pickerView.tag;
    if (tag>=100) {
        int index = tag - 100;
        
        if (index == 0) {
            return _aim_types.count;
        }else{
            if (_aim_type_index == 0) {
                // daily
                NSArray* data = _numbers_daily[index-1];
                return data.count;
            }else{
                NSArray* data = _numbers_weekly[index-1];
                return data.count;
            }
        }
        
    }
    return 0;
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    int tag = (int)pickerView.tag;
    if (tag>=100) {
        int index = tag - 100;
        if (index == 0) {
            // change challenge_type to daily or weekly
            _aim_type_index = (int)row;
            _lblAimtype.text = _aim_types[_aim_type_index];
            
            NSArray* pkNumbers = @[_pkStepsAim,_pkWalkingAim,_pkCyclingAim,_pkStandingAim,_pkFlightsAim,_pkActiveAim,_pkSwimingAim];
            
            for (UIPickerView* picker in pkNumbers) {
                [picker reloadAllComponents];
            }
        }else{
            // change one field
            NSArray* lblAimLabels = @[_lblStepsAim,_lblWalkingAim,_lblCyclingAim,_lblStandingAim,_lblFlightsAim,_lblActiveAim,_lblSwimingAim];
            UILabel*label = lblAimLabels[index-1];
            
//            _numbers_daily = @[daily_steps,     daily_walking,  daily_cycling,  daily_stand,    daily_flight,   daily_energy,daily_swimming];
            
            if (_aim_type_index == 0) {
                // daily
                NSArray* data = _numbers_daily[index-1];
                NSArray* unit = _numbers_suffix[index-1];
//                label.text =  data[row];
                label.text = [NSString stringWithFormat:@"%@ %@",data[row],unit];
                
            }else{
                NSArray* data = _numbers_weekly[index-1];
//                label.text =  data[row];
                NSArray* unit = _numbers_suffix[index-1];
                label.text = [NSString stringWithFormat:@"%@ %@",data[row],unit];
            }
        }
        
        
    }
}
-(CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component{
    return 30.0;
}
@end

@implementation NSString (emailValidation)

-(BOOL) isValidEmail
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:self];
}



@end
