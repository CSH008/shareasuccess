//
//  ChallengeCell.m
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import "ChallengeCell.h"
#import "Utils.h"
#import "CGlobal.h"
#import "ChallengeViewController.h"

@implementation ChallengeCell

- (void)awakeFromNib {
    // Initialization code
    _labelGroup.textColor = [CGlobal colorWithHexString:@"#878787" Alpha:1.0f];        //878787
    _labelMyself.textColor = [CGlobal colorWithHexString:@"#878787" Alpha:1.0f];
    _lblType.textColor = [CGlobal colorWithHexString:@"#878787" Alpha:1.0f];
    
    
    NSArray *grImageArray = @[_imageGroup1,_imageGroup2,_imageGroup3,_imageGroup4,_imageGroup5];
    for (int i=0; i<[grImageArray count]; i++) {
        UIImageView* image = [grImageArray objectAtIndex:i];
        image.contentMode = UIViewContentModeScaleAspectFit;
        
    }
    
    _constraint_leading.constant = status_leading;
    _constraint_trailing.constant = status_trailing;
    
    _constraint_toolbar_top.constant = top_space - statusbar_gap1;
    
    [_labelChallengeName setFont:defaultFont];
    [_labelGroup setFont:defaultFont];
    [_labelMyself setFont:defaultFont];
    [_lblType setFont:defaultFont_Italic];
    
    [_labelChallengeName setTextColor:defaultColor_blue];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}
-(void)setDataForTblChallenge:(TblChallenge*)data{
    
    NSArray *myImageArray = @[_imageMy1,_imageMy2,_imageMy3,_imageMy4,_imageMy5];
    NSArray *grImageArray = @[_imageGroup1,_imageGroup2,_imageGroup3,_imageGroup4,_imageGroup5];
    NSArray *syImageArray = @[_imageSymbol1,_imageSymbol2,_imageSymbol3,_imageSymbol4,_imageSymbol5];
    
    for (int i=0; i<[myImageArray count]; i++) {
        UIImageView* myimage = [myImageArray objectAtIndex:i];
        UIImageView* grimage = [grImageArray objectAtIndex:i];
        UIImageView* syimage = [syImageArray objectAtIndex:i];
        myimage.image = nil;
        grimage.image = nil;
        syimage.image = nil;
    }
    
    _labelChallengeName.text = [NSString stringWithFormat:@"%@ (%ld)",data.challenge_name,data.total];
    
    int type = [data.type intValue];
    
    NSArray* aimValues = [data getAimValues];
    int nCount = 0;
    NSArray* imgNames = @[@"exe_steps",@"exe_walking",@"exe_cycling",@"exe_standing",@"exe_flights",@"exe_activeenergy",@"exe_swim"];
    
    if (type == 0) {
        NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Challenge" value:@"" table:nil];
        _lblType.text = temp;
        NSArray* challenge_values = [data getChallengeValues];
        for (int i=0; i<challenge_values.count; i++) {
            int val = [challenge_values[i] intValue];
            if (val == 1) {
                UIImageView* myimage = myImageArray[nCount];
                UIImageView* grimage = grImageArray[nCount];
                UIImageView* syimage = syImageArray[nCount];
                
                int myindex = [data.colors_my[i] intValue];
                int grindex = [data.colors_gr[i] intValue];
                NSString* imgname = imgNames[i];
                
                myimage.image = [UIImage imageNamed:g_listColor[myindex]];
                grimage.image = [UIImage imageNamed:g_listColor[grindex]];
                syimage.image = [UIImage imageNamed:imgname];
                nCount++;
            }
            if (nCount==5) {
                break;
            }
        }
    }else{
        NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Aim" value:@"" table:nil];
        _lblType.text = temp;
        NSArray* challenge_values = [data getAimValues];
        for (int i=0; i<challenge_values.count; i++) {
            float val = [challenge_values[i] floatValue];
            if (val > 0 ) {
                UIImageView* myimage = myImageArray[nCount];
                UIImageView* grimage = grImageArray[nCount];
                UIImageView* syimage = syImageArray[nCount];
                
                int myindex = [data.colors_my[i] intValue];
                int grindex = [data.colors_gr[i] intValue];
                NSString* imgname = imgNames[i];
                
                myimage.image = [UIImage imageNamed:g_listColor[myindex]];
                grimage.image = [UIImage imageNamed:g_listColor[grindex]];
                syimage.image = [UIImage imageNamed:imgname];
                nCount++;
            }
            if (nCount==5) {
                break;
            }
        }
    }
}
@end



