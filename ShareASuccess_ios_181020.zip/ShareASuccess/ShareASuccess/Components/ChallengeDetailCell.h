//
//  ChallengeDetailCell.h
//  Fit
//
//  Create by Denis on 2/24/16.
//
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblHealthData.h"
#import "TblInvitee.h"
#import "TblChallenge.h"
#import "TblWinnerInfo.h"

@interface ChallengeDetailCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelSteps;
@property (weak, nonatomic) IBOutlet UILabel *labelCycling;
@property (weak, nonatomic) IBOutlet UILabel *labelWalking;
@property (weak, nonatomic) IBOutlet UILabel *labelStanding;
//@property (weak, nonatomic) IBOutlet UILabel *labelActive;
@property (weak, nonatomic) IBOutlet UILabel *labelFlights;

@property (assign, nonatomic) CGFloat fontsize;

-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;


@end
