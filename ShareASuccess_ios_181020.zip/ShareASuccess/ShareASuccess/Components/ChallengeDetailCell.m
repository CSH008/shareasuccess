//
//  ChallengeDetailCell.m
//  Fit
//
//  Create by Denis on 2/24/16.
//
//

#import "ChallengeDetailCell.h"
#import "CGlobal.h"

@implementation ChallengeDetailCell

-(void)awakeFromNib{
    [super awakeFromNib];
    UILabel* myimage1 = _labelSteps;
    UILabel* myimage2 = _labelWalking;
    UILabel* myimage3 = _labelCycling;
    UILabel* myimage4 = _labelStanding;
    UILabel* myimage5 = _labelFlights;
    
    NSMutableArray *myImageArray = [[NSMutableArray alloc] initWithObjects:myimage1,myimage2,myimage3,myimage4,myimage5,nil];
    
    
    CGRect rect = [[UIScreen mainScreen] bounds];
    if (rect.size.width<=320) {
        
        _fontsize = 11.0;
    }else{
        _fontsize = 12.0;
    }
    
    for (int i=0; i<[myImageArray count]; i++) {
        UILabel* label = [myImageArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
//        [label setFont:[UIFont systemFontOfSize:_fontsize]];
        [label setFont:defaultFont];
    }
    
    _constraint_trailing.constant = status_trailing;
    _constraint_leading.constant = status_leading;
    
    [_labelName setFont:defaultFont];
    
}
-(NSString *)commonValue :(NSString *)value
{
    
    if (value)
    {
        if ([value isEqualToString:@"-"])
        {
            return @"-";
        }
        else
        {
            return [NSString stringWithFormat:@"%d",[value intValue]];
        }
    }
    
    return @"";
    
}
-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo{
//    EnvVar*env = [CGlobal sharedId].env;
    if (invitee == nil) {
        _labelName.text = [[NSBundle mainBundle] localizedStringForKey:@"Myself" value:@"" table:nil];
    }else{
        
        if (invitee.fname == nil || [invitee.fname isEqualToString:@""]) {
            _labelName.text = invitee.email_address;
        }else{
            _labelName.text = invitee.fname;
        }
    }
    
    if (winnerinfo!=nil) {
        NSMutableArray* ids = [[NSMutableArray alloc] init];
        [ids addObject:winnerinfo.steps];
        [ids addObject:winnerinfo.walking_running];
        [ids addObject:winnerinfo.cycling_distance];
        [ids addObject:winnerinfo.stand_hours];
        [ids addObject:winnerinfo.flights_climbed];
        [ids addObject:winnerinfo.active_energy];
        [ids addObject:winnerinfo.swim];
        if ([ids containsObject:data.custId]) {
            [_labelName setTextColor:[CGlobal colorWithHexString:@"#d8da59" Alpha:1.0f]];
        }else{
            [_labelName setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        }
    }else{
        [_labelName setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
    }
    
    UILabel* myimage1 = _labelSteps;
    UILabel* myimage2 = _labelWalking;
    UILabel* myimage3 = _labelCycling;
    UILabel* myimage4 = _labelStanding;
    UILabel* myimage5 = _labelFlights;
    
    NSArray *myImageArray = @[myimage1,myimage2,myimage3,myimage4,myimage5];
    for (int i=0; i<[myImageArray count]; i++) {
        UILabel* label = [myImageArray objectAtIndex:i];
        label.text = @"";
        [label setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        [label setFont:[UIFont systemFontOfSize:_fontsize]];
    }
    
    NSArray* dayValues = [data getHealthValues];
    NSArray* dayValues_Series = [data getHealthStrValues];
    NSArray* chValues = [challenge getChallengeValues];
    NSArray* winnerIds = [winnerinfo getStrValues];
    
    int nCount = 0;
    for (int i=0; i<dayValues.count; i++) {
        int chVal = [chValues[i] intValue];
        if (chVal == 1) {
            UILabel* mylabel = myImageArray[nCount];
            mylabel.text = dayValues_Series[i];
            NSMutableArray*leading = challenge.leading_val[i];
            if ([leading containsObject:data.custId]) {
                [mylabel setTextColor:[CGlobal colorWithHexString:@"#63b55a" Alpha:1.0f]];
                [mylabel setFont:[UIFont boldSystemFontOfSize:_fontsize]];
            }
            if ([data.custId isEqualToString:winnerIds[i]]) {
                [mylabel setTextColor:[CGlobal colorWithHexString:@"#d8da59" Alpha:1.0f]];
                [mylabel setFont:[UIFont boldSystemFontOfSize:_fontsize]];
            }
            nCount++;
        }
        if (nCount == 5) {
            break;
        }
    }
    
}
@end
