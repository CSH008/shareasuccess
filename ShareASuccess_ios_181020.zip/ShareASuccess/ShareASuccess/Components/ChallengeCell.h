//
//  ChallengeCell.h
//  Fit
//
//  Create by Denis on 2/23/16.
//
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblChallenge.h"

@interface ChallengeCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *labelChallengeName;
//@property (weak, nonatomic) IBOutlet UILabel *labelChallengeInfo;
@property (weak, nonatomic) IBOutlet UILabel *labelGroup;
@property (weak, nonatomic) IBOutlet UILabel *labelMyself;

@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol1;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol2;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol3;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol4;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol5;
//@property (weak, nonatomic) IBOutlet UIImageView *imageSymbolFlights;

@property (weak, nonatomic) IBOutlet UIImageView *imageMy1;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy2;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy3;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy4;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy5;
//@property (weak, nonatomic) IBOutlet UIImageView *imageMyFlights;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup1;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup2;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup3;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup4;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup5;
//@property (weak, nonatomic) IBOutlet UIImageView *imageGroupFlights;
//@property (weak, nonatomic) IBOutlet UIButton *btnSelection;

@property (weak, nonatomic) IBOutlet UIView *view_root;

//-(void)setData:(ChallengeInfo*)data;
-(void)setDataForTblChallenge:(TblChallenge*)data;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (weak, nonatomic) IBOutlet UILabel *lblType;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_toolbar_top;
@end
