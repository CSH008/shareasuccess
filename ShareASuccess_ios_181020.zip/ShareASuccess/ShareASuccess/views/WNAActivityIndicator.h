//
//  WNAActivityIndicator.h
//  Wordpress News App
//

#import <UIKit/UIKit.h>
@interface WNAActivityIndicator : UIView

- (id)initWithViewController:(UIView*)view;
@end
