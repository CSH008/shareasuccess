//
//  HelpDialog.h
//  ShareASuccess
//
//  Created by BoHuang on 9/5/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyPopupDialog.h"
@interface HelpDialog : UIView<UIScrollViewDelegate>


//@property (nonatomic,assign) int viewMode;

@property (nonatomic,strong) IBOutlet UIView* viewRoot;

@property (nonatomic,strong) id<ViewDialogDelegate> aDelegate;

@property (weak, nonatomic) IBOutlet UIViewController* vc;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
//@property (weak, nonatomic) IBOutlet UIScrollView *scrollViewAim;
//@property (weak, nonatomic) IBOutlet UIScrollView *scrollViewCh;

-(void)firstProcess:(CGRect)viewRootRect;
@end
