
#import "EnvVar.h"
#import "macros.h"
#import "CGlobal.h"
#import "NetworkParser.h"
//Login keys
static NSString * kDefaultsUserNameKey = @"username";
static NSString * kDefaultsPasswordKey = @"password";

//updated keys
static NSString * kDefaultsLastLoggedInKey = @"LASTLOGGEDIN";

//My own keys


@interface EnvVar()
{
    BOOL bSaveDefaults;
}
@end

@implementation EnvVar

- (long) udLong:(NSString *)key default:(long)v
{
    if (UDValue(key))
    {
        return UDInteger(key);
    }
    else
    {
        //set default value and return default value;
        UDSetInteger(key, v);
        UDSync();
        return v;
    }
}
- (void) loadFromDefaults
{
    
    _username = UDValue(kDefaultsUserNameKey);
    _password = UDValue(kDefaultsPasswordKey);
    
    _lastLogin = UDInteger(kDefaultsLastLoggedInKey);
    _lastSyncStatus = UDInteger(@"lastSyncStatus");
    _custId = [NSString stringWithFormat:@"%ld",_lastLogin];
    _myUsers  = UDValue(@"myUsers");
    _token = UDValue(@"token");
    _fbid = UDValue(@"fbid");
    _fname = UDValue(@"fname");
    _lname = UDValue(@"lname");
    _user_status = UDValue(@"user_status");
    _screen = UDValue(@"screen");
    _public_share = UDValue(@"public_share");
    _language = UDValue(@"language");
    _user_timezone= UDValue(@"user_timezone");
    _email= UDValue(@"email");
    _push_enabled = UDValue(@"push_enabled");
    _profile_image = UDValue(@"profile_image");
    
    _lastMySyncDay= UDValue(@"lastMySyncDay");
    _lastwinnerdate = UDValue(@"lastwinnerdate");
    _historyVersion = UDValue(@"historyVersion");
    
    _my_invitee_pending= UDInteger(@"my_invitee_pending");
    _friends_invitee_pending= UDInteger(@"friends_invitee_pending");
    _total_invitee_pending= UDInteger(@"total_invitee_pending");
//    _chat_lasttime = UDValue(@"chat_lasttime");
    _tip_step= UDInteger(@"tip_step");
    
    _lastChallengeCount = UDInteger(@"lastChallengeCount");
    _backGroundStatus = 0;
    
//    if(_chat_lasttime == nil){
//        _chat_lasttime = @"0";
//    }
    if (_token == nil) {
        _token = @"123456789";
    }
    
    if (_pushtoken == nil) {
        _pushtoken = @"";
    }
}

- (id) init
{
    self = [super init];
    if (self != nil)
    {
        bSaveDefaults = YES;
        [self loadFromDefaults];
    }
    return self;
}

- (id) initTemp
{
    self = [super init];
    if (self != nil)
    {
        bSaveDefaults = NO;
    }
    return self;
}

#pragma mark - Login environment variables....
- (void)saveDefaults:(NSString *)key value:(id)obj
{
    if (bSaveDefaults)
    {
        if (obj != nil)
            UDSetValue(key, obj);
        else
            UDRemove(key);
        UDSync();
    }

}

- (void)saveDefaultsLong:(NSString *)key value:(long)v
{
    if (bSaveDefaults)
    {
        UDSetInteger(key, v);
        UDSync();
    }
}
- (void)setUsername:(NSString *)username
{
    _username = [username copy];
    [self saveDefaults:kDefaultsUserNameKey value:username];
}

- (void)setPassword:(NSString *)password
{
    _password = password;
    [self saveDefaults:kDefaultsPasswordKey value:password];
}
-(void)setEmail:(NSString *)email{
    _email = email;
    [self saveDefaults:@"email" value:email];
}
-(void)setPush_enabled:(NSString *)push_enabled{
    _push_enabled = push_enabled;
    [self saveDefaults:@"push_enabled" value:push_enabled];
}
-(void)setProfile_image:(NSString *)profile_image{
    _profile_image = profile_image;
    [self saveDefaults:@"profile_image" value:profile_image];
}
- (BOOL)hasLoginDetails
{
    return self.username != nil && self.password != nil;
}

- (void)logOut
{
    [self setLastLogin:-1];
    [self setUsername:@""];
    [self setPassword:@""];
    
    _lastSyncStatus = GLOBAL_SYNC_FIRSTTIME;
    [self saveDefaultsLong:@"lastSyncStatus" value:GLOBAL_SYNC_FIRSTTIME];
    
    
    
    _fname = @"";
    [self saveDefaults:@"fname" value:_fname];
    _lname = @"";
    [self saveDefaults:@"lname" value:_lname];
    _screen = @"";
    [self saveDefaults:@"screen" value:_screen];
    _language = @"";
    [self saveDefaults:@"language" value:_language];
    _user_status = @"";
    [self saveDefaults:@"user_status" value:_user_status];
    _user_timezone = @"";
    [self saveDefaults:@"user_timezone" value:_user_timezone];
    _public_share = @"";
    [self saveDefaults:@"public_share" value:_public_share];
    
    _lastMySyncDay = nil;
    [self saveDefaults:@"lastMySyncDay" value:nil];
    _my_invitee_pending = 0;
    [self saveDefaultsLong:@"my_invitee_pending" value:_my_invitee_pending];
    _friends_invitee_pending = 0;
    [self saveDefaultsLong:@"friends_invitee_pending" value:_friends_invitee_pending];
    _total_invitee_pending = 0;
    [self saveDefaultsLong:@"total_invitee_pending" value:_total_invitee_pending];
    
//    _chat_lasttime = @"0";
//    [self saveDefaults:@"chat_lasttime" value:_chat_lasttime];
    
    _myUsers = @"";
    [self saveDefaults:@"myUsers" value:_myUsers];
}


#pragma mark - Other Preference Values
- (void)setLastLogin:(long)lastLogin
{
    NSLog(@"setLastLogin %ld",lastLogin);
    _lastLogin = lastLogin;
    _custId = [NSString stringWithFormat:@"%ld",lastLogin];
    [self saveDefaultsLong:kDefaultsLastLoggedInKey value:lastLogin];
}
-(void)setLastSyncStatus:(long)lastSyncStatus{
    _lastSyncStatus = lastSyncStatus;
    [self saveDefaultsLong:@"lastSyncStatus" value:_lastSyncStatus];
    
    switch (lastSyncStatus) {
        case GLOBAL_SYNC_FIRSTTIME:{
//            NSLog(@"GLOBAL_SYNC_FIRSTTIME");
            break;
        }
        case GLOBAL_SYNC_INITIAL:{
//            NSLog(@"GLOBAL_SYNC_INITIAL");
            break;
        }
        case GLOBAL_SYNC_COLLECTING:{
//            NSLog(@"GLOBAL_SYNC_COLLECTING");
            break;
        }
        case GLOBAL_SYNC_COLLECTING_DONE:{
//            NSLog(@"GLOBAL_SYNC_COLLECTING_DONE");
            
            break;
        }
        case GLOBAL_SYNC_PUSHING:{
//            NSLog(@"GLOBAL_SYNC_PUSHING");
            break;
        }
        case GLOBAL_SYNC_PUSHING_DONE:{
//            NSLog(@"GLOBAL_SYNC_PUSHING_DONE");
            
            break;
        }
        case GLOBAL_SYNC_GETTING_MYINFO:{
//            NSLog(@"GLOBAL_SYNC_GETTING_MYINFO");
            break;
        }
        default:{
//            NSLog(@"GLOBAL_SYNC default  = %ld",lastSyncStatus);
            break;
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:GLOBALNOTIFICATION_SYNC_CHANGESTATUS object:@{@"status":[NSString stringWithFormat:@"%ld",lastSyncStatus]}];
}
-(void)setBackGroundStatus:(long)backGroundStatus{
    _backGroundStatus = backGroundStatus;
    
}
-(void)setMy_invitee_pending:(long)my_invitee_pending{
    _my_invitee_pending = my_invitee_pending;
    [self saveDefaultsLong:@"my_invitee_pending" value:_my_invitee_pending];
}
-(void)setFriends_invitee_pending:(long)friends_invitee_pending{
    _friends_invitee_pending = friends_invitee_pending;
    [self saveDefaultsLong:@"friends_invitee_pending" value:_friends_invitee_pending];
}
-(void)setTotal_invitee_pending:(long)total_invitee_pending{
    _total_invitee_pending = total_invitee_pending;
    [self saveDefaultsLong:@"total_invitee_pending" value:_total_invitee_pending];
}
//-(void)setChat_lasttime:(NSString*)chat_lasttime{
//    _chat_lasttime = chat_lasttime;
//    [self saveDefaults:@"chat_lasttime" value:_chat_lasttime];
//}
-(void)setMyUsers:(NSString *)myUsers{
    _myUsers = myUsers;
    [self saveDefaults:@"myUsers" value:myUsers];
}
-(void)setLastMySyncDay:(NSString *)lastMySyncDay{
    _lastMySyncDay = lastMySyncDay;
    [self saveDefaults:@"lastMySyncDay" value:lastMySyncDay];
}
-(void)setTip_step:(long)tip_step{
    _tip_step = tip_step;
    [self saveDefaultsLong:@"tip_step" value:tip_step];
}
-(void)setLastwinnerdate:(NSString *)lastwinnerdate{
    _lastwinnerdate = lastwinnerdate;
    [self saveDefaults:@"lastwinnerdate" value:lastwinnerdate];
}
-(void)setHistoryVersion:(NSString *)historyVersion{
    _historyVersion = historyVersion;
    [self saveDefaults:@"historyVersion" value:historyVersion];
}


//custom token
-(void) saveToken{
}

-(void)setLastChallengeCount:(long)lastChallengeCount{
    _lastChallengeCount = lastChallengeCount;
    [self saveDefaultsLong:@"lastChallengeCount" value:lastChallengeCount];
}

@end
