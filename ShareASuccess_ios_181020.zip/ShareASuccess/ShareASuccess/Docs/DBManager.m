//
//  DBManager.m
//  SQLite3DBSample
//
//  Created by Gabriel Theodoropoulos on 25/6/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import "DBManager.h"
#import <sqlite3.h>
#import "CGlobal.h"
#import "TblHealthData.h"
#import "TblChallenge.h"
#import "TblSortInfo.h"
#import "TblInvitee.h"
#import "BaseModel.h"
#import "TblInviteInfoData.h"
#import "TblSortInfo.h"

@interface DBManager()

@property (nonatomic, strong) NSString *documentsDirectory;

@property (nonatomic, strong) NSString *databaseFilename;
@property (nonatomic, strong) NSString *databaseFilename_Source;

@property (nonatomic, strong) NSMutableArray *arrResults;


-(void)copyDatabaseIntoDocumentsDirectory;

-(BOOL)runQuery:(const char *)query isQueryExecutable:(BOOL)queryExecutable;

@end


@implementation DBManager

#pragma mark - Initialization

-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename SourceName:(NSString* ) sourceName{
    self = [super init];
    if (self) {
        // Set the documents directory path to the documentsDirectory property.
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        self.documentsDirectory = [paths objectAtIndex:0];
        
        // Keep the database filename.
        self.databaseFilename = dbFilename;
        self.databaseFilename_Source = sourceName;
        
        // Copy the database file into the documents directory if necessary.
        [self copyDatabaseIntoDocumentsDirectory];
        
    }
    return self;
}
-(void) deleteDatabase:(NSString *)filepath{
    //delete file
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    BOOL fileExists = [fileManager fileExistsAtPath:filepath];
    
    if (fileExists)
    {
        BOOL success = [fileManager removeItemAtPath:filepath error:&error];
        if (!success) NSLog(@"Error: %@", [error localizedDescription]);
        
    }
}


#pragma mark - Private method implementation

-(void)copyDatabaseIntoDocumentsDirectory{
    // Check if the database file exists in the documents directory.
    NSString *destinationPath = [self.documentsDirectory stringByAppendingPathComponent:self.databaseFilename];
    NSLog(@"dbpath %@",destinationPath);
    if (![[NSFileManager defaultManager] fileExistsAtPath:destinationPath]) {
        // The database file does not exist in the documents directory, so copy it from the main bundle now.
        NSString *sourcePath = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:self.databaseFilename_Source];
        NSError *error;
        
        [[NSFileManager defaultManager] copyItemAtPath:sourcePath toPath:destinationPath error:&error];
        //[self deleteDatabase:sourcePath];
        
        // Check if any error occurred during copying and display it.
        if (error != nil) {
            NSLog(@"%@", [error localizedDescription]);
        }
        
        // this time app updated. 2016-10-21
        
    }else{
        NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
        
        NSString *build = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString *)kCFBundleVersionKey];
        
        // file already exists.
        float f_version = [version floatValue];
        if(f_version>=1.5){
            //
            NSString* query = @"SELECT name FROM sqlite_master WHERE type='table' AND name='tbl_winnerinfo'";
            NSArray *array = [self loadDataFromDB:query];
            if ([array count] == 0) {
                NSString* winnertable = @"CREATE TABLE `tbl_winnerinfo` (`id`	INTEGER,`challenge_id`	INTEGER,`date_for`	TEXT,`steps`	TEXT,`walking_running`	TEXT,`stand_hours`	TEXT,`active_energy`	TEXT,`cycling_distance`	TEXT,`flights_climbed`	TEXT)";
                [self executeQuery:winnertable];
            }
        }
        if(f_version>=4){
            // check chat table
            NSString* query = @"SELECT name FROM sqlite_master WHERE type='table' AND name='tbl_chat'";
            NSArray *array = [self loadDataFromDB:query];
            if ([array count] == 0) {
                NSString* winnertable = @"CREATE TABLE `tbl_chat` (    `id`    TEXT,    `user_id`    TEXT,    `user_name`    TEXT,    `msg`    TEXT,    `time_val`    REAL,    `ch_id`    TEXT,  `deleted`    TEXT , `last_seen`    TEXT);";
                [self executeQuery:winnertable];
            }
        }
        if(f_version>=2){
            // new version
            BOOL have = true;
            
            NSString*query = @"select swim from tbl_challenge limit 1";
            have = [self runQuery:[query UTF8String] isQueryExecutable:NO];
            // determine not have.
            
            if (!have) {
                NSArray* queries = @[@"ALTER TABLE tbl_challenge ADD COLUMN 'type' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'swim' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_steps' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_walking_running' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_cycling_distance' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_stand_hours' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_flights_climbed' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_active_energy' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_swim' TEXT;",
                                     @"ALTER TABLE tbl_challenge ADD COLUMN 'aim_type' TEXT;",
                                     @"ALTER TABLE tbl_healthdata ADD COLUMN 'swim' TEXT;",
                                     @"ALTER TABLE tbl_winnerinfo ADD COLUMN 'swim' TEXT;"
                                     ];
                for (int i=0; i<queries.count; i++) {
                    [self executeQuery:queries[i]];
                }
                
                
                queries = @[@"update tbl_healthdata set swim = '' ",
                            @"update tbl_winnerinfo set swim = '' ",
                            @"update tbl_challenge set type = '0', swim ='0', aim_steps = '0', aim_walking_running = '0', aim_cycling_distance = '0', aim_stand_hours = '0', aim_flights_climbed = '0', aim_active_energy = '0', aim_swim = '0', aim_type = '0' "];
                for (int i=0; i<queries.count; i++) {
                    [self executeQuery:queries[i]];
                }
                
                [self logout];
                
                EnvVar*env = [CGlobal sharedId].env;
                env.lastSyncStatus = GLOBAL_SYNC_FIRSTTIME;
                NSLog(@"passed");
            }
            
        }
    }
    //[self deleteDatabase:destinationPath];
}



-(BOOL)runQuery:(const char *)query isQueryExecutable:(BOOL)queryExecutable{
    // Create a sqlite object.
    sqlite3 *sqlite3Database;
    BOOL ret = true;
    
    // Set the database file path.
    NSString *databasePath = [self.documentsDirectory stringByAppendingPathComponent:self.databaseFilename];
    
    // Initialize the results array.
    if (self.arrResults != nil) {
        [self.arrResults removeAllObjects];
        self.arrResults = nil;
    }
    self.arrResults = [[NSMutableArray alloc] init];
    
    // Initialize the column names array.
    if (self.arrColumnNames != nil) {
        [self.arrColumnNames removeAllObjects];
        self.arrColumnNames = nil;
    }
    self.arrColumnNames = [[NSMutableArray alloc] init];
    
    
    // Open the database.
    BOOL openDatabaseResult = sqlite3_open([databasePath UTF8String], &sqlite3Database);
    if(openDatabaseResult == SQLITE_OK) {
        // Declare a sqlite3_stmt object in which will be stored the query after having been compiled into a SQLite statement.
        sqlite3_stmt *compiledStatement;
        
        // Load all data from database to memory.
        BOOL prepareStatementResult = sqlite3_prepare_v2(sqlite3Database, query, -1, &compiledStatement, NULL);
        if(prepareStatementResult == SQLITE_OK) {
            // Check if the query is non-executable.
            if (!queryExecutable){
                // In this case data must be loaded from the database.
                
                // Declare an array to keep the data for each fetched row.
                NSMutableArray *arrDataRow;
                
                // Loop through the results and add them to the results array row by row.
                while(sqlite3_step(compiledStatement) == SQLITE_ROW) {
                    // Initialize the mutable array that will contain the data of a fetched row.
                    arrDataRow = [[NSMutableArray alloc] init];
                    
                    // Get the total number of columns.
                    int totalColumns = sqlite3_column_count(compiledStatement);
                    
                    // Go through all columns and fetch each column data.
                    for (int i=0; i<totalColumns; i++){
                        // Convert the column data to text (characters).
                        char *dbDataAsChars = (char *)sqlite3_column_text(compiledStatement, i);
                        
                        // If there are contents in the currenct column (field) then add them to the current row array.
                        if (dbDataAsChars != NULL) {
                            // Convert the characters to string.
                            [arrDataRow addObject:[NSString  stringWithUTF8String:dbDataAsChars]];
                        }
                        
                        // Keep the current column name.
                        if (self.arrColumnNames.count != totalColumns) {
                            dbDataAsChars = (char *)sqlite3_column_name(compiledStatement, i);
                            [self.arrColumnNames addObject:[NSString stringWithUTF8String:dbDataAsChars]];
                        }
                    }
                    
                    // Store each fetched data row in the results array, but first check if there is actually data.
                    if (arrDataRow.count > 0) {
                        [self.arrResults addObject:arrDataRow];
                    }
                }
            }
            else {
                // This is the case of an executable query (insert, update, ...).
                
                // Execute the query.
                int executeQueryResults = sqlite3_step(compiledStatement);
                if (executeQueryResults == SQLITE_DONE) {
                    // Keep the affected rows.
                    self.affectedRows = sqlite3_changes(sqlite3Database);
                    
                    // Keep the last inserted row ID.
                    self.lastInsertedRowID = sqlite3_last_insert_rowid(sqlite3Database);
                }
                else {
                    // If could not execute the query show the error message on the debugger.
                    NSLog(@"DB Error: %s", sqlite3_errmsg(sqlite3Database));
                }
            }
        }
        else {
            // In the database cannot be opened then show the error message on the debugger.
            NSLog(@"%s", sqlite3_errmsg(sqlite3Database));
            ret = false;
        }
        
        // Release the compiled statement from memory.
        sqlite3_finalize(compiledStatement);
        
    }
    
    // Close the database.
    sqlite3_close(sqlite3Database);
    return ret;
}


#pragma mark - Public method implementation

-(NSArray *)loadDataFromDB:(NSString *)query{
    // Run the query and indicate that is not executable.
    // The query string is converted to a char* object.
    [self runQuery:[query UTF8String] isQueryExecutable:NO];
    
    // Returned the loaded results.
    return (NSArray *)self.arrResults;
}


-(void)executeQuery:(NSString *)query{
    // Run the query and indicate that is executable.
    [self runQuery:[query UTF8String] isQueryExecutable:YES];
}
-(NSString*)getLastSavedDate{
    EnvVar*env = [CGlobal sharedId].env;
    TblHealthData* data = nil;
    NSString*query = [NSString stringWithFormat:@"select * from tbl_healthdata where custId = '%@' order by `date` desc limit 1",env.custId];
    
    NSArray *array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblHealthData alloc] initWithArray:item];
    }
    return data.date;
}
-(NSString*)getLastWinnerDate{
    TblWinnerInfo* data = nil;
    NSString*query = @"select * from tbl_winnerinfo order by `date_for` desc limit 1";
    
    NSArray *array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblWinnerInfo alloc] initWithArray:item];
    }
    return data.date_for;
}
-(NSMutableArray*)getMaxMinDay{
    EnvVar*env = [CGlobal sharedId].env;
    TblHealthData* data = nil;
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    NSString*query = [NSString stringWithFormat:@"select * from tbl_healthdata where custId = '%@' order by `date` desc limit 1",env.custId];
    
    NSArray *array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblHealthData alloc] initWithArray:item];
        [ret addObject:data.date];
    }
    
    query = [NSString stringWithFormat:@"select * from tbl_healthdata where custId = '%@' order by `date` asc limit 1",env.custId];
    
    array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblHealthData alloc] initWithArray:item];
        [ret addObject:data.date];
    }
    
    return ret;
}
-(BOOL)insertHealthData:(TblHealthData*)data{
    [data checkForInsert];
    NSString*query = [NSString stringWithFormat:@"delete from tbl_healthdata where custId = '%@' and day = '%@'",data.custId,data.day];
    [self executeQuery:query];
//    NSLog(@"insertHealthData sql= %@ ",query);
    
    query = [BaseModel getInsertSql:data TableName:@"tbl_healthdata" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid",@"action",@"result",@"res",@"activeCalories",@"calorieGoal",@"users",@"t_steps",@"t_sleep",@"t_weight",@"t_exercise",@"t_standing",@"t_walking",@"t_cycling",@"t_flights",@"t_active_cal",@"t_cal_goal",@"t_swim", nil]];
             
    [self executeQuery:query];
    NSLog(@"insertHealthData sql= %@ ",query);
    return true;
}
-(BOOL)insertChallengeData:(TblChallenge*)data{
    
    
    NSString*query = [NSString stringWithFormat:@"delete from tbl_challenge where challenge_id = '%@'",data.challenge_id];
    [self executeQuery:query];
//    NSLog(@"insertChallengeData del sql= %@ ",query);
    
    query = [TblChallenge getInsertSql:data TableName:@"tbl_challenge"];
//    NSLog(@"insertChallengeData insert sql= %@ ",query);
    [self executeQuery:query];
    
    return true;
}
-(TblHealthData*)getHealthData:(NSDate*)day CustId:(NSString*)custId;    //  dd/mm/yy
{
    NSString*ddmmyy = [CGlobal getDayPartFromNSDate:day isGmt:useGmt];
    TblHealthData* data = nil;
    NSString*query = [NSString stringWithFormat:@"select * from tbl_healthdata where custId = '%@' and day = '%@'",custId,ddmmyy];
    //    NSLog(@"getHealthData sql= %@ ",query);
    
    NSArray *array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblHealthData alloc] initWithArray:item];
        
    }
    return data;
}
-(TblHealthData*)getHealthDataTo:(NSDate*)day CustId:(NSString*)custId Mode:(int)mode    //  dd/mm/yy
{
    NSDate*iDate = [CGlobal getMondayOfThisDate:day isGmt:useGmt];
    NSString*ddmmyy = [CGlobal getDayPartFromNSDate:day isGmt:useGmt];
    NSString* wherepart = @"";
    int k = 0;
    while(true){
        NSString*ppp = [CGlobal getDayPartFromNSDate:iDate isGmt:useGmt];
        NSString* temp = [NSString stringWithFormat:@"'%@',",ppp];
        wherepart = [wherepart stringByAppendingString:temp];
        
        if (mode == 0) {
            // to current day
            if ([ppp isEqualToString:ddmmyy] || k == 6) {
                break;
            }
        }else{
            // whole week
            if (k == 6) {
                break;
            }
        }
        
        iDate = [iDate dateByAddingTimeInterval:60*60*24*1];
        k++;
    }
    TblHealthData* sumInfo = nil;
    if (wherepart.length > 0) {
        wherepart = [wherepart substringToIndex:wherepart.length-1];
        wherepart = [NSString stringWithFormat:@"(%@)",wherepart];
    }
    
    NSString* query = [NSString stringWithFormat:@"select sum(steps) as steps,sum(walking) as walking,sum(cycling) as cycling,sum(standing) as standing,sum(flights) as flights,sum(active_cal) as active_cal,sum(swim) as swim  from tbl_healthdata where custId = '%@' and day in %@",custId,wherepart];
    NSArray* array = [self loadDataFromDB:query];
    
    if ([array count]>0) {
        NSArray*dict = array[0];
        sumInfo = [[TblHealthData alloc] init];
        sumInfo.steps = [dict objectAtIndex:0];
        sumInfo.walking = [dict objectAtIndex:1];
        sumInfo.cycling = [dict objectAtIndex:2];
        sumInfo.standing = [dict objectAtIndex:3];
        sumInfo.flights = [dict objectAtIndex:4];
        sumInfo.active_cal = [dict objectAtIndex:5];
        sumInfo.swim = [dict objectAtIndex:6];
    }else{
        sumInfo = [[TblHealthData alloc] initNull:@"-1" Date:[CGlobal getTimeStringFromDate:curDate isGmt:useGmt]];
        sumInfo.steps = @"0";
        sumInfo.walking = @"0";
        sumInfo.cycling = @"0";
        sumInfo.standing = @"0";
        sumInfo.flights = @"0";
        sumInfo.active_cal = @"0";
        sumInfo.swim = @"0";
        NSLog(@"DBManager HGC1");
    }
    
    
    return sumInfo;
}
-(TblWinnerInfo*)getWinnerData:(NSDate*)day1 Challenge:(NSString*)challenge_id;    //  yy-mm-dd
{
    NSDate*day = [CGlobal getMondayOfThisDate:day1 isGmt:useGmt];
    
    NSString*yymmdd = [CGlobal getDayPart1FromNSDate:day isGmt:useGmt];
    TblWinnerInfo* data = nil;
    NSString*query = [NSString stringWithFormat:@"select * from tbl_winnerinfo where challenge_id = '%@' and date_for = '%@'",challenge_id,yymmdd];
    //    NSLog(@"getHealthData sql= %@ ",query);
    
    NSArray *array = [self loadDataFromDB:query];
    if ([array count]>0) {
        NSArray*item = array[0];
        data = [[TblWinnerInfo alloc] initWithArray:item];
        
    }
    return data;
}
-(BOOL)replaceChallenges:(NSMutableArray*)listData{
    EnvVar* env = [CGlobal sharedId].env;
    NSString*query = [NSString stringWithFormat:@"delete from tbl_challenge where 1"];
    [self executeQuery:query];
//    NSLog(@"replaceChallenges del sql= %@ ",query);
    
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    for (int i=0; i< [listData count]; i++) {
        TblChallenge*item = listData[i];
        query = [TblChallenge getInsertSql:item TableName:@"tbl_challenge"];
        [self executeQuery:query];
        for (int j=0; j< [item.invitees count]; j++) {
            TblInvitee* invitee = item.invitees[j];
            [dict setObject:invitee.custid forKey:invitee.custid];
        }
        if (![item.custId isEqualToString:env.custId]) {
            [dict setObject:item.custId forKey:item.custId];
        }
    }
    
    NSString*users = @"";
    for (NSString* key in dict) {
        if ([key isEqualToString:env.custId]) {
            continue;
        }
        users = [users stringByAppendingString:key];
        users = [users stringByAppendingString:@","];
    }
    if ([users length]>0) {
        users = [users substringToIndex:[users length]-1];
    }
    
    env.myUsers = users;
    
    return true;
}
-(BOOL)replaceInviteeInfo:(NSMutableArray*)listData{
    NSString*query = [NSString stringWithFormat:@"delete from tbl_invitedata where 1"];
    [self executeQuery:query];
//     NSLog(@"replaceInviteeInfo del sql= %@ ",query);
    
    for (int i=0; i< [listData count]; i++) {
        TblInviteInfoData*item = listData[i];
        query = [BaseModel getInsertSql:item TableName:@"tbl_invitedata" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid", nil]];
        [self executeQuery:query];
    }
    return true;
}
-(BOOL)replaceSortInfo:(NSMutableArray*)listData{
    NSString*query = [NSString stringWithFormat:@"delete from tbl_order where 1"];
    [self executeQuery:query];
//    NSLog(@"replaceSortInfo del sql= %@ ",query);
    
    for (int i=0; i< [listData count]; i++) {
        TblSortInfo*item = listData[i];
        query = [BaseModel getInsertSql:item TableName:@"tbl_order" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid", nil]];
        [self executeQuery:query];
    }
    return true;
}
-(BOOL)replaceWinnerInfo:(NSMutableArray*)listData{
    //    NSLog(@"replaceSortInfo del sql= %@ ",query);
    
    for (int i=0; i< [listData count]; i++) {
        TblWinnerInfo*item = listData[i];
        NSString*query = [NSString stringWithFormat:@"delete from tbl_winnerinfo where id = %@",item.id];
        [self executeQuery:query];
        
        query = [BaseModel getInsertSql:item TableName:@"tbl_winnerinfo" Exceptions:nil];
        [self executeQuery:query];
        NSLog(@"winnerinfo = %@",query);
    }
    return true;
}
-(BOOL)deleteChallenge:(TblChallenge*)data{
    NSString*query = [NSString stringWithFormat:@"delete from tbl_challenge where challenge_id = '%@'",data.challenge_id];
    [self executeQuery:query];
//    NSLog(@"deleteChallenge del sql= %@ ",query);
    
    return true;
}
-(BOOL)deleteInviteeInfo:(TblInviteInfoData*)data{
    NSString*query = [NSString stringWithFormat:@"delete from tbl_invitedata where reqId = '%@'",data.reqId];
    [self executeQuery:query];
//    NSLog(@"deleteInviteeInfo del sql= %@ ",query);
    
    return true;
}
-(BOOL)insertSortInfo:(TblSortInfo*)data{
    NSString*query = [NSString stringWithFormat:@"delete from tbl_order where id = '%@'",data.id];
    [self executeQuery:query];
//    NSLog(@"deleteInviteeInfo del sql= %@ ",query);
    
    TblSortInfo*item = data;
    query = [BaseModel getInsertSql:item TableName:@"tbl_order" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid", nil]];
    [self executeQuery:query];
    
    return true;
}
-(BOOL)logout{
    NSLog(@"DBManager logout");
    
    NSString*query = @"delete from tbl_healthdata";
    [self executeQuery:query];
    
    query = @"delete from tbl_challenge";
    [self executeQuery:query];
    
    query = @"delete from tbl_invitedata";
    [self executeQuery:query];
    
    query = @"delete from tbl_order";
    [self executeQuery:query];
    
    query = @"delete from tbl_winnerinfo";
    [self executeQuery:query];
    
    query = @"delete from tbl_chat";
    [self executeQuery:query];
    
    return true;
}
-(NSMutableArray*)getChallenges:(NSString*)date{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    NSString* query;
//    if (date == nil) {
//        query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id order by B.display_order asc, A.challenge_id desc"];
//    }else{
//        query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id where A.date_added <= '%@' order by B.display_order asc, A.challenge_id desc",date];
//    }
//    NSString* query0 = [NSString stringWithFormat:@"select A.* from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id where A.cancelled != 1 order by B.display_order asc, A.challenge_id desc"];
//    NSArray *array0 = [self loadDataFromDB: query0];
//    NSString* query1 = [NSString stringWithFormat:@"select * from tbl_challenge"];
//    NSArray *array1 = [self loadDataFromDB: query1];
//    
    query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id where A.cancelled != 1 order by B.display_order asc, A.challenge_id desc"];
    
    NSArray *array = [self loadDataFromDB:query];
    EnvVar *env = [CGlobal sharedId].env;
    
    if ([array count]>0) {
        for (int i=0; i< [array count]; i++) {
            NSArray*item = array[i];
            TblChallenge* data = [[TblChallenge alloc] initWithArray:item];
            if (date == nil) {
                [ret addObject:data];
            }else{
                NSString* inputdate = nil;
                if ([data.custId isEqualToString:env.custId]) {
                    // i created the challenge
                    inputdate = data.date_added;
                }else{
                    for (TblInvitee* invitee in data.invitees) {
                        if ([invitee.custid isEqualToString:env.custId] && [invitee.status isEqualToString:@"1"]) {
                            inputdate = invitee.accepted_date;
                        }
                    }
                }
                if (inputdate!=nil && [inputdate length] >= 10) {
                    NSString* mondaystr = inputdate;
                    int comp = [mondaystr compare:date] ;
                    if ([mondaystr compare:date] != NSOrderedDescending) {
                        [ret addObject:data];
                    }
                }
            }
            
        }
        
    }
    
    for (int i=0; i<ret.count; i++) {
        TblChallenge* data = ret[i];
        int count = [self notSeenMessages:data.challenge_id];
        data.msg_count = [NSString stringWithFormat:@"%d",count];
    }
    

    return ret;
}

-(long)getChallengeCountWithInvitees:(NSString*)date{
    NSString* query;
    //    if (date == nil) {
    //        query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id order by B.display_order asc, A.challenge_id desc"];
    //    }else{
    //        query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id where A.date_added <= '%@' order by B.display_order asc, A.challenge_id desc",date];
    //    }
    query = [NSString stringWithFormat:@"select A.*,B.display_order from tbl_challenge as A join tbl_order as B on A.challenge_id = B.id  where A.cancelled != 1 order by B.display_order asc, A.challenge_id desc"];
    
    NSArray *array = [self loadDataFromDB:query];
    
    return [array count];
}
-(NSMutableArray*)getSortInfo{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    NSString* query;
    query = [NSString stringWithFormat:@"select * from tbl_order order by display_order asc"];
    
    NSArray *array = [self loadDataFromDB:query];
    
    if ([array count]>0) {
        for (int i=0; i< [array count]; i++) {
            NSArray*item = array[i];
            TblSortInfo* data = [[TblSortInfo alloc] initWithArray:item];
            [ret addObject:data];
        }
        
    }
    
    return ret;
}
-(NSMutableArray*)getInviteeInfo{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    NSString* query;
    query = [NSString stringWithFormat:@"select A.*,B.total,B.pending from tbl_invitedata as A join tbl_challenge as B  on A.challenge_id = B.challenge_id where A.type = 1"];
    
    query = @"select * from tbl_invitedata where type = 1 order by rowid asc";
    
    NSArray *array = [self loadDataFromDB:query];
    
    if ([array count]>0) {
        for (int i=0; i< [array count]; i++) {
            NSArray*item = array[i];
            TblInviteInfoData* data = [[TblInviteInfoData alloc] initWithArray:item];
            [ret addObject:data];
        }
        
    }
    return ret;
}
-(BOOL)insertChatData:(TblChat*)data{
    [data checkForInsert];
    
    NSString* query = [BaseModel getInsertSql:data TableName:@"tbl_healthdata" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid",nil]];
    
    [self executeQuery:query];
    NSLog(@"insertChatData sql= %@ ",query);
    return true;
}
-(TblChat*)lastChatFor:(TblChallenge*)challenge{
    NSString* query = [NSString stringWithFormat:@"select * from tbl_chat where ch_id = %@ order by time_val desc",challenge.challenge_id];
    NSArray *array = [self loadDataFromDB:query];
    if (array.count>0) {
        TblChat* model = [[TblChat alloc] initWithArray:array[0]];
        return model;
    }
    return nil;
}
-(BOOL)insertOrUpdateChatData:(TblChat*)data{
    [data checkForInsert];
    
    NSString* query = [NSString stringWithFormat:@"select * from tbl_chat where id = %@",data.id];
    NSArray *array = [self loadDataFromDB:query];
    if (array.count == 0) {
        // insert
        query = [BaseModel getInsertSql:data TableName:@"tbl_chat" Exceptions:[[NSMutableArray alloc] initWithObjects:@"rowid",nil]];
        
        [self executeQuery:query];
        NSLog(@"insertChatData sql= %@ ",query);
        return true;
    }else{
        // update
        query = [BaseModel getUpdateSql:data TableName:@"tbl_chat" WhereField:@"id" WhereValue:data.id];
        [self executeQuery:query];
        NSLog(@"updateChatData sql= %@ ",query);
        return true;
    }
}
-(NSMutableArray*)loadChat:(TblChallenge*)challenge TIME:(NSString*)last_time{
    NSMutableArray* ret = [[NSMutableArray alloc] init];
    NSString* query;
    query = [NSString stringWithFormat:@"select * from tbl_chat where ch_id = %@ and deleted != '1' order by time_val asc ",challenge.challenge_id];
    if(last_time!=nil){
        query = [NSString stringWithFormat:@"select * from tbl_chat where ch_id = %@  and time_val > %@ and deleted != '1' order by time_val asc ",challenge.challenge_id,last_time];
    }
    
    NSArray *array = [self loadDataFromDB:query];
    
    if ([array count]>0) {
        for (int i=0; i< [array count]; i++) {
            NSArray*item = array[i];
            TblChat* data = [[TblChat alloc] initWithArray:item];
            [ret addObject:data];
        }
        
    }
    return ret;
}

-(int)notSeenMessages:(NSString*)ch_id{
    NSString* query;
    query = [NSString stringWithFormat:@"select * from tbl_chat where ch_id = %@ and last_seen = '1' and deleted != '1' order by time_val desc limit 1",ch_id];
    NSArray *array = [self loadDataFromDB:query];
    
    int count = 0;
    if ([array count]>0) {
        TblChat* lastSeenMsg = [[TblChat alloc] initWithArray:array[0]];
        
        query = [NSString stringWithFormat:@"select * from tbl_chat where time_val > %@ and ch_id = '%@' and deleted != '1' ",lastSeenMsg.time_val,ch_id];
        NSArray *list_msg = [self loadDataFromDB:query];
        count = list_msg.count;
    }else{
        query = [NSString stringWithFormat:@"select * from tbl_chat where ch_id = '%@' and deleted != '1' ",ch_id];
        NSArray *list_msg = [self loadDataFromDB:query];
        count = list_msg.count;
    }
    
    return count;
}
//-(WNACountry*)getCountryFromWebcode:(NSString *)param{
//    WNACountry* country = nil;
//    NSString* query;
//    query = [NSString stringWithFormat:@"select * from countries where webCode = '%@'",param];
//    
//    NSArray *array = [self loadDataFromDB:query];
//    
//    if ([array count]>0) {
//        NSArray*item = array[0];
//        country = [[WNACountry alloc] initWithArray:item];
//    }
//    
//    
//    return country;
//}
//-(WNACountry*)getCountryFromName:(NSString *)param{
//    WNACountry* country = nil;
//    NSString* query;
//    query = [NSString stringWithFormat:@"select * from countries where countryName = '%@'",param];
//    
//    NSArray *array = [self loadDataFromDB:query];
//    
//    if ([array count]>0) {
//        NSArray*item = array[0];
//        country = [[WNACountry alloc] initWithArray:item];
//    }
//    
//    
//    return country;
//}
//-(NSMutableArray*)getCountries{
//    NSMutableArray* ret = [[NSMutableArray alloc] init];
//    NSString* query;
//    query = [NSString stringWithFormat:@"select * from countries where 1"];
//    
//    NSArray *array = [self loadDataFromDB:query];
//    
//    if ([array count]>0) {
//        for (int i=0; i< [array count]; i++) {
//            NSArray*item = array[i];
//            WNACountry* country = [[WNACountry alloc] initWithArray:item];
//            [ret addObject:country];
//        }
//        
//    }
//    
//    
//    return ret;
//}
@end
