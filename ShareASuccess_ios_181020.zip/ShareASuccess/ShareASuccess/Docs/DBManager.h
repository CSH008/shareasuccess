//
//  DBManager.h
//  SQLite3DBSample
//
//  Created by Gabriel Theodoropoulos on 25/6/14.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TblHealthData.h"
#import "TblChallenge.h"
#import "TblInvitee.h"
#import "TblInviteInfoData.h"
#import "TblSortInfo.h"
#import "TblWinnerInfo.h"
#import "TblChat.h"

@interface DBManager : NSObject

@property (nonatomic, strong) NSMutableArray *arrColumnNames;

@property (nonatomic) int affectedRows;

@property (nonatomic) long long lastInsertedRowID;



-(instancetype)initWithDatabaseFilename:(NSString *)dbFilename SourceName:(NSString* ) sourceName;

-(NSArray *)loadDataFromDB:(NSString *)query;

-(void)executeQuery:(NSString *)query;

-(NSString*)getLastSavedDate;    //  yyyy-mm-dd hh:mm:ss
-(BOOL)insertHealthData:(TblHealthData*)data;    //  delete by day and insert data
-(BOOL)insertChallengeData:(TblChallenge*)data;    

-(TblHealthData*)getHealthData:(NSDate*)date CustId:(NSString*)custId;    //  get data using format dd/mm/yy of date
-(TblHealthData*)getHealthDataTo:(NSDate*)day CustId:(NSString*)custId Mode:(int)mode;      //  0   to current      1 whoel week
-(TblWinnerInfo*)getWinnerData:(NSDate*)day Challenge:(NSString*)challenge_id;
-(BOOL)replaceChallenges:(NSMutableArray*)listData;
-(BOOL)replaceInviteeInfo:(NSMutableArray*)listData;
-(BOOL)replaceSortInfo:(NSMutableArray*)listData;
-(BOOL)replaceWinnerInfo:(NSMutableArray*)listData;

-(long)getChallengeCountWithInvitees:(NSString*)date;
-(NSMutableArray*)getChallenges:(NSString*)date;
-(NSMutableArray*)getSortInfo;
-(NSMutableArray*)getInviteeInfo;

-(NSMutableArray*)getMaxMinDay;     // yyyy-mm-dd
-(NSString*)getLastWinnerDate;
-(BOOL)deleteChallenge:(TblChallenge*)data;    //  delete by day and insert data
-(BOOL)deleteInviteeInfo:(TblInviteInfoData*)data;    //  delete by day and insert data
-(BOOL)insertSortInfo:(TblSortInfo*)data;

-(BOOL)logout;

-(BOOL)insertChatData:(TblChat*)data;
-(BOOL)insertOrUpdateChatData:(TblChat*)data;
-(NSMutableArray*)loadChat:(TblChallenge*)challenge TIME:(NSString*)last_time;
-(TblChat*)lastChatFor:(TblChallenge*)challenge;
-(int)notSeenMessages:(NSString*)ch_id;
@end
