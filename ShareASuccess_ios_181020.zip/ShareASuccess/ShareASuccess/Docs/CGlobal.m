//
//  CGlobal.m
//  SchoolApp
//
//  Created by apple on 9/24/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import "CGlobal.h"
#import "AppDelegate.h"
#import "NSString+Common.h"
#import "WNAActivityIndicator.h"
#import "TblChallenge.h"
#import "TblInvitee.h"
#import <AddressBook/AddressBook.h>
#import <AVFoundation/AVFoundation.h>
#import <Photos/Photos.h>

#import <SDWebImage/UIImageView+WebCache.h>

int gms_camera_zoom = 6;
BOOL useGmt=false;
BOOL useEncode=true;
BOOL g_fakeDevice = false;
int g_indicator_mode = 0;
CGFloat topPadding_help=20;
NSDictionary*g_launchoptions;


//NSString* g_baseUrl = @"http://192.168.1.108/adminuser";
NSString* g_baseUrl = @"https://share-a-success.com/tpw72betk/webservices.php";
//  tpw72betk    vbn87fjk
NSString* g_primaryUrl = @"https://share-a-success.com";
NSString* G_DEVICETOKEN;
BOOL g_lock = false;

NSString*   APISERVICE_IP_URL = @"http://ip-api.com/json";
NSString*   APISERVICE_MAP_URL = @"http://maps.googleapis.com/maps";
NSDate*   curDate;
int   appDidBecomeActive_Status;

NSString*   ACTION_LOGIN = @"/assets/rest/apns/login.php";
NSString*   ACTION_IOSPUSH = @"/iospush1/savetoken.php";
NSString*   ACTION_FRESH = @"/assets/rest/apns/loadfresh.php";
NSString*   ACTION_TOGO = @"/assets/rest/apns/loadtogo.php";
NSString*   ACTION_CONQUERED = @"/assets/rest/apns/loadconquered1.php";
NSString*   ACTION_TOGO_COUNTRY = @"/assets/rest/apns/loadtogo_country.php";
NSString*   ACTION_CONQUERED_COUNTRY = @"/assets/rest/apns/loadconquered_country.php";
NSString*   ACTION_UPLOAD = @"/assets/rest/apns/fileuploadmm.php";
NSString*   ACTION_LIKEPIC = @"/assets/rest/apns/actionlike.php";
NSString*   ACTION_REPORT = @"/assets/rest/apns/actionreport.php";
NSString*   ACTION_MAKEPOST = @"/assets/rest/apns/makepost.php";
NSString*   ACTION_COMMENT = @"/assets/rest/apns/actioncomment.php";
NSString*   ACTION_USERINFO = @"/assets/rest/apns/userinfo.php";
NSString*   ACTION_UPDATEPROFILE = @"/assets/rest/apns/updateprofile.php";

NSString*   ACTION_DEFAULTPROFILE = @"/assets/uploads/user1.png";

//basic info
NSString* sync_collect_start;
NSString* sync_collect_done;
NSString* sync_push_start;
NSString* sync_push_done;
NSString* sync_save_start;
NSString* sync_save_done;
NSArray* g_listColor;
NSArray* g_listColor_BK;
UIFont* defaultFont;
UIFont* defaultFont_Headline;
UIFont* defaultFont_Headline_Bold;
UIFont* defaultFont_Italic;
UIColor* defaultColor;
UIColor* defaultColor1;
UIColor* defaultColor_blue;
UIFont* abcAlena_bold;
UIFont* abcAlena_lightitalic;
UIFont* abcAlena_semibold;
UIFont* abcAlena_light;
UIFont* abcAlena_medium;
UIFont* abcAlena_regular;
UIFont* abcAlena_regularitalic;

NSString*  g_socket_addr = @"74.208.111.25";
int  g_socket_port = 8080;

// notifications
NSString *GLOBALNOTIFICATION_DATA_CHANGED_PHOTO = @"GLOBALNOTIFICATION_DATA_CHANGED_PHOTO";;
NSString *GLOBALNOTIFICATION_MAP_PICKLOCATION = @"GLOBALNOTIFICATION_MAP_PICKLOCATION";
NSString *GLOBALNOTIFICATION_RECEIVE_USERINFO_SUCC = @"GLOBALNOTIFICATION_RECEIVE_USERINFO_SUCC";
NSString *GLOBALNOTIFICATION_RECEIVE_USERINFO_FAIL = @"GLOBALNOTIFICATION_RECEIVE_USERINFO_FAIL";
NSString *GLOBALNOTIFICATION_CHANGEVIEWCONTROLLER = @"GLOBALNOTIFICATION_CHANGEVIEWCONTROLLER";
NSString *GLOBALNOTIFICATION_CHANGEVIEWCONTROLLERREBATE = @"GLOBALNOTIFICATION_CHANGEVIEWCONTROLLERREBATE";

NSString *GLOBALNOTIFICATION_MQTTPAYLOAD = @"GLOBALNOTIFICATION_MQTTPAYLOAD";
NSString *GLOBALNOTIFICATION_MQTTPAYLOAD_PROCESS = @"GLOBALNOTIFICATION_MQTTPAYLOAD_PROCESS";

NSString *GLOBALNOTIFICATION_TRENDINGRESET = @"GLOBALNOTIFICATION_TRENDINGRESET";
NSString *GLOBALNOTIFICATION_LIKEDBUTTON =  @"GLOBALNOTIFICATION_LIKEDBUTTON";

NSString *NOTIFICATION_RECEIVEUUID =  @"NOTIFICATION_RECEIVEUUID";
NSString *NOTIFICATION_TOOLBAR_CHANGE =  @"NOTIFICATION_TOOLBAR_CHANGE";
NSString *NOTIFICATION_TOOLBAR_BADGE =  @"NOTIFICATION_TOOLBAR_BADGE";
NSString *NOTIFICATION_MAIN_COMMON_NOTI =  @"NOTIFICATION_MAIN_COMMON_NOTI";
NSString *GLOBALNOTIFICATION_SYNC_CHANGESTATUS    = @"GLOBALNOTIFICATION_SYNC_CHANGESTATUS";
NSString *GLOBALNOTIFICATION_CHALLENGELIST_CHANGED    = @"GLOBALNOTIFICATION_CHALLENGELIST_CHANGED";
NSString *NOTIFICATION_RECEIVEMSG =  @"NOTIFICATION_RECEIVEMSG";

NSString *GLOBALNOTIFICATION_NOTICE    = @"GLOBALNOTIFICATION_NOTICE_SECOND";

//MENU HEIGHT

CGFloat GLOBAL_MENUWIDTH = 200;

UIColor* APP_COLOR_PRIMARY;
UIColor* APP_COLOR_PRIMARY_SECONDARY;
UIColor* APP_COLOR_BUTTON_PRIMARY;
UIColor* APP_COLOR_CELL_GRAY;
UIColor* APP_COLOR_DOT_RED;
UIColor* APP_COLOR_DOT_RED_OLD;
UIColor* APP_COLOR_DOT_GREEN;

UIColor* APP_COLOR_RED;
UIColor* APP_COLOR_GREEN;
UIColor* APP_COLOR_BLUE;
UIColor* APP_COLOR_YELLOW;
UIColor* APP_COLOR_NOCOLOR;

UIColor* APP_COLOR_DETAIL1;
UIColor* APP_COLOR_DETAIL2;
UIColor* APP_COLOR_DETAIL3;
UIColor* APP_COLOR_DETAIL_BACKGREEN;
UIColor* APP_COLOR_DETAIL_BACKRED;
UIColor* APP_COLOR_DETAIL_BACKYELLOW;

UIColor* APP_COLOR_COLOREDVIEW;
//enum {GLOBAL_SYNC_INITIAL = 0};
//const int GLOBAL_SYNC_COLLECTING= 1;
//const int GLOBAL_SYNC_COLLECTING_DONE= 2;
//const int GLOBAL_SYNC_PUSHING= 3;
//const int GLOBAL_SYNC_PUSHING_DONE= 4;

//common variables
NSMutableArray *g_buttonTitles;
UIFont * g_largefont;
CGFloat g_menuHeight = 90;
NSMutableArray* menu_bottomList;
NSMutableArray* menu_topList;
CGFloat status_leading;
CGFloat status_trailing;
CGFloat default_textfield_radius;
CGFloat statusbar_gap1;
CGFloat top_space;
CGFloat bottom_space;
CGFloat top_space_toolbar_title;

@implementation CGlobal

+(void)initSample{
    [self initConfig];
    
}
+(void)initConfig{
    
}


+ (CGlobal *)sharedId
{
    static dispatch_once_t onceToken;
    static CGlobal *instance = nil;
    dispatch_once(&onceToken, ^{
        instance = [[CGlobal alloc] init];
    });
    return instance;
}

- (id) init
{
    self = [super init];
    if (self != nil)
    {
        _env = [[EnvVar alloc] init];
    }
    return self;
}

// Common Funcs
+(void)makeCountLabel:(UILabel*) label{
    
}
+(void)makeTermsPrivacyForLabel: (TTTAttributedLabel *) label withUrl:(NSString*)urlString{
    //TTTAttributedLabel *tttLabel = ;
    NSString *labelText = label.text;
    
    NSRange r = [labelText rangeOfString:labelText];
    [label addLinkToURL:[NSURL URLWithString:urlString] withRange:r];
    
}
+(void)showIndicatorInWindow{
    int viewTag = 1998;
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[window viewWithTag:viewTag];
    if(activityIndicator == nil){
        activityIndicator = [[WNAActivityIndicator alloc] initWithViewController:window];
        activityIndicator.tag = viewTag;
    }
    if (![activityIndicator isDescendantOfView:window]) {
        [window addSubview:activityIndicator];
        activityIndicator.center = window.center;
    }
    activityIndicator.hidden = false;
}
+(void)stopIndicatorInWindow{
    int viewTag = 1998;
    
    UIWindow* window = [UIApplication sharedApplication].keyWindow;
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[window viewWithTag:viewTag];
    if(activityIndicator!=nil){
        [activityIndicator setHidden:YES];
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
}
+(void)showIndicator:(UIViewController*)viewcon Tag:(NSString*)tag{
    int viewTag = 1999;
    if (tag!=nil) {
        viewTag = [tag intValue];
    }
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[viewcon.view viewWithTag:viewTag];
    if(activityIndicator == nil){
        activityIndicator = [[WNAActivityIndicator alloc] initWithViewController:viewcon.view];
        activityIndicator.tag = viewTag;
    }
    if (![activityIndicator isDescendantOfView:viewcon.view]) {
        [viewcon.view addSubview:activityIndicator];
        activityIndicator.center = viewcon.view.center;
    }
    activityIndicator.hidden = false;
}
+(void)stopIndicator:(UIViewController*)viewcon Tag:(NSString*)tag{
    int viewTag = 1999;
    if (tag!=nil) {
        viewTag = [tag intValue];
    }
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[viewcon.view viewWithTag:viewTag];
    if(activityIndicator!=nil){
        [activityIndicator setHidden:YES];
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
    
//    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
+(void)showIndicatorForView:(UIView*)viewcon{
    if (viewcon==nil) {
        return;
    }
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[viewcon viewWithTag:1999];
    if(activityIndicator == nil){
        CGRect screenRect = [[UIScreen mainScreen] bounds];
        activityIndicator = [[WNAActivityIndicator alloc] initWithFrame:screenRect];
        activityIndicator.tag = 1999;
        [activityIndicator setHidden:NO];
    }
    if (![activityIndicator isDescendantOfView:viewcon]) {
        [viewcon addSubview:activityIndicator];
    }
}
+(void)stopIndicatorForView:(UIView*)viewcon{
    if (viewcon==nil) {
        return;
    }
    WNAActivityIndicator* activityIndicator = (WNAActivityIndicator*)[viewcon viewWithTag:1999];
    if(activityIndicator!=nil){
        [activityIndicator setHidden:YES];
        [activityIndicator removeFromSuperview];
        activityIndicator = nil;
    }
    
    //    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
}
//+(void)showIndicator:(UIViewController*)viewcon{
//    UIActivityIndicatorView* view = (UIActivityIndicatorView*)[viewcon.view viewWithTag:1000];
//    if(view == nil){
//        CGFloat width = 60.0;
//        CGFloat height = 60.0;
//        UIActivityIndicatorView *indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
//        
//        [indicatorView setColor:[UIColor colorWithRed:69.0/255.0 green:98.0/255.0 blue:163.0/255.0 alpha:1]];
//        indicatorView.center = viewcon.view.center;
//        indicatorView.tag = 1000;
//        [viewcon.view addSubview:indicatorView];
//        [viewcon.view bringSubviewToFront:indicatorView];
//        
//        view = indicatorView;
//    }
//    
//    view.hidden = false;
//    [viewcon.view bringSubviewToFront:view];
//    [view startAnimating];
//}
//+(void)stopIndicator:(UIViewController*)viewcon{
//    UIActivityIndicatorView* view = (UIActivityIndicatorView*)[viewcon.view viewWithTag:1000];
//    if(view != nil){
//        view.hidden = YES;
//        [view stopAnimating];
//    }
//}
+(void)removeIndicator:(UIViewController*)viewcon{
    UIActivityIndicatorView* view = (UIActivityIndicatorView*)[viewcon.view viewWithTag:1000];
    if(view != nil){
        [view removeFromSuperview];
    }
}
+(void)AlertMessage:(NSString*)message Title:(NSString*)title{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:title
                          message:message
                          delegate:nil
                          cancelButtonTitle:@"Ok"
                          otherButtonTitles:nil];
    [alert show];
}
+(void)makeBorderBlackAndBackWhite:(UIView*)target{
    target.layer.borderWidth = 1;
    target.layer.borderColor = [UIColor blackColor].CGColor;
    target.layer.masksToBounds = true;
}
+(void)makeBorderASUITextField:(UIView*)target{
    target.layer.borderWidth = 1;
    target.layer.borderColor = [UIColor blackColor].CGColor;
    target.layer.cornerRadius = 4;
    target.layer.masksToBounds = true;
}
+(CGFloat)heightForView:(NSString*)text Font:(UIFont*) font Width:(CGFloat) width{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, CGFLOAT_MAX)];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.font = font;
    label.text = text;
    [label sizeToFit];
    
    CGFloat height = MAX(label.frame.size.height, 21);
    return height;
}
+(CGSize)sizeForView:(NSString*)text Font:(UIFont*) font Width:(CGFloat) width{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, width, CGFLOAT_MAX)];
    label.numberOfLines = 0;
    label.lineBreakMode = NSLineBreakByWordWrapping;
    label.font = font;
    label.text = text;
    [label sizeToFit];
    
    CGFloat l_height = MAX(label.frame.size.height, 21);
    CGFloat l_width = MIN(label.frame.size.width, width);
    if (l_height == 21) {
        // calculate width
        label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 0, l_height)];
        label.numberOfLines = 1;
        label.lineBreakMode = NSLineBreakByWordWrapping;
        label.font = font;
        label.text = text;
        [label sizeToFit];
        
        return CGSizeMake(l_width, l_height);
    }else{
        return CGSizeMake(l_width, l_height);
    }
    
}
+(NSString*)generateFilePath{
    NSString*path = [NSString stringWithFormat:@"%ld", (long)[[NSDate date] timeIntervalSince1970]];
    path = [path stringByAppendingString:@".jpg"];
    NSString* uploadpath = [g_baseUrl stringByAppendingString:@"uploads/"];
    uploadpath = [uploadpath stringByAppendingString:path];
    
    return  uploadpath;
}

+(NSString*)getUDID{
    NSString *uuid = [[NSUUID UUID] UUIDString];
    return uuid;
}
+(void)setDefaultBackground:(UIViewController*)viewcon{
    UIImageView* view = (UIImageView*)[viewcon.view viewWithTag:2000];
    if(view == nil){
        view = [[UIImageView alloc] initWithFrame:viewcon.view.frame];
        view.image = [UIImage imageNamed:@"bg_shopping.png"];
        
        view.center = viewcon.view.center;
        view.tag = 2000;
        [viewcon.view addSubview:view];
        [viewcon.view sendSubviewToBack:view];
    }
}
+(int)getOrientationMode{
    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    int mode = 4;
    if (orientation == UIDeviceOrientationLandscapeLeft) {
        mode = 1;
    } else if (orientation == UIDeviceOrientationLandscapeRight) {
        mode = 2;
    } else if (orientation == UIDeviceOrientationPortraitUpsideDown) {
        mode = 3;
    } else if (orientation == UIDeviceOrientationPortrait) {
        mode = 4;
    }
    return mode;
}
+(NSString*) jsonStringFromDict:(BOOL) prettyPrint Dict:(NSDictionary*)dict{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict
                                                       options:(NSJSONWritingOptions)    (prettyPrint ? NSJSONWritingPrettyPrinted : 0)
                                                         error:&error];
    
    if (! jsonData) {
        NSLog(@"bv_jsonStringWithPrettyPrint: error: %@", error.localizedDescription);
        return @"{}";
    } else {
        return [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
}
+(NSString*)getEncodedString:(NSString*)input{
    NSCharacterSet *URLCombinedCharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@" \"#%/:<>?@[\\]^`,.&'{|}\n"] invertedSet];
    
    
    NSString *path = [input stringByAddingPercentEncodingWithAllowedCharacters:URLCombinedCharacterSet];
    return  path;
}
+ (NSString *) escapeString:(NSString *)string {
    NSRange range = NSMakeRange(0, [string length]);
    return [string stringByReplacingOccurrencesOfString:@"'" withString:@"''" options:NSCaseInsensitiveSearch range:range];
}

// datepicker and time

+(NSString*)getDateFromPickerForDb:(UIDatePicker*)datePicker{
    NSDate *myDate = datePicker.date;
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *prettyVersion = [dateFormat stringFromDate:myDate];
    return prettyVersion;
}
+(NSDate*)getDateFromDbString:(NSString*)string isGmt:(BOOL)isGmt{
    
    
    NSString *str =string;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *timezone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [formatter setTimeZone:timezone];
    }else{
        NSTimeZone *timezone = [NSTimeZone localTimeZone];
        [formatter setTimeZone:timezone];
    }
    
    
    NSDate* date = [formatter dateFromString:str];
    
    //    NSLog(@"%@",date);
    return date;
}
+(NSDate*)getLocalDateFromDbString:(NSString*)string isGmt:(BOOL)isGmt{
    
    
    NSString *str =string;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *timezone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [formatter setTimeZone:timezone];
    }else{
        NSTimeZone *timezone = [NSTimeZone localTimeZone];
        [formatter setTimeZone:timezone];
    }
    
    //    NSTimeZone* timezone = [NSTimeZone systemTimeZone];
    
    NSDate* date = [formatter dateFromString:str];
    
    //    NSLog(@"%@",date);
    return date;
    
}
+(NSString*)getDateStringAfterNDays:(NSString*)string isGmt:(BOOL)isGmt AfterTime:(long)time{
    
    if (string == nil || [string isEqualToString:@""]) {
        return nil;
    }
    
    NSString *str =string;
    NSDateFormatter *formatter = [[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    if (isGmt) {
        NSTimeZone *timezone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [formatter setTimeZone:timezone];
    }else{
        NSTimeZone *timezone = [NSTimeZone localTimeZone];
        [formatter setTimeZone:timezone];
    }
    
    //    NSTimeZone* timezone = [NSTimeZone systemTimeZone];
    
    NSDate* date = [formatter dateFromString:str];
    
    date = [date dateByAddingTimeInterval:time];
    
    NSString *dateRepresentation = [formatter stringFromDate:date];
    
    //    NSLog(@"%@",date);
    return dateRepresentation;
    
}
+(NSString*)getLocalDateFromDBString:(NSString*)string isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
    
    if (isGmt) {
        NSTimeZone *gmtTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormatter setTimeZone:gmtTimeZone];
    }else{
        NSTimeZone *gmtTimeZone = [NSTimeZone localTimeZone];
        [dateFormatter setTimeZone:gmtTimeZone];
    }
    
    [dateFormatter setDateFormat:@"YYYY-MM-dd HH:mm:ss"];
    NSDate *dateFromString = [dateFormatter dateFromString:string];
    NSLog(@"Input date as GMT: %@",dateFromString);
    
    NSTimeZone* sourceTimeZone = [NSTimeZone systemTimeZone];
    [dateFormatter setTimeZone:sourceTimeZone];
    NSString *dateRepresentation = [dateFormatter stringFromDate:dateFromString];
    NSLog(@"Date formated with local time zone: %@",dateRepresentation);
    
    return dateRepresentation;
}
+(NSString*)getGmtHour{
    NSDate* sourceDate = [NSDate date];
    
    NSTimeZone* sourceTimeZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    NSTimeZone* destinationTimeZone = [NSTimeZone systemTimeZone];
    //    NSTimeZone* destinationTimeZone = [NSTimeZone timeZoneWithName:@"America/New_York"];
    
    NSInteger sourceGMTOffset = [sourceTimeZone secondsFromGMTForDate:sourceDate];
    NSInteger destinationGMTOffset = [destinationTimeZone secondsFromGMTForDate:sourceDate];
    NSTimeInterval interval = destinationGMTOffset - sourceGMTOffset;
    
    NSDate* destinationDate = [[NSDate alloc] initWithTimeInterval:interval sinceDate:sourceDate] ;
    
    NSDate* sourceDateM = [[NSDate alloc] initWithTimeInterval:-interval sinceDate:destinationDate] ;
    
    NSUInteger componentFlags =  NSCalendarUnitHour|NSCalendarUnitMinute;
    //    NSDateComponents *compoenents = [[NSCalendar currentCalendar] components:componentFlags fromDate:destinationDate];
    
    NSDateComponents *compoenents = [[NSCalendar currentCalendar]  components:NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute fromDate:sourceDateM toDate:destinationDate options:0];
    
    NSInteger hour = [compoenents hour];
    NSInteger min = [compoenents minute];
    NSString *gmt = [NSString stringWithFormat:@"%d;%d",hour,min];
    
    return gmt;
}
+(NSString*)getCurrentTimeInGmt0{
    NSDate* sourceDate = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    NSString *prettyVersion = [dateFormat stringFromDate:sourceDate];
    
    return prettyVersion;
}
+(NSString*)getTimeStringFromDate:(NSDate*)sourceDate  isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *prettyVersion = [dateFormat stringFromDate:sourceDate];
    
    return prettyVersion;
}
+(NSString*)getTimePartStringFromDate:(NSDate*)sourceDate  isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *prettyVersion = [dateFormat stringFromDate:sourceDate];
    
    return prettyVersion;
}
+(NSString*)getFormattedTimeFormPicker:(UIDatePicker*)picker{
    return @"";
}
+(int)ageFromBirthday:(NSDate *)birthdate {
    NSDate *today = [NSDate date];
    NSString*date1 = [CGlobal getTimeStringFromDate:today isGmt:false];
    NSString*date2 = [CGlobal getTimeStringFromDate:birthdate isGmt:false];
    
    int age = [[date1 substringToIndex:4] intValue] - [[date2 substringToIndex:4] intValue];
    
//    NSDateComponents *ageComponents = [[NSCalendar currentCalendar]
//                                       components:NSYearCalendarUnit
//                                       fromDate:birthdate
//                                       toDate:today
//                                       options:0];
    return age;
}
+(NSString*)getTimeLeft:(NSString*)str_enddate{
    NSDate*endDate = [self getDateFromDbString:str_enddate isGmt:useGmt];
    NSDate*curDate = [NSDate date];
    
    if ([endDate compare:curDate] == NSOrderedAscending) {
        return @"Pending";
    }
    
    NSDateComponents *compoenents = [[NSCalendar currentCalendar]  components:NSCalendarUnitDay|NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond fromDate:curDate toDate:endDate options:0];
    
    
    NSInteger hour = [compoenents hour];
    NSInteger min = [compoenents minute];
    NSInteger sec = [compoenents second];
    NSString *gmt = [NSString stringWithFormat:@"%02d:%02d:%02d",hour,min,sec];
    
    return gmt;
}
+(NSNumber*)getNumberFromStringForCurrency:(NSString*)formatted_str{
    NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    [numberFormatter setCurrencySymbol:@""];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setMaximumFractionDigits:0];
    return [numberFormatter numberFromString:formatted_str];
}
+(NSString*)getStringFromNumberForCurrency:(NSNumber*)number{
    NSNumberFormatter* numberFormatter = [[NSNumberFormatter alloc] init];
    [numberFormatter setNumberStyle:NSNumberFormatterCurrencyStyle];
    [numberFormatter setCurrencySymbol:@""];
    [numberFormatter setGroupingSeparator:@","];
    [numberFormatter setGroupingSize:3];
    [numberFormatter setMaximumFractionDigits:0];
    return [numberFormatter stringFromNumber:number];
}
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert Alpha:(CGFloat)alpha
{
    NSString *noHashString = [stringToConvert stringByReplacingOccurrencesOfString:@"#" withString:@""]; // remove the #
    NSScanner *scanner = [NSScanner scannerWithString:noHashString];
    [scanner setCharactersToBeSkipped:[NSCharacterSet symbolCharacterSet]]; // remove + and $
    
    unsigned hex;
    if (![scanner scanHexInt:&hex]) return nil;
    int r = (hex >> 16) & 0xFF;
    int g = (hex >> 8) & 0xFF;
    int b = (hex) & 0xFF;
    
    return [UIColor colorWithRed:r / 255.0f green:g / 255.0f blue:b / 255.0f alpha:alpha];
}
+ (void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url withView:(UIView*)view withController:(UIViewController*)controller
{
    NSMutableArray *sharingItems = [NSMutableArray new];
    
    if (text) {
        [sharingItems addObject:text];
    }
    if (image) {
        [sharingItems addObject:image];
    }
    if (url) {
        [sharingItems addObject:url];
    }
    
    UIActivityViewController *activityController = [[UIActivityViewController alloc] initWithActivityItems:sharingItems applicationActivities:nil];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        activityController.popoverPresentationController.sourceView = view;
    }
    
    [controller presentViewController:activityController animated:YES completion:nil];
}
+ (NSString *)urlencode:(NSString*)param1 {
    NSMutableString *output = [NSMutableString string];
    const unsigned char *source = (const unsigned char *)[param1 UTF8String];
    int sourceLen = strlen((const char *)source);
    for (int i = 0; i < sourceLen; ++i) {
        const unsigned char thisChar = source[i];
        if (thisChar == ' '){
            [output appendString:@"+"];
        } else if (thisChar == '.' || thisChar == '-' || thisChar == '_' || thisChar == '~' ||
                   (thisChar >= 'a' && thisChar <= 'z') ||
                   (thisChar >= 'A' && thisChar <= 'Z') ||
                   (thisChar >= '0' && thisChar <= '9')) {
            [output appendFormat:@"%c", thisChar];
        } else {
            [output appendFormat:@"%%%02X", thisChar];
        }
    }
    return output;
}

+ (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize;
{
    
    UIGraphicsBeginImageContext( newSize );
    [image drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}
+ (UIImage*)getScaledImage:(UIImage*)image
{
    CGImageRef cgImage =  image.CGImage;
    
    CGFloat width = CGImageGetWidth(cgImage);
    CGFloat height = CGImageGetHeight(cgImage);
    
    if(width<1024){
        return image;
    }else{
        CGFloat newSizeWidth = 1024;
        CGFloat newSizeHeight = 1024;
        
        CGFloat scale = width / 1024.0;
        newSizeHeight = height / scale;
        
        return [CGlobal imageWithImage:image scaledToSize:CGSizeMake(newSizeWidth, newSizeHeight)];
    }
}
+(NSMutableArray*)getEmailAddressFromAdressBook{
    ABAddressBookRef m_addressbook = ABAddressBookCreate();
    CFArrayRef allPeople = ABAddressBookCopyArrayOfAllPeople(m_addressbook);
    CFIndex nPeople = ABAddressBookGetPersonCount(m_addressbook);
    
    NSMutableArray* ret= [[NSMutableArray alloc] init];
    
    for (int i=0;i < nPeople;i++) {
        
        
        ABRecordRef ref = CFArrayGetValueAtIndex(allPeople,i);
        
        //For username and surname
        ABMultiValueRef phones =(__bridge ABMultiValueRef)((__bridge NSString*)ABRecordCopyValue(ref, kABPersonPhoneProperty));
        CFStringRef firstName, lastName;
        firstName = ABRecordCopyValue(ref, kABPersonFirstNameProperty);
        lastName  = ABRecordCopyValue(ref, kABPersonLastNameProperty);
        
        
        //For Email ids
        ABMutableMultiValueRef eMail  = ABRecordCopyValue(ref, kABPersonEmailProperty);
        long count = ABMultiValueGetCount(eMail);
        if(count > 0) {
            for (int i=0; i<count; i++) {
                NSMutableDictionary *dOfPerson=[NSMutableDictionary dictionary];
                [dOfPerson setObject:[NSString stringWithFormat:@"%@ %@", firstName, lastName] forKey:@"name"];
                [dOfPerson setObject:(__bridge NSString *)ABMultiValueCopyValueAtIndex(eMail, i) forKey:@"email"];
//                [dOfPerson setObject:@"xxx@gmail.com" forKey:@"email"];
                [ret addObject:dOfPerson];
            }
            
        }
        //        NSLog(@"AAAAAAAABBBBBBBB       %i",i);
    }
    return ret;
    
}

// program specific
+ (void)makeStyle1:(UIView*)controller Mode:(int)mode{
    CGRect rect = controller.frame;
    CGFloat halfheight = rect.size.height/2;
    controller.layer.cornerRadius = halfheight;
    controller.layer.masksToBounds = true;
    if ([controller isKindOfClass:[UITextField class]]) {
        UITextField*textField = (UITextField*)controller;
        controller.backgroundColor = [ UIColor clearColor];
        controller.layer.borderWidth = 1;
        controller.layer.borderColor = [[CGlobal colorWithHexString:@"#97AEA0" Alpha:1.0f] CGColor];
        
        
        UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
        textField.leftView = paddingView;
        textField.leftViewMode = UITextFieldViewModeAlways;
        
        switch (mode) {
            case 1:{
                controller.layer.cornerRadius = default_textfield_radius;
                break;
            }
            default:{
                
                break;
            }
        }
    }
}
+(NSArray*)findAllTextFieldsInView:(UIView*)view{
    NSMutableArray* textfieldarray = [[NSMutableArray alloc] init];
    for(id x in [view subviews]){
        if([x isKindOfClass:[UITextField class]])
            [textfieldarray addObject:x];
        
        if([x isKindOfClass:[UIButton class]])
            [textfieldarray addObject:x];
        
        if([x respondsToSelector:@selector(subviews)]){
            // if it has subviews, loop through those, too
            [textfieldarray addObjectsFromArray:[self findAllTextFieldsInView:x]];
        }
    }
    return textfieldarray;
}
+(NSString*)getDayPart:(NSString*)date{
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@/%@/%@",dd,mm,yy];
    return ret;
}
+(NSString*)getDayPart1:(NSString*)date{
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@-%@-%@",yy,mm,dd];
    return ret;
}
+(NSString*)getDayPartFromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *date = [dateFormat stringFromDate:sourceDate];
    
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@/%@/%@",dd,mm,yy];
    return ret;
}
+(NSArray*)getDaySerialForWeek:(NSDate*)sourceDate isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *date = [dateFormat stringFromDate:sourceDate];
    
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@/%@/%@",dd,mm,yy];
    return ret;
}
+(NSString*)getDayPart1FromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *date = [dateFormat stringFromDate:sourceDate];
    
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
    NSString*ret = [NSString stringWithFormat:@"%@-%@-%@",yy,mm,dd];
    return ret;
}
+(NSString*)getDayPart2FromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSString *date = [dateFormat stringFromDate:sourceDate];
    
    if (date == nil || [date length] < 10) {
        return nil;
    }
    NSString*yy = [date substringWithRange:NSMakeRange(0, 4)];
    NSString*mm = [date substringWithRange:NSMakeRange(5, 2)];
    NSString*dd = [date substringWithRange:NSMakeRange(8, 2)];
//    NSString*ret = [NSString stringWithFormat:@"%@.%@.%@",dd,mm,yy];
    NSString*ret = [NSString stringWithFormat:@"%@-%@-%@",dd,mm,yy];
    return ret;
}
+(NSMutableArray*)getGroupIds:(NSMutableArray*)listData{
    EnvVar* env = [CGlobal sharedId].env;
    NSMutableDictionary* dict = [[NSMutableDictionary alloc] init];
    for (int i=0; i< [listData count]; i++) {
        TblChallenge* data = listData[i];
        for (int j=0; j< [data.invitees count]; j++) {
            TblInvitee* invitee = data.invitees[j];
            [dict setObject:invitee.custid forKey:invitee.custid];
        }
        if (![data.custId isEqualToString:env.custId]) {
            [dict setObject:data.custId forKey:data.custId];
        }
    }
    NSMutableArray* array = [[NSMutableArray alloc] init];
    for (NSString*key in dict) {
        [array addObject:key];
    }
    
    return array;
}
+(NSString*)getDayofWeekFromNSString:(NSString*)paramdate isGmt:(BOOL)isGmt{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    if (isGmt) {
        NSTimeZone *gmt = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
        [dateFormat setTimeZone:gmt];
    }else{
        NSTimeZone *gmt = [NSTimeZone localTimeZone];
        [dateFormat setTimeZone:gmt];
    }
    NSDate *sourceDate = [dateFormat dateFromString:paramdate];
    
    
    NSCalendar* gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents*comps = [gregorian components:NSCalendarUnitWeekday|NSCalendarUnitHour|NSCalendarUnitMinute fromDate:sourceDate];
    int weekday = (int)[comps weekday];
    NSArray* array = [NSArray arrayWithObjects:@"Sunday",@"Monday",@"Tuesday",@"Wednesday",@"Thursday",@"Friday",@"Saturday", nil];
    
    
    NSString*param1 = array[weekday-1];
    NSString* dayofweek = [[NSBundle mainBundle] localizedStringForKey:param1 value:@"" table:nil];
    NSString* ret = [NSString stringWithFormat:@"%@ %02d:%02d",dayofweek,(int)comps.hour,(int)comps.minute];
    
    return ret;
}
+(NSString*)getDayofWeekFromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt{
    NSCalendar* gregorian = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents*comps = [gregorian components:NSCalendarUnitWeekday fromDate:sourceDate];
    int weekday = (int)[comps weekday];
    NSArray* array = [NSArray arrayWithObjects:@"Sunday",@"Monday",@"Tuesday",@"Wednesday",@"Thursday",@"Friday",@"Saturday", nil];
    
    
    NSString*param1 = array[weekday-1];
    NSString* dayofweek = [[NSBundle mainBundle] localizedStringForKey:param1 value:@"" table:nil];
    
    return dayofweek;
}
+(NSURL*)urlForPath:(NSString*)param{
    NSURL* url = [NSURL URLWithString:param];
    return url;
}
+(NSString*)getThumbPhotoPath:(NSString*)filename{
    
    NSString* uploadpath = [NSString stringWithFormat:@"%@/assets/uploads/thumbnail/%@",g_baseUrl,filename];
    return  uploadpath;
}
+(NSString*)getPhotoPath:(NSString*)filename{
    
    NSString* uploadpath = [NSString stringWithFormat:@"%@/assets/uploads/%@",g_baseUrl,filename];
    return  uploadpath;
}
+(NSString*)getBasePhotoPath:(NSString*)filename{
    
    NSString* uploadpath = [NSString stringWithFormat:@"%@/assets/base/%@",g_baseUrl,filename];
    return  uploadpath;
}
+(UIImage*)getImageForMap:(UIImage*)bm NSString:(NSString*)number{
    int spellsize = 12;
    UIFont*font = [UIFont fontWithName:@"Helvetica" size:spellsize];
    CGSize textSize = [number sizeWithAttributes:@{NSFontAttributeName:font}];
    CGFloat bw = textSize.width;
    CGFloat bh = textSize.height;
    float radius = 10;
    if (bw<bh) {
        radius = bh/2;
    }else{
        radius = bw/2;
    }
    radius+=5;
    
    int sm,cw,tw,th;
    sm = 1;
    cw = radius;
    tw = 60;
    th = 60;
    int dw = tw - 2*sm - cw;
    int dh = tw - 2*sm-cw;
    int thumb_width = bm.size.width;
    int thumb_height = bm.size.height;
    int realwidth,realheight;
    if (thumb_width>thumb_height){
        realwidth = dw;
        realheight = (int) (((float)realwidth/(float)thumb_width)*thumb_height);
    }else{
        realheight = dh;
        realwidth =  (int) (((float)realheight/(float)thumb_height)*thumb_width);
    }
    
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(tw,th), NO, 2.0);
    CGContextRef context = UIGraphicsGetCurrentContext();
    // drawing with a white stroke color
    CGContextSetRGBStrokeColor(context, 1.0, 1.0, 1.0, 1.0);
    // drawing with a white fill color
    CGContextSetRGBFillColor(context, 1.0, 1.0, 1.0, 1.0);
    CGContextFillRect(context, CGRectMake(0, cw, sm*2+dw, th));
    
    int cx = (dw-realwidth)/2+sm,cy = (dh-realheight)/2+sm+cw;
    CGRect dst = CGRectMake(cx,cy,realwidth,realheight);
    [bm drawInRect:dst];
    
    if ([number intValue] > 1) {
        CGRect circle_rect = CGRectMake(tw-cw*2, 0, 2*cw, 2*cw);
        CGContextSetRGBFillColor(context, 0.29, 0.60, 0.85,1.0);
        CGContextFillEllipseInRect(context, circle_rect);
        
        CGContextSetRGBStrokeColor(context, 1.0, 1.0, 1.0, 1.0);
        NSDictionary* dict =  [NSDictionary dictionaryWithObjectsAndKeys:
         font, NSFontAttributeName,
         [NSNumber numberWithFloat:1.0], NSBaselineOffsetAttributeName, nil];
        
        CGRect text_rect = CGRectMake((circle_rect.size.width-bw)/2+circle_rect.origin.x,(circle_rect.size.height-bh)/2+circle_rect.origin.y,bw,bh);
        [number drawInRect:text_rect withAttributes:dict];
    }
    UIImage *resultImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return resultImage;
}
+(UIImage*)drawFront:(UIImage*)image text:(NSString*)text atPoint:(CGPoint)point
{
    UIFont *font = [UIFont fontWithName:@"Halter" size:21];
    UIGraphicsBeginImageContext(image.size);
    [image drawInRect:CGRectMake(0,0,image.size.width,image.size.height)];
    CGRect rect = CGRectMake(point.x, (point.y - 5), image.size.width, image.size.height);
    [[UIColor whiteColor] set];
    
    NSMutableAttributedString* attString = [[NSMutableAttributedString alloc] initWithString:text];
    NSRange range = NSMakeRange(0, [attString length]);
    
    [attString addAttribute:NSFontAttributeName value:font range:range];
    [attString addAttribute:NSForegroundColorAttributeName value:[UIColor whiteColor] range:range];
    
    NSShadow* shadow = [[NSShadow alloc] init];
    shadow.shadowColor = [UIColor darkGrayColor];
    shadow.shadowOffset = CGSizeMake(1.0f, 1.5f);
    [attString addAttribute:NSShadowAttributeName value:shadow range:range];
    
    [attString drawInRect:CGRectIntegral(rect)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return newImage;
}
+(NSString*) getFirstDayStringFromString:(NSString *)param1 isGmt:(BOOL)isGmt{
    //m this output  monday time 00 00 01
    // if today is monday return current monday
    //    2016-09-10 15:05:04   --------    2016-09-05 00:00:01
    NSDate* today = [CGlobal getDateFromDbString:param1 isGmt:isGmt];
    
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 3))];// for beginning of the week.
    
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    if (dayofweek == 1) {
        beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24*7];
    }
    beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24+1];
    
    NSString* ret = [CGlobal getTimeStringFromDate:beginningOfWeek isGmt:isGmt];
    return ret;
    
}
+(NSDate*) getFirstDay1:(NSDate *)today isGmt:(BOOL)isGmt{
    // this output  monday time 00 00 01
    // if today is monday return last monday
    
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 3))];// for beginning of the week.
    
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    if (dayofweek == 2 || dayofweek == 1) {
        beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24*7];
    }
    beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24+1];
    return beginningOfWeek;
    
}
+(NSDate*) getMondayOfThisDate:(NSDate *)today isGmt:(BOOL)isGmt{
    //m this output  monday time 23 59 59
    // if today is monday return last monday
    // 2016-09-12 10:38:06 +0000 -------------  2016-09-05 21:59:59 +0000
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 3))];// for beginning of the week.
    
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    if (dayofweek == 1) {
        beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24*7];
    }
    beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-1];
    return beginningOfWeek;
}
+(NSDate*) getFirstDay:(NSDate *)today isGmt:(BOOL)isGmt{
    //m this output  monday time 23 59 59
    // if today is monday return last monday
    // 2016-09-12 10:38:06 +0000 -------------  2016-09-05 21:59:59 +0000
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    
    int dayofweek = [[[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:today] weekday];// this will give you current day of week
    
    [components setDay:([components day] - ((dayofweek) - 3))];// for beginning of the week.
    
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    if (dayofweek == 2 || dayofweek == 1) {
        beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-60*60*24*7];
    }
    beginningOfWeek = [beginningOfWeek dateByAddingTimeInterval:-1];
    return beginningOfWeek;
}
+(NSDate*) getLastTimeOfDay:(NSDate *)today isGmt:(BOOL)isGmt{
    //m this output  toay's last time.  i.e  2016-07-04 23:59:59 utc
    // 2016-09-12 21:59:59 +0000  ------     2016-09-12 21:59:59 +0000
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    [components setHour:23];
    [components setMinute:59];
    [components setSecond:59];
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    return beginningOfWeek;
    
}
+(NSDate*) getFirstTimeOfDay:(NSDate *)today isGmt:(BOOL)isGmt{
    //m this output  toay's first time.  i.e  2016-07-04 00:00:01 utc
    //  2016-09-11 21:59:59 +0000      -----------     2016-09-10 22:00:01 +0000
    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
    if (isGmt) {
        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    }else{
        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
    }
    
    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
    [components setHour:00];
    [components setMinute:00];
    [components setSecond:01];
    
    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
    return beginningOfWeek;
    
}
+(BOOL) isToday:(NSDate *)param isGmt:(BOOL)isGmt{
    NSDate* today = [NSDate date];
    NSInteger seconds = [today timeIntervalSinceDate:param];
    if (seconds>=0 && seconds<24 * 60*60 ) {
        return true;
    }else{
        return false;
    }
}
+(NSString*)encodeForUml:(NSString*)input{
    NSArray* array1 = [[NSArray alloc] initWithObjects:@"ä",@"ö",@"ü",@"Ü",@"Ä",@"Ö",@" ",@"£",@"&",@"é",@"è", nil];
    NSArray* array2 = [[NSArray alloc] initWithObjects:@"%C3%A4",@"%C3%B6",@"%C3%BC",@"%C3%9C",@"%C3%84",@"%C3%96",@"%20",@"%C2%A3",@"%26", @"%C3%A9",@"%C3%A8",nil];
    
    for (int i=0; i< [array1 count]; i++) {
        NSString* p1 = array1[i];
        NSString* p2 = array2[i];
        input = [input stringByReplacingOccurrencesOfString:p1 withString:p2];
    }
    return input;
}
//+(NSDate*) getLastTimeOfDay:(NSDate *)today isGmt:(BOOL)isGmt{
//    //m this output  toay's last time.  i.e  2016-07-04 23:59:59 utc
//    // 2016-09-12 21:59:59 +0000  ------     2016-09-12 21:59:59 +0000
//    NSCalendar *gregorian = [[NSCalendar alloc]        initWithCalendarIdentifier:NSGregorianCalendar];
//    if (isGmt) {
//        [gregorian setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
//    }else{
//        [gregorian setTimeZone:[NSTimeZone localTimeZone]];
//    }
//    
//    
//    NSDateComponents *components = [gregorian components:NSWeekdayCalendarUnit | NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit fromDate:today];
//    [components setHour:23];
//    [components setMinute:59];
//    [components setSecond:59];
//    
//    NSDate *beginningOfWeek = [gregorian dateFromComponents:components];
//    return beginningOfWeek;
//    
//}

+(void)setStyleForView:(UIView*)view Color:(UIColor*)color Mode:(int)mode Radius:(CGFloat)paramRadius{
    switch (mode) {
        case 1:
        {
            CGRect rect = view.frame;
            CGFloat radius = rect.size.width/2;
            view.layer.backgroundColor = [color CGColor];
            view.layer.cornerRadius = paramRadius;
            view.layer.borderWidth = 1;
            view.layer.borderColor = [[UIColor whiteColor] CGColor];
            view.layer.masksToBounds = true;
            break;
        }
        case 2:
        {
            CGRect rect = view.frame;
            CGFloat radius = rect.size.height/2;
            view.layer.backgroundColor = [color CGColor];
            view.layer.cornerRadius = paramRadius;
            view.layer.borderWidth = 1;
            view.layer.borderColor = [[UIColor blackColor] CGColor];
            view.layer.masksToBounds = true;
            break;
        }
        default:
            break;
    }
}
+(void)setStyleForText:(UITextField*)view Color:(UIColor*)color Mode:(int)mode Radius:(CGFloat)paramRadius{
    switch (mode) {
        case 1:
        {
            CGRect rect = view.frame;
            
            view.layer.backgroundColor = [[UIColor clearColor] CGColor];
            view.layer.cornerRadius = paramRadius;
            view.layer.borderWidth = 1;
            view.layer.borderColor = [[CGlobal colorWithHexString:@"7F7F82" Alpha:1.0f] CGColor];
            view.layer.masksToBounds = true;
            view.backgroundColor = [UIColor clearColor];
            break;
        }
        default:
            break;
    }
}
+(UIImage*)getColoredImage:(NSString*)imgName Color:(UIColor*)color{
    UIImage *image = [UIImage imageNamed:imgName];
    
    if (color == nil) {
        return image;
    }
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context, rect, image.CGImage);
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    
    UIImage *flippedImage = [UIImage imageWithCGImage:img.CGImage
                                                scale:1.0 orientation: UIImageOrientationDownMirrored];
    
    return flippedImage;
}
+(UIImage*)getColoredImageFromImage:(UIImage*)image Color:(UIColor*)color{
    
    CGRect rect = CGRectMake(0, 0, image.size.width, image.size.height);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextClipToMask(context, rect, image.CGImage);
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    
    
    UIImage *flippedImage = [UIImage imageWithCGImage:img.CGImage
                                                scale:1.0 orientation: UIImageOrientationDownMirrored];
    
    return flippedImage;
}
+(void)setCheckMark{
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    EnvVar* env = [CGlobal sharedId].env;
    env.historyVersion = version;
}
+(BOOL)checkIphoneSe{
    CGSize size = [UIScreen mainScreen].bounds.size;
    if (size.width <= 320) {
        return true;
    }
    return false;
}

+(void)grantedPermissionCamera:(PermissionCallback)callback{
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    if(authStatus == AVAuthorizationStatusAuthorized) {
        callback(true);
        return;
        // do your logic
    }else if(authStatus ==AVAuthorizationStatusNotDetermined){
        [AVCaptureDevice requestAccessForMediaType:mediaType completionHandler:^(BOOL granted) {
            callback(granted);
        }];
        return;
    }
    else{
        callback(false);
        return;
    }
}
+(void)grantedPermissionPhotoLibrary:(PermissionCallback)callback{
    if([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusAuthorized){
        callback(true);
        return;
    }else if([PHPhotoLibrary authorizationStatus] == PHAuthorizationStatusNotDetermined){
        [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
            callback(status);
            return;
        }];
        return;
    }else{
        callback(false);
        return;
    }
}
+(void)AlertMessageMessage:(NSString*)message Title:(NSString*)title{
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:title
                          message:message
                          delegate:nil
                          cancelButtonTitle:@"Ok"
                          otherButtonTitles:nil];
    [alert show];
}
+(NSString*)getUploadDirectory{
    NSString* path1 = [g_baseUrl stringByDeletingLastPathComponent];
    path1 = [path1 stringByDeletingLastPathComponent];

    path1 = [path1 stringByAppendingPathComponent:@"assets"];
    path1 = [path1 stringByAppendingPathComponent:@"uploads"];
    
    return path1;
    
}
+(NSString*)getFileFullPath:(NSString*)filename{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString*sourcePath = [paths objectAtIndex:0];
    NSString* zipfile = [sourcePath stringByAppendingPathComponent:@"log"];
    BOOL isDir = false;
    NSError* err;
    if([[NSFileManager defaultManager] fileExistsAtPath:zipfile isDirectory:&isDir]== false){
        [[NSFileManager defaultManager] createDirectoryAtPath:zipfile withIntermediateDirectories:YES attributes:nil error:&err];
    };
    zipfile = [zipfile stringByAppendingPathComponent:filename];
    return zipfile;
}
+(UIImage*)localUserImage:(NSString*)custId{
    NSString* filename = [NSString stringWithFormat:@"user%d.jpg",[custId intValue] ];
    NSString* path = [CGlobal getFileFullPath:filename];
    
    UIImage* image = [UIImage imageWithContentsOfFile:path];
    return image;
}
+(void)getUserImage:(NSString*)custId Callback:(UserImageCallback)callback{
    AppDelegate* delegate = [UIApplication sharedApplication].delegate;
    NetworkStatus internetStatus = [delegate.reachability currentReachabilityStatus];
    if (internetStatus == NotReachable) {
        //return;
        callback([self localUserImage:custId]);
    }else{
        NSString* filename = [NSString stringWithFormat:@"user%d.jpg",[custId intValue] ];
        NSString* path = [[CGlobal getUploadDirectory] stringByAppendingPathComponent:filename];
        
        [[SDWebImageDownloader sharedDownloader] downloadImageWithURL:[NSURL URLWithString:path] options:SDWebImageDownloaderUseNSURLCache progress:nil completed:^(UIImage *image, NSData *data, NSError *error, BOOL finished) {
            if (image!=nil) {
                [self saveImage:image FileName:filename];
                callback(image);
            }
            
        }];
        
//        [_user_image sd_setImageWithURL:[NSURL URLWithString:path]
//                       placeholderImage:[UIImage imageNamed:@"user_avatar.png"]
//                              completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
//                                  _user_image.image = image;
//                              }];
    }
}
+(void)saveImage: (UIImage*)image FileName:(NSString*)filename
{
    if (image != nil)
    {
        NSString* path = [CGlobal getFileFullPath:filename];
        //NSData* data = UIImagePNGRepresentation(image);
        NSData* data = UIImageJPEGRepresentation(image, 1.0);
        [data writeToFile:path atomically:YES];
    }
}
@end




