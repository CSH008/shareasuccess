//
//  CGlobal.h
//  SchoolApp
//
//  Created by apple on 9/24/15.
//  Copyright (c) 2015 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "TTTAttributedLabel.h"
#import "EnvVar.h"

extern int gms_camera_zoom;
extern BOOL useGmt;
extern BOOL useEncode;
extern BOOL g_fakeDevice;
extern int g_indicator_mode;
extern CGFloat topPadding_help;
extern NSDictionary*g_launchoptions;
extern  NSString * g_baseUrl;
extern  NSString * g_primaryUrl;
extern NSString* G_DEVICETOKEN;

extern  NSString*   APISERVICE_IP_URL;
extern  NSString*   APISERVICE_MAP_URL;
extern  NSDate*   curDate;
extern  int   appDidBecomeActive_Status;

extern  NSString*   ACTION_LOGIN;
extern  NSString*   ACTION_IOSPUSH;
extern  NSString*   ACTION_FRESH;
extern  NSString*   ACTION_TOGO;
extern  NSString*   ACTION_CONQUERED;
extern  NSString*   ACTION_TOGO_COUNTRY;
extern  NSString*   ACTION_CONQUERED_COUNTRY;
extern  NSString*   ACTION_UPLOAD;
extern  NSString*   ACTION_LIKEPIC;
extern  NSString*   ACTION_REPORT;
extern  NSString*   ACTION_ACTIVEBIDS ;
extern  NSString*   ACTION_MAKEPOST ;
extern  NSString*   ACTION_COMMENT ;
extern  NSString*   ACTION_USERINFO ;
extern  NSString*   ACTION_UPDATEPROFILE ;
extern  NSString*   ACTION_DEFAULTPROFILE ;
//basic data
extern NSString* sync_collect_start;
extern NSString* sync_collect_done;
extern NSString* sync_push_start;
extern NSString* sync_push_done;
extern NSString* sync_save_start;
extern NSString* sync_save_done;

extern NSArray* g_listColor;
extern NSArray* g_listColor_BK;
extern UIFont* defaultFont;
extern UIFont* defaultFont_Headline;
extern UIFont* defaultFont_Headline_Bold;
extern UIFont* defaultFont_Italic;
extern UIColor* defaultColor;
extern UIColor* defaultColor1;
extern UIColor* defaultColor_blue;
extern UIFont* abcAlena_bold;
extern UIFont* abcAlena_lightitalic;
extern UIFont* abcAlena_semibold;
extern UIFont* abcAlena_light;
extern UIFont* abcAlena_medium;
extern UIFont* abcAlena_regular;
extern UIFont* abcAlena_regularitalic;

//notifications
extern NSString *GLOBALNOTIFICATION_DATA_CHANGED_PHOTO ;
extern NSString *GLOBALNOTIFICATION_MAP_PICKLOCATION ;
extern NSString *GLOBALNOTIFICATION_RECEIVE_USERINFO_SUCC;
extern NSString *GLOBALNOTIFICATION_RECEIVE_USERINFO_FAIL;
extern NSString *GLOBALNOTIFICATION_CHANGEVIEWCONTROLLER;
extern NSString *GLOBALNOTIFICATION_CHANGEVIEWCONTROLLERREBATE;
extern NSString *GLOBALNOTIFICATION_MQTTPAYLOAD;
extern NSString *GLOBALNOTIFICATION_MQTTPAYLOAD_PROCESS;
extern NSString *GLOBALNOTIFICATION_TRENDINGRESET;
extern NSString *GLOBALNOTIFICATION_LIKEDBUTTON;

extern NSString *NOTIFICATION_RECEIVEUUID;
extern NSString *NOTIFICATION_TOOLBAR_CHANGE;
extern NSString *NOTIFICATION_TOOLBAR_BADGE;
extern NSString *NOTIFICATION_MAIN_COMMON_NOTI;
extern NSString *GLOBALNOTIFICATION_SYNC_CHANGESTATUS;
extern NSString *GLOBALNOTIFICATION_CHALLENGELIST_CHANGED;
extern NSString *NOTIFICATION_RECEIVEMSG;
extern NSString *GLOBALNOTIFICATION_NOTICE;

//menu height
extern CGFloat GLOBAL_MENUWIDTH;

enum {GLOBAL_BACK_INITIAL           = 0};
enum {GLOBAL_BACK_DOING           = 1};

enum {GLOBAL_SYNC_FIRSTTIME         = 0};
enum {GLOBAL_SYNC_INITIAL           = 1};
enum {GLOBAL_SYNC_COLLECTING        = 2};
enum {GLOBAL_SYNC_COLLECTING_DONE   = 3};
enum {GLOBAL_SYNC_PUSHING           = 4};
enum {GLOBAL_SYNC_PUSHING_DONE      = 5};
enum {GLOBAL_SYNC_GETTING_MYINFO      = 6};
enum {GLOBAL_SYNC_IMPORTING      = 10};

enum {GLOBAL_COLOR_RED         = 0};
enum {GLOBAL_COLOR_GREEN         = 1};
enum {GLOBAL_COLOR_BLUE         = 2};
enum {GLOBAL_COLOR_YELLOW         = 3};
enum {GLOBAL_COLOR_NOCOLOR         = 4};

extern UIColor* APP_COLOR_PRIMARY;
extern UIColor* APP_COLOR_PRIMARY_SECONDARY;
extern UIColor* APP_COLOR_BUTTON_PRIMARY;
extern UIColor* APP_COLOR_CELL_GRAY;
extern UIColor* APP_COLOR_DOT_RED;
extern UIColor* APP_COLOR_DOT_RED_OLD;
extern UIColor* APP_COLOR_DOT_GREEN;

extern UIColor* APP_COLOR_RED;
extern UIColor* APP_COLOR_GREEN;
extern UIColor* APP_COLOR_BLUE;
extern UIColor* APP_COLOR_YELLOW;
extern UIColor* APP_COLOR_NOCOLOR;

extern UIColor* APP_COLOR_DETAIL1;
extern UIColor* APP_COLOR_DETAIL2;
extern UIColor* APP_COLOR_DETAIL3;
extern UIColor* APP_COLOR_DETAIL_BACKGREEN;
extern UIColor* APP_COLOR_DETAIL_BACKRED;
extern UIColor* APP_COLOR_DETAIL_BACKYELLOW;

extern UIColor* APP_COLOR_COLOREDVIEW;

typedef void (^PermissionCallback)(BOOL ret);
typedef void (^UserImageCallback)(UIImage* ret);

@interface CGlobal : NSObject
+ (CGlobal *)sharedId;
@property (nonatomic, strong) EnvVar * env;
@property (nonatomic, copy) NSString* uuid;
@property (nonatomic, strong) void (^fetchCallBack)(UIBackgroundFetchResult);
// common variables
extern NSMutableArray *g_buttonTitles;
extern UIFont * g_largefont;
extern CGFloat g_menuHeight;
extern NSMutableArray* menu_bottomList;
extern NSMutableArray* menu_topList;
extern CGFloat status_leading;
extern CGFloat status_trailing;
extern CGFloat default_textfield_radius;
extern CGFloat statusbar_gap1;
extern CGFloat top_space;
extern CGFloat bottom_space;
extern CGFloat top_space_toolbar_title;

// COMMON FUMCTIONS
+(void)makeTermsPrivacyForLabel: (TTTAttributedLabel *) label withUrl:(NSString*)urlString;
+(void)initSample;
+(int)getOrientationMode;
+(void)showIndicatorInWindow;
+(void)stopIndicatorInWindow;
+(void)showIndicator:(UIViewController*)viewcon Tag:(NSString*)tag;
+(void)stopIndicator:(UIViewController*)viewcon Tag:(NSString*)tag;
+(void)showIndicatorForView:(UIView*)viewcon;
+(void)stopIndicatorForView:(UIView*)viewcon;
+(void)AlertMessage:(NSString*)message Title:(NSString*)title;
+(void)makeBorderBlackAndBackWhite:(UIView*)target;
+(void)makeBorderASUITextField:(UIView*)target;
+(CGFloat)heightForView:(NSString*)text Font:(UIFont*) font Width:(CGFloat) width;
+(CGSize)sizeForView:(NSString*)text Font:(UIFont*) font Width:(CGFloat) width;
+(NSString*)generateFilePath;
+(NSString*)getUDID;
+(void)setDefaultBackground:(UIViewController*)viewcon;
+(NSString*) jsonStringFromDict:(BOOL) prettyPrint Dict:(NSDictionary*)dict;
+(NSString*)getEncodedString:(NSString*)input;
//+(BOOL)gotoViewController:(UIViewController*)controller Mode:(int) mode;
+ (NSString *) escapeString:(NSString *)string;

+(NSString*)getDateFromPickerForDb:(UIDatePicker*)datePicker;
+(NSDate*)getDateFromDbString:(NSString*)string isGmt:(BOOL)isGmt;
+(NSDate*)getLocalDateFromDbString:(NSString*)string isGmt:(BOOL)isGmt;
+(NSString*)getDateStringAfterNDays:(NSString*)string isGmt:(BOOL)isGmt AfterTime:(long)time;
+(NSString*)getLocalDateFromDBString:(NSString*)string isGmt:(BOOL)isGmt;
+(NSString*)getGmtHour;
+(NSString*)getCurrentTimeInGmt0;
+(NSString*)getTimeStringFromDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt;
+(NSString*)getTimePartStringFromDate:(NSDate*)sourceDate  isGmt:(BOOL)isGmt;
+(NSArray*)getIntegerArrayFromRids:(NSString*)rids;
+(NSString*)getFormattedTimeFormPicker:(UIDatePicker*)picker;
+(int)ageFromBirthday:(NSDate *)birthdate;
+(NSString*)getTimeLeft:(NSString*)str_enddate;
+(NSNumber*)getNumberFromStringForCurrency:(NSString*)formatted_str;
+(NSString*)getStringFromNumberForCurrency:(NSNumber*)number;
+ (UIColor *)colorWithHexString:(NSString *)stringToConvert Alpha:(CGFloat)alpha;
+(void)shareText:(NSString *)text andImage:(UIImage *)image andUrl:(NSURL *)url withView:(UIView*)view withController:(UIViewController*)controller;
+ (NSString *)urlencode:(NSString*)param1;
+ (UIImage*)imageWithImage:(UIImage*)image
              scaledToSize:(CGSize)newSize;
+ (UIImage*)getScaledImage:(UIImage*)image;
+(NSMutableArray*)getEmailAddressFromAdressBook;

// program specific
+ (void)makeStyle1:(UIView*)controller Mode:(int)mode;
+(NSArray*)findAllTextFieldsInView:(UIView*)view;
+(NSString*)getDayPart:(NSString*)date;                     //      dd/mm/yy
+(NSString*)getDayPart1:(NSString*)date;                    //      yyyy-mm-dd
+(NSString*)getDayPartFromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt;       //      dd/mm/yy
+(NSString*)getDayPart1FromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt;      //  output  yyyy-mm-dd
+(NSString*)getDayPart2FromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt;      //  output  yyyy-mm-dd
+(NSMutableArray*)getGroupIds:(NSMutableArray*)listData;
+(NSString*)getDayofWeekFromNSString:(NSString*)paramdate isGmt:(BOOL)isGmt;
+(NSString*)getDayofWeekFromNSDate:(NSDate*)sourceDate isGmt:(BOOL)isGmt;      //  output


//PARSING JSON

+(NSString*)getThumbPhotoPath:(NSString*)filename;
+(NSString*)getPhotoPath:(NSString*)filename;
+(NSString*)getBasePhotoPath:(NSString*)filename;
+(UIImage*)getImageForMap:(UIImage*)bm NSString:(NSString*)number;
+(NSString*) getFirstDayStringFromString:(NSString *)param1 isGmt:(BOOL)isGmt;
+(NSDate*) getFirstDay1:(NSDate *)today isGmt:(BOOL)isGmt;
+(NSDate*) getMondayOfThisDate:(NSDate *)today isGmt:(BOOL)isGmt;
+(NSDate*) getFirstDay:(NSDate *)today isGmt:(BOOL)isGmt;
+(NSDate*) getLastTimeOfDay:(NSDate *)today isGmt:(BOOL)isGmt;
+(NSDate*) getFirstTimeOfDay:(NSDate *)today isGmt:(BOOL)isGmt;
//+(NSString*)encodeForUml:(NSString*)input;
+(BOOL) isToday:(NSDate *)param isGmt:(BOOL)isGmt;

+(void)setStyleForView:(UIView*)view Color:(UIColor*)color Mode:(int)mode  Radius:(CGFloat)paramRadius;
+(void)setStyleForText:(UITextField*)view Color:(UIColor*)color Mode:(int)mode Radius:(CGFloat)paramRadius;
+(UIImage*)getColoredImage:(NSString*)imgName Color:(UIColor*)color;
+(UIImage*)getColoredImageFromImage:(UIImage*)image Color:(UIColor*)color;
+(void)setCheckMark;
+(BOOL)checkIphoneSe;

+(void)grantedPermissionCamera:(PermissionCallback)callback;
+(void)grantedPermissionPhotoLibrary:(PermissionCallback)callback;

+(void)AlertMessageMessage:(NSString*)message Title:(NSString*)title;
+(NSString*)getUploadDirectory;

+(UIImage*)localUserImage:(NSString*)custId;
+(void)getUserImage:(NSString*)custId Callback:(UserImageCallback)callback;
+(void)saveImage: (UIImage*)image FileName:(NSString*)filename;
@end
