
#import <Foundation/Foundation.h>

@interface EnvVar : NSObject
@property (nonatomic, copy) NSString * username;
@property (nonatomic, copy) NSString * password;
@property (nonatomic, assign) long lastLogin;

@property (nonatomic, copy) NSString * token;
@property (nonatomic, copy) NSString * fbtoken;
@property (nonatomic, copy) NSString * email;
@property (nonatomic, copy) NSString * fbid;
@property (nonatomic, copy) NSString * pushtoken;

@property (nonatomic, copy) NSString * fname;
@property (nonatomic, copy) NSString * lname;
@property (nonatomic, copy) NSString * user_status;
@property (nonatomic, copy) NSString * weight;
@property (nonatomic, copy) NSString * screen;
@property (nonatomic, copy) NSString * public_share;
@property (nonatomic, copy) NSString * language;
@property (nonatomic, copy) NSString * user_timezone;

@property (nonatomic, copy) NSString * custId;
@property (nonatomic, copy) NSString * lastMySyncDay;
@property (nonatomic, copy) NSString * myUsers;
@property (nonatomic, copy) NSString * lastwinnerdate;
@property (nonatomic, copy) NSString * historyVersion;
@property (nonatomic, assign) long my_invitee_pending;          //      type 1
@property (nonatomic, assign) long friends_invitee_pending;     //      type 0
@property (nonatomic, assign) long total_invitee_pending;
//@property (nonatomic, assign) NSString* chat_lasttime;

@property (nonatomic, assign) NSString* push_enabled;
@property (nonatomic, assign) NSString* profile_image;

@property (nonatomic, assign) long lastSyncStatus;
@property (nonatomic, assign) long lastChallengeCount;
@property (nonatomic, assign) long backGroundStatus;

- (BOOL)hasLoginDetails;
- (void)logOut;
- (void) loadFromDefaults;
- (id) initTemp;
- (void)saveDefaults:(NSString *)key value:(id)obj;

//customFunctions
-(void)saveToken;

@property (nonatomic, assign) long tip_step;
@end
