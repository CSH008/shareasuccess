//
//  ChatLeft.swift
//  ShareASuccess
//
//  Created by BoHuang on 7/30/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

import UIKit

class ChatLeft: ChatCellBaseView {

    
    @objc override func setData(row:TblChat, delegate:ViewDialogDelegate,type:Int){
        super.setData(row: row, delegate: delegate,type:type)
//        changeImage("chat_bubble_received")
        //img_bubble.tintColor = CGlobal.color(withHexString: "#F2F6F9", alpha: 1.0)
    }
    @IBAction override func tapEntire(_ sender: Any) {
        super.tapEntire(sender)
    }
    @IBAction override func tapDelete(_ sender: Any) {
        super.tapDelete(sender)
    }

}
