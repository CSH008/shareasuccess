//
//  ChallengeOverTableViewCell.h
//  ShareASuccess
//
//  Created by Twinklestar on 3/28/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TblInvitee.h"
#import "TblHealthData.h"
#import "TblWinnerInfo.h"
#import "TblChallenge.h"
@class ColoredView;

@interface ChallengeOverTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIView *viewHeadLine;
@property (weak, nonatomic) IBOutlet UILabel *lblHeadline;

@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol1;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol2;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol3;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol4;
@property (weak, nonatomic) IBOutlet UIImageView *imageSymbol5;

@property (weak, nonatomic) IBOutlet UIView *viewSymbol1;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol2;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol3;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol4;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol5;
@property (weak, nonatomic) IBOutlet UIView *viewSymbol;

@property (weak, nonatomic) IBOutlet UIView *viewMe1;
@property (weak, nonatomic) IBOutlet UIView *viewMe2;
@property (weak, nonatomic) IBOutlet UIView *viewMe3;
@property (weak, nonatomic) IBOutlet UIView *viewMe4;
@property (weak, nonatomic) IBOutlet UIView *viewMe5;
@property (weak, nonatomic) IBOutlet UIView *viewMe;

@property (weak, nonatomic) IBOutlet UIView *viewGroup;
@property (weak, nonatomic) IBOutlet UIView *viewGroup1;
@property (weak, nonatomic) IBOutlet UIView *viewGroup2;
@property (weak, nonatomic) IBOutlet UIView *viewGroup3;
@property (weak, nonatomic) IBOutlet UIView *viewGroup4;
@property (weak, nonatomic) IBOutlet UIView *viewGroup5;


@property (weak, nonatomic) IBOutlet UIImageView *imageMy1;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy2;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy3;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy4;
@property (weak, nonatomic) IBOutlet UIImageView *imageMy5;

@property (weak, nonatomic) IBOutlet UIImageView *imageGroup1;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup2;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup3;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup4;
@property (weak, nonatomic) IBOutlet UIImageView *imageGroup5;
@property (weak, nonatomic) IBOutlet UILabel *labelGroup;
@property (weak, nonatomic) IBOutlet UILabel *labelMe;
@property (weak, nonatomic) IBOutlet UILabel *labelChallengeName;

@property (assign, nonatomic) CGFloat fontsize;

@property (weak, nonatomic) IBOutlet UIImageView* pinImage;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

//@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;

-(void)setDataForTblChallenge:(TblChallenge*)data;
@property (weak, nonatomic) IBOutlet UIView *view_bubble;
@property (weak, nonatomic) IBOutlet UIImageView *bubble_img;
@property (weak, nonatomic) IBOutlet UILabel *bubble_lbl;

@property (weak, nonatomic) IBOutlet UIImageView *img_ppl;
@property (weak, nonatomic) IBOutlet UIImageView *img_person;
@property (weak, nonatomic) IBOutlet ColoredView *cell_seperator1;
@property (weak, nonatomic) IBOutlet ColoredView *cell_seperator2;
@property (weak, nonatomic) IBOutlet ColoredView *cell_seperator3;

@end
