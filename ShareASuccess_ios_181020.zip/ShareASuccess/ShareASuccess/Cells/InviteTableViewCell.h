//
//  InviteTableViewCell.h
//  UiScreens
//
//  Created by BoHuang on 5/13/16.
//  Copyright © 2016 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblInviteInfoData.h"

@interface InviteTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imageType;
@property (weak, nonatomic) IBOutlet UIImageView *imageStatus;
@property (weak, nonatomic) IBOutlet UILabel *labelTitle;
@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelDesc;

@property (weak, nonatomic) IBOutlet UIButton *btn_reject;
@property (weak, nonatomic) IBOutlet UIButton *btn_accept;

@property (weak, nonatomic) IBOutlet UIView *view_top1;
@property (weak, nonatomic) IBOutlet UIView *view_top2;
@property (weak, nonatomic) IBOutlet UIView *view_root;


@property (weak, nonatomic) UIFont *font1,*font2;
@property (assign, nonatomic) CGFloat labelwidth1;


-(void)setData:(TblInviteInfoData*)data;
@end
