//
//  ChatRight.swift
//  ShareASuccess
//
//  Created by BoHuang on 7/30/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

import UIKit

class ChatRight: ChatCellBaseView {

    @objc override func setData(row:TblChat, delegate:ViewDialogDelegate,type:Int){
        super.setData(row: row, delegate: delegate,type: type)
//        lbl_name.isHidden = true
//        changeImage("chat_bubble_sent")
//        img_bubble.tintColor = CGlobal.color(withHexString: "#DBF4FD", alpha: 1.0)
    }
    
    @IBAction override func tapEntire(_ sender: Any) {
        super.tapEntire(sender)
    }
    @IBAction override func tapDelete(_ sender: Any) {
        super.tapDelete(sender)
    }

}
