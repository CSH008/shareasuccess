//
//  ViewScrollContainer.m
//  Logistika
//
//  Created by BoHuang on 4/27/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import "ViewScrollContainer.h"
#import "ShareASuccess-Swift.h"

@implementation ViewScrollContainer

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/
-(void)firstProcess{
    self.views = [[NSMutableArray alloc] init];
    self.last3views = [[NSMutableArray alloc] init];
    self.bouncesZoom = false;
    self.alwaysBounceVertical = false;
    self.alwaysBounceHorizontal = false;
    self.bounces = false;
    
    self.stackView.spacing = 8;
    
//    self.layer.borderWidth = 1;
//    self.layer.masksToBounds = true;
//    self.layer.borderColor = [UIColor blackColor].CGColor;
}

-(CGFloat)getHeightLast3Views{
    CGFloat height = 0;
    for (int i=0; i<self.last3views.count; i++) {
        ChatCellBaseView* view = self.last3views[i];
        height = height + view.constraint_H.constant + self.stackView.spacing;
    }
    height = height - 8;
//    return fmax(205,height);
    if (height>0) {
        return height;
    }else{
        return 0;
    }
}

- (void)removeAllSubviews {
//    for (int i = self.views.count - 1; i >= 0; i ++) {
//        [self.views[i] removeFromSuperview];
//    }
//    [self.views removeAllObjects];
}

-(void)addOneView:(UIView*)view{
    [self.stackView addArrangedSubview:view];
    [self.views addObject:view];
    
    self.bouncesZoom = false;
    self.alwaysBounceVertical = false;
    self.alwaysBounceHorizontal = false;
    self.bounces = false;
    
    ChatCellBaseView* chat_base = nil;
    if ([view isKindOfClass:[ChatLeft class]]) {
        chat_base = view;
    }else if ([view isKindOfClass:[ChatRight class]]) {
        chat_base = view;
    }
    if (chat_base!=nil) {
        [self.last3views addObject:chat_base];
        if (self.last3views.count>=4) {
            [self.last3views removeObjectAtIndex:0];
        }
    }
}
-(void)scrollToBottom{
    CGPoint bottomOffset = CGPointMake(0, self.contentSize.height - self.bounds.size.height);
    [self setContentOffset:bottomOffset animated:YES];
    NSLog(@"bottomOffset y = %f",bottomOffset.y);
    
}
-(void)setCellSpace:(CGFloat)space{
    
}
@end
