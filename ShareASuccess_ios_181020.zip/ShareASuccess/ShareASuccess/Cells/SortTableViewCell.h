//
//  SortTableViewCell.h
//  Fit
//
//  Created by BoHuang on 5/18/16.
//
//

#import <UIKit/UIKit.h>

@interface SortTableViewCell : UITableViewCell

@property (nonatomic,weak) IBOutlet UILabel* lbl_content;
@property (nonatomic,weak) IBOutlet UIImageView* img_right;

-(void)setData:(NSString*)data;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;

@end
