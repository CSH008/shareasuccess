//
//  ViewScrollContainer.h
//  Logistika
//
//  Created by BoHuang on 4/27/17.
//  Copyright © 2017 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewScrollContainer : UIScrollView
@property (weak, nonatomic) IBOutlet UIStackView *stackView;
@property (strong, nonatomic) NSMutableArray *views;
@property (strong, nonatomic) NSMutableArray *last3views;

-(CGFloat)getHeightLast3Views;

-(void)firstProcess;
- (void)removeAllSubviews;
-(void)addOneView:(UIView*)view;
-(void)scrollToBottom;
@end
