//
//  InviteEmailTableViewCell.h
//  UiScreens
//
//  Created by BoHuang on 5/13/16.
//  Copyright © 2016 BoHuang. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface InviteEmailTableViewCell : UITableViewCell

@property (nonatomic,weak) IBOutlet UITextField*txt_email;
@property (nonatomic,weak) IBOutlet UIImageView * img_left;
@property (nonatomic,weak) IBOutlet UIButton * img_right;

@property (nonatomic,weak) IBOutlet UIView * viewRoot;

-(void)setData:(id)data;
@end
