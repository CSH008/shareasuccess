//
//  MainDetailTableViewCell.m
//  Fit
//
//  Create by Denis on 2/24/16.
//
//

#import "MainDetailTableViewCell.h"
#import "CGlobal.h"
#import <SDWebImage/UIImageView+WebCache.h>


@implementation MainDetailTableViewCell

-(void)awakeFromNib{
    [super awakeFromNib];
    NSMutableArray *myArray = [[NSMutableArray alloc] initWithObjects:_labelDay1,_labelDay2,_labelDay3,_labelDay4,_labelDay5,_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5,nil];
    
    
    CGRect rect = [[UIScreen mainScreen] bounds];
    if (rect.size.width<=320) {
        
        _fontsize = 11.0;
    }else{
        _fontsize = 12.0;
    }
    
    UIFont* font = [UIFont systemFontOfSize:_fontsize];
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
        [label setFont:font];
    }
    
    myArray = [[NSMutableArray alloc] initWithObjects:_labelDay,_labelTotal, nil];
    
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
        [label setFont:font];
    }
    [_labelName setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
    
    
    _constraint_trailing.constant = status_trailing;
    _constraint_leading.constant = status_leading;
    
    [_labelName setFont:defaultFont];
    
    
    _labelDay.textColor = APP_COLOR_CELL_GRAY;
    _labelTotal.textColor = APP_COLOR_CELL_GRAY;
    
}
-(NSString *)commonValue :(NSString *)value
{
    
    if (value)
    {
        if ([value isEqualToString:@"-"])
        {
            return @"-";
        }
        else
        {
            return [NSString stringWithFormat:@"%d",[value intValue]];
        }
    }
    
    return @"";
    
}
-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo{
    EnvVar*env = [CGlobal sharedId].env;
    
    self.data = data;
    self.invitee = invitee;
    self.challenge = challenge;
    self.winnerinfo = winnerinfo;
    
    NSString* thisId = @"";
    if (invitee == nil) {
        _labelName.text = [[NSBundle mainBundle] localizedStringForKey:@"Myself" value:@"" table:nil];
        thisId = [NSString stringWithFormat:@"%d",env.lastLogin];
        
    }else{
        
        if (invitee.fname == nil || [invitee.fname isEqualToString:@""]) {
            _labelName.text = invitee.email_address;
        }else{
            _labelName.text = invitee.fname;
        }
        
        thisId = invitee.custid;
    }
    
    UIImage* image = [CGlobal localUserImage:thisId];
    if (image!=nil) {
        _user_image.image = image;
    }
    else {
        _user_image.image = [UIImage imageNamed:@"user_avatar.png"];
        
        [CGlobal getUserImage:thisId Callback:^(UIImage *ret) {
            if (ret!=nil) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    _user_image.image = ret;
                });
            }
        }];
    }
    
    
    if (winnerinfo!=nil) {
        NSMutableArray* ids = [[NSMutableArray alloc] init];
        [ids addObject:winnerinfo.steps];
        [ids addObject:winnerinfo.walking_running];
        [ids addObject:winnerinfo.cycling_distance];
        [ids addObject:winnerinfo.stand_hours];
        [ids addObject:winnerinfo.flights_climbed];
        [ids addObject:winnerinfo.active_energy];
        [ids addObject:winnerinfo.swim];
//        if ([ids containsObject:data.custId]) {
//            [_labelName setTextColor:[CGlobal colorWithHexString:@"#d8da59" Alpha:1.0f]];
//        }else{
//            [_labelName setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
//        }
    }else{
//        [_labelName setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
    }
    
    UILabel* myimage1 = _labelDay1;
    UILabel* myimage2 = _labelDay2;
    UILabel* myimage3 = _labelDay3;
    UILabel* myimage4 = _labelDay4;
    UILabel* myimage5 = _labelDay5;
    NSMutableArray* totalLabelArray = [[NSMutableArray alloc] initWithArray:@[_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5]];
    
    NSArray *dayLabelArray = @[myimage1,myimage2,myimage3,myimage4,myimage5];
    
    
    for (UILabel* label in totalLabelArray) {
        label.text = @"";
    }
    for (UILabel* label in totalLabelArray) {
        label.text = @"";
    }
    
    for (int i=0; i<[dayLabelArray count]; i++) {
        UILabel* label = [dayLabelArray objectAtIndex:i];
        label.text = @"";
        //[label setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        [label setFont:[UIFont systemFontOfSize:_fontsize]];
    }
    
    NSArray* viewDayArray  = @[_viewDay1,_viewDay2,_viewDay3,_viewDay4,_viewDay5];
    NSArray* viewTotalArray  = @[_viewTotal1,_viewTotal2,_viewTotal3,_viewTotal4,_viewTotal5];
    for (UIView* view in viewDayArray) {
        //view.backgroundColor = [UIColor whiteColor];
        view.hidden = true;
    }
    for (UIView* view in viewTotalArray) {
        //view.backgroundColor  = [UIColor whiteColor];
        view.hidden = true;
    }
    
    _viewDay.backgroundColor = [UIColor clearColor];
    _viewTotal.backgroundColor = [UIColor clearColor];
    
    
    NSArray* dayValues = [data getHealthValues];
    NSArray* dayValues_Series = [data getHealthStrValues];
    NSArray* chValues = [challenge getChallengeValues];
    NSArray* winnerIds = [winnerinfo getStrValues];
    NSArray* totalValues_Series = [data getTotalHealthStrValues];
    
    int nCount = 0;
    for (int i=0; i<dayValues.count; i++) {
        int chVal = [chValues[i] intValue];
        if (chVal == 1) {
            UIView* view1 = viewDayArray[nCount];
            UIView* view2 = viewTotalArray[nCount];
            //view1.backgroundColor  = APP_COLOR_DETAIL3;
            //view2.backgroundColor  = APP_COLOR_DETAIL3;
            view1.layer.borderColor = APP_COLOR_PRIMARY.CGColor;
            view2.layer.borderColor = APP_COLOR_PRIMARY.CGColor;
            
            view1.hidden = false;
            view2.hidden = false;
            
            UILabel* mylabel = dayLabelArray[nCount];
            mylabel.text = dayValues_Series[i];
            NSMutableArray*leading = challenge.leading_val[i];
            if ([leading containsObject:data.custId]) {
                //[mylabel setTextColor:[CGlobal colorWithHexString:@"#63b55a" Alpha:1.0f]];
                [mylabel setFont:[UIFont boldSystemFontOfSize:_fontsize]];
                
                //view1.backgroundColor = APP_COLOR_DETAIL_BACKGREEN;
                view1.layer.borderColor = APP_COLOR_GREEN.CGColor;
            }
            if ([data.custId isEqualToString:winnerIds[i]]) {
                //[mylabel setTextColor:[CGlobal colorWithHexString:@"#d8da59" Alpha:1.0f]];
                [mylabel setFont:[UIFont boldSystemFontOfSize:_fontsize]];
                
                //view1.backgroundColor = APP_COLOR_DETAIL_BACKYELLOW;
                view1.layer.borderColor = APP_COLOR_YELLOW.CGColor;
            }
            
            UILabel* total = totalLabelArray[nCount];
            total.text = totalValues_Series[i];
            
            
            nCount++;
        }
        if (nCount == 5) {
            break;
        }
    }
    
}
- (IBAction)tapUserImage:(id)sender {
    if (self.aDelegate!=nil) {
        NSDictionary* dict =  @{@"action":@"tap_userimage"};
        
        [self.aDelegate didSubmit:dict View:self];
    }
}

@end
