//
//  MainDetailAimTableViewCell.m
//  Fit
//
//  Create by Denis on 2/24/16.
//
//

#import "MainDetailAimTableViewCell.h"
#import "CGlobal.h"
#import "ChallengeViewController.h"

@implementation MainDetailAimTableViewCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    NSMutableArray *myArray = [[NSMutableArray alloc] initWithObjects:_labelDay1,_labelDay2,_labelDay3,_labelDay4,_labelDay5,_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5,nil];
    
    
    CGRect rect = [[UIScreen mainScreen] bounds];
    if (rect.size.width<=320) {
        
        _fontsize = 11.0;
    }else{
        _fontsize = 12.0;
    }
    
    UIFont* font = [UIFont systemFontOfSize:_fontsize];
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
        [label setFont:font];
    }
    
    myArray = [[NSMutableArray alloc] initWithObjects:_labelDay,_labelTotal, nil];
    
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
        [label setFont:font];
    }
    [_labelName setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
    
    _constraint_trailing.constant = status_trailing;
    _constraint_leading.constant = status_leading;
    
    [_labelName setFont:defaultFont];
    
    _labelDay.textColor = APP_COLOR_PRIMARY_SECONDARY;
    _labelTotal.textColor = APP_COLOR_PRIMARY_SECONDARY;
    
}
-(NSString *)commonValue :(NSString *)value
{
    
    if (value)
    {
        if ([value isEqualToString:@"-"])
        {
            return @"-";
        }
        else
        {
            return [NSString stringWithFormat:@"%d",[value intValue]];
        }
    }
    
    return @"";
    
}
-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo{
    EnvVar*env = [CGlobal sharedId].env;
    
    self.data = data;
    self.invitee = invitee;
    self.challenge = challenge;
    self.winnerinfo = winnerinfo;
    
    NSString* thisId = @"";
    if (invitee == nil) {
        _labelName.text = [[NSBundle mainBundle] localizedStringForKey:@"Myself" value:@"" table:nil];
        thisId = [NSString stringWithFormat:@"%d",env.lastLogin];
        
    }else{
        
        if (invitee.fname == nil || [invitee.fname isEqualToString:@""]) {
            _labelName.text = invitee.email_address;
        }else{
            _labelName.text = invitee.fname;
        }
        
        thisId = invitee.custid;
    }
    UIImage* image = [CGlobal localUserImage:thisId];
    if (image!=nil) {
        _user_image.image = image;
    }
    [CGlobal getUserImage:thisId Callback:^(UIImage *ret) {
        if (ret!=nil) {
            dispatch_async(dispatch_get_main_queue(), ^{
                _user_image.image = ret;
            });
            
        }
        
    }];
    
    
    NSMutableArray* dayLabelArray = [[NSMutableArray alloc] initWithArray:@[_labelDay1,_labelDay2,_labelDay3,_labelDay4,_labelDay5]];
    
    NSMutableArray* totalLabelArray = [[NSMutableArray alloc] initWithArray:@[_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5]];
    for (UILabel* label in dayLabelArray) {
        label.text = @"";
    }
    for (UILabel* label in totalLabelArray) {
        label.text = @"";
    }
    
    NSArray* viewDayArray  = @[_viewDay1,_viewDay2,_viewDay3,_viewDay4,_viewDay5];
    NSArray* viewTotalArray  = @[_viewTotal1,_viewTotal2,_viewTotal3,_viewTotal4,_viewTotal5];
    for (UIView* view in viewDayArray) {
        view.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
        view.hidden = true;
    }
    for (UIView* view in viewTotalArray) {
        view.backgroundColor  = APP_COLOR_PRIMARY_SECONDARY;
        view.hidden = true;
    }
    
    _viewDay.backgroundColor = [UIColor clearColor];
    _viewTotal.backgroundColor = [UIColor clearColor];
    
    NSArray* dayValues_Series = [data getHealthStrValues];
    NSArray* totalValues_Series = [data getTotalHealthStrValues];
    //NSArray* aimValues_Series = @[challenge.aim_steps,challenge.aim_walking_running,challenge.aim_cycling_distance,challenge.aim_stand_hours,challenge.aim_flights_climbed,challenge.aim_active_energy,challenge.aim_swim];
    
    
    NSArray* totalValues = [data getTotalHealthValues];
    NSArray* aimValues = [challenge getAimValues];
    
    // APP_COLOR_DETAIL_BACKRED
    if ([challenge.aim_type intValue] == 0) {
        //daily
        int nCount = 0;
        for (int i=0; i<aimValues.count; i++) {
            float aimVal = [aimValues[i] floatValue];
            if (aimVal > 0) {
                // this item is activated
                UILabel* label = dayLabelArray[nCount];
                UILabel* total = totalLabelArray[nCount];
                label.text = dayValues_Series[i];
                total.text = totalValues_Series[i];
                
                UIView* view1 = viewDayArray[nCount];
                UIView* view2 = viewTotalArray[nCount];
                //view1.backgroundColor  = APP_COLOR_DETAIL3;
                //view2.backgroundColor  = APP_COLOR_DETAIL3;
                view1.layer.borderColor = APP_COLOR_DETAIL3.CGColor;
                view2.layer.borderColor = APP_COLOR_DETAIL3.CGColor;
                
                view1.hidden = false;
                view2.hidden = false;
                nCount++;
            }
            if (nCount == 5) {
                break;
            }
        }
    }else{
        NSArray* colorValues = [ChallengeViewController calculateColorForAim:totalValues Aim:aimValues];
        NSArray* colorBackValues = [ChallengeViewController calculateBackColorForAim:totalValues Aim:aimValues];
        
        NSArray* colorApp = @[APP_COLOR_RED,APP_COLOR_GREEN,APP_COLOR_BLUE,APP_COLOR_YELLOW,[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        
        int nCount = 0;
        for (int i=0; i<aimValues.count; i++) {
            float aimVal = [aimValues[i] floatValue];
            if (aimVal > 0) {
                // this item is activated
                UIView* view1 = viewDayArray[nCount];
                UIView* view2 = viewTotalArray[nCount];
                //view1.backgroundColor  = APP_COLOR_DETAIL3;
                //view2.backgroundColor = colorBackValues[i];
                //view1.layer.borderColor = APP_COLOR_DETAIL3.CGColor;
                //view2.layer.borderColor = ((UIColor*)colorBackValues[i]).CGColor
                
                view1.hidden = false;
                view2.hidden = false;
                
                UILabel* label = dayLabelArray[nCount];
                UILabel* total = totalLabelArray[nCount];
                label.text = dayValues_Series[i];
                total.text = totalValues_Series[i];
                
                int color = [colorValues[i] intValue];
                if (color>=0 && color< colorApp.count) {
                    //[total setTextColor:colorApp[color]];
                    view1.layer.borderColor = APP_COLOR_DETAIL3.CGColor;
                    view2.layer.borderColor = ((UIColor*)colorApp[color]).CGColor;
                    
                    
                }else{
                    //[total setTextColor:[CGlobal colorWithHexString:@"#ffffff" Alpha:1.0f]];
                    
                    
                    NSLog(@"err color ");
                }
                
                
                nCount++;
            }
            if (nCount == 5) {
                break;
            }
        }
    }
}

- (IBAction)tapUserImage:(id)sender {
    if (self.aDelegate!=nil) {
        NSDictionary* dict =  @{@"action":@"tap_userimage"};
        
        [self.aDelegate didSubmit:dict View:self];
    }
}




@end
