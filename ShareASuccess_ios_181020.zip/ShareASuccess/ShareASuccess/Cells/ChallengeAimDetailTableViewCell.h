//
//  ChallengeAimDetailTableViewCell.h
//  ShareASuccess
//
//  Created by BoHuang on 12/21/16.
//  Copyright © 2016 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblHealthData.h"
#import "TblInvitee.h"
#import "TblChallenge.h"
#import "TblWinnerInfo.h"

@interface ChallengeAimDetailTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelDay1;
@property (weak, nonatomic) IBOutlet UILabel *labelDay2;
@property (weak, nonatomic) IBOutlet UILabel *labelDay3;
@property (weak, nonatomic) IBOutlet UILabel *labelDay4;
@property (weak, nonatomic) IBOutlet UILabel *labelDay5;

@property (weak, nonatomic) IBOutlet UILabel *labelTotal1;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal2;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal3;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal4;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal5;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal;
@property (weak, nonatomic) IBOutlet UILabel *labelDay;

@property (assign, nonatomic) CGFloat fontsize;

-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;
@end
