//
//  ChallengeOverTableViewCell.m
//  ShareASuccess
//
//  Created by Twinklestar on 3/28/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import "ChallengeOverTableViewCell.h"
#import "Utils.h"
#import "CGlobal.h"
#import "ChallengeViewController.h"
#import "ShareASuccess-Swift.h"

@implementation ChallengeOverTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _labelMe.textColor = [UIColor whiteColor];
    [_labelMe setFont:defaultFont];
    
    _lblHeadline.textColor = [UIColor whiteColor];
    [_lblHeadline setFont:defaultFont];
    
    _labelGroup.textColor = [UIColor whiteColor];
    [_labelGroup setFont:defaultFont];
    
    [_labelChallengeName setFont:defaultFont];
//    [_labelChallengeName setTextColor:defaultColor_blue];
    [_labelChallengeName setTextColor:[UIColor whiteColor]];
    
//    _pinImage.image = [CGlobal getColoredImageFromImage:_pinImage.image Color:defaultColor_blue];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setBubbleData:(TblChallenge*)data{
    self.view_bubble.hidden = true;
    if ([data hasMessages]) {
        self.view_bubble.hidden = false;
        self.bubble_lbl.text = data.msg_count;
    }else{
//        self.view_bubble.hidden = false;
//        self.bubble_lbl.text = @"0";
    }
}
-(void)setDataForTblChallenge:(TblChallenge*)data{
    [self setBubbleData:data];
    NSArray *myImageArray = @[_imageMy1,_imageMy2,_imageMy3,_imageMy4,_imageMy5];
    NSArray *grImageArray = @[_imageGroup1,_imageGroup2,_imageGroup3,_imageGroup4,_imageGroup5];
    NSArray *syImageArray = @[_imageSymbol1,_imageSymbol2,_imageSymbol3,_imageSymbol4,_imageSymbol5];
    
    NSArray *myViewArray = @[_viewMe1,_viewMe2,_viewMe3,_viewMe4,_viewMe5];
    NSArray *grViewArray = @[_viewGroup1,_viewGroup2,_viewGroup3,_viewGroup4,_viewGroup5];
    NSArray *syViewArray = @[_viewSymbol1,_viewSymbol2,_viewSymbol3,_viewSymbol4,_viewSymbol5];
    
    for (int i=0; i<[myImageArray count]; i++) {
        UIImageView* myimage = [myImageArray objectAtIndex:i];
        UIImageView* grimage = [grImageArray objectAtIndex:i];
        UIImageView* syimage = [syImageArray objectAtIndex:i];
        myimage.image = nil;
        grimage.image = nil;
        syimage.image = nil;
        
        UIImageView* myview = [myViewArray objectAtIndex:i];
        UIImageView* grview = [grViewArray objectAtIndex:i];
        UIImageView* syview = [syViewArray objectAtIndex:i];
        myview.hidden = true;
        grview.hidden = true;
        syview.hidden = true;
        
    }
    
    _labelChallengeName.text = [NSString stringWithFormat:@"%@ (%ld)",data.challenge_name,data.total];
    
    int type = [data.type intValue];
    
    NSArray* aimValues = [data getAimValues];
    int nCount = 0;
    NSArray* imgNames = @[@"exe_steps",@"exe_walking",@"exe_cycling",@"exe_standing",@"exe_flights",@"exe_activeenergy",@"exe_swim"];
    
    if (type == 0) {
        self.img_ppl.image = [UIImage imageNamed:@"ico_ppl.png"];
        self.img_person.image = [UIImage imageNamed:@"ico_person.png"];
        self.cell_seperator1.backMode = 7;
        self.cell_seperator2.backMode = 7;
        self.cell_seperator3.backMode = 7;
        
        NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Challenge" value:@"" table:nil];
        _lblHeadline.text = temp;
        _lblHeadline.backgroundColor = APP_COLOR_DOT_GREEN;
        
        NSArray* challenge_values = [data getChallengeValues];
        for (int i=0; i<challenge_values.count; i++) {
            int val = [challenge_values[i] intValue];
            if (val == 1) {
                UIImageView* myimage = myImageArray[nCount];
                UIImageView* grimage = grImageArray[nCount];
                UIImageView* syimage = syImageArray[nCount];
                
                int myindex = [data.colors_my[i] intValue];
                int grindex = [data.colors_gr[i] intValue];
                NSString* imgname = imgNames[i];
                
                
                myimage.image = [UIImage imageNamed:g_listColor[myindex]];
                grimage.image = [UIImage imageNamed:g_listColor[grindex]];
                syimage.image = [UIImage imageNamed:imgname];
                switch (myindex) {
                    case 0:
                    {
                        myimage.image = [CGlobal getColoredImage:g_listColor[myindex] Color:APP_COLOR_DOT_RED];
                        break;
                    }
                    case 1:{
                        myimage.image = [CGlobal getColoredImage:g_listColor[myindex] Color:APP_COLOR_GREEN];
                        break;
                    }
                        
                    default:
                        break;
                }
                switch (grindex) {
                    case 0:
                    {
                        grimage.image = [CGlobal getColoredImage:g_listColor[grindex] Color:APP_COLOR_DOT_RED];
                        break;
                    }
                    case 1:{
                        grimage.image = [CGlobal getColoredImage:g_listColor[grindex] Color:APP_COLOR_GREEN];
                        break;
                    }
                        
                    default:
                        break;
                }
                
                UIImageView* myview = [myViewArray objectAtIndex:nCount];
                UIImageView* grview = [grViewArray objectAtIndex:nCount];
                UIImageView* syview = [syViewArray objectAtIndex:nCount];
                
                myview.hidden = false;
                grview.hidden = false;
                syview.hidden = false;
                
//                myview.backgroundColor = g_listColor_BK[myindex];
//                grview.backgroundColor = g_listColor_BK[grindex];
                
                myview.backgroundColor = [UIColor clearColor];
                grview.backgroundColor = [UIColor clearColor];
                
                
                nCount++;
            }
            if (nCount==5) {
                break;
            }
        }
    }else{
        
        self.img_ppl.image = [UIImage imageNamed:@"ico_ppl_2.png"];
        self.img_person.image = [UIImage imageNamed:@"ico_person_2.png"];
        
        self.cell_seperator1.backMode = 8;
        self.cell_seperator2.backMode = 8;
        self.cell_seperator3.backMode = 8;
        
        NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Aim" value:@"" table:nil];
        _lblHeadline.text = temp;
        _lblHeadline.backgroundColor = APP_COLOR_DOT_RED;
        NSArray* challenge_values = [data getAimValues];
        for (int i=0; i<challenge_values.count; i++) {
            float val = [challenge_values[i] floatValue];
            if (val > 0 ) {
                UIImageView* myimage = myImageArray[nCount];
                UIImageView* grimage = grImageArray[nCount];
                UIImageView* syimage = syImageArray[nCount];
                
                int myindex = [data.colors_my[i] intValue];
                int grindex = [data.colors_gr[i] intValue];
                NSString* imgname = [imgNames[i] stringByAppendingString:@"_2"];
                
                myimage.image = [UIImage imageNamed:g_listColor[myindex]];
                grimage.image = [UIImage imageNamed:g_listColor[grindex]];
                syimage.image = [UIImage imageNamed:imgname];
                
                switch (myindex) {
                    case 0:
                    {
                        myimage.image = [CGlobal getColoredImage:g_listColor[myindex] Color:APP_COLOR_DOT_RED];
                        break;
                    }
                    case 1:{
                        myimage.image = [CGlobal getColoredImage:g_listColor[myindex] Color:APP_COLOR_GREEN];
                        break;
                    }
                        
                    default:
                        break;
                }
                switch (grindex) {
                    case 0:
                    {
                        grimage.image = [CGlobal getColoredImage:g_listColor[grindex] Color:APP_COLOR_DOT_RED];
                        break;
                    }
                    case 1:{
                        grimage.image = [CGlobal getColoredImage:g_listColor[grindex] Color:APP_COLOR_GREEN];
                        break;
                    }
                        
                    default:
                        break;
                }
                
                UIImageView* myview = [myViewArray objectAtIndex:nCount];
                UIImageView* grview = [grViewArray objectAtIndex:nCount];
                UIImageView* syview = [syViewArray objectAtIndex:nCount];
                
                myview.hidden = false;
                grview.hidden = false;
                syview.hidden = false;
                
//                myview.backgroundColor = g_listColor_BK[myindex];
//                grview.backgroundColor = g_listColor_BK[grindex];
                
                myview.backgroundColor = [UIColor clearColor];
                grview.backgroundColor = [UIColor clearColor];

                
                nCount++;
            }
            if (nCount==5) {
                break;
            }
        }
    }
}
@end
