//
//  InviteTableViewCell.m
//  UiScreens
//
//  Created by BoHuang on 5/13/16.
//  Copyright © 2016 BoHuang. All rights reserved.
//

#import "InviteTableViewCell.h"
#import "CGlobal.h"

@implementation InviteTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    self.selectionStyle = UITableViewCellSelectionStyleNone;
    
    
    _font1 = [UIFont boldSystemFontOfSize:15];
    [_labelName setFont:_font1];
    [_labelTitle setFont:_font1];
    
    _font2 = [UIFont systemFontOfSize:15];
    [_labelDesc setFont:_font2];
    
    CGRect screenRect = [UIScreen mainScreen].bounds;
    _labelwidth1 = screenRect.size.width - 40;
    
    [CGlobal makeStyle1:_btn_accept Mode:0];
    [CGlobal makeStyle1:_btn_reject Mode:0];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

-(void)setData:(TblInviteInfoData*)inviteinfo{
    int total = 0;
    
    total = inviteinfo.total - 1;
    NSString* temp = [[NSBundle mainBundle] localizedStringForKey:@"Pending invites (%d)" value:@"" table:nil];
    NSString *title = [NSString stringWithFormat:temp,total];
    _labelTitle.text = title;
    _labelName.text = inviteinfo.challenge_name;
    _labelDesc.text = inviteinfo.challenge_description;
    
}
@end
