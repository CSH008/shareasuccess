//
//  InviteEmailTableViewCell.m
//  UiScreens
//
//  Created by BoHuang on 5/13/16.
//  Copyright © 2016 BoHuang. All rights reserved.
//

#import "InviteEmailTableViewCell.h"
#import "TblInvitee.h"
@implementation InviteEmailTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    [_txt_email setTextColor:[UIColor blackColor]];
    
//    _viewRoot.backgroundColor = [UIColor redColor];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
-(void)setData:(id)data{
    if ([data isKindOfClass:[NSDictionary class]]) {
        
        if ([data[@"status"] intValue] == 1) {
            //[_img_left setImage:[UIImage imageNamed:@"symbol_fine"]];
        } else {
            //[_img_left setImage:[UIImage imageNamed:@"symbol_pending"]];
        }
        _txt_email.text = data[@"email_address"];
    }else if([data isKindOfClass:[NSString class]]){
        _img_left.hidden = true;
        _txt_email.text = data;
    }else if([data isKindOfClass:[TblInvitee class]]){
        TblInvitee* invitee = (TblInvitee*)data;
        if ([invitee.status intValue] == 1) {
            //[_img_left setImage:[UIImage imageNamed:@"symbol_fine"]];
        } else {
            //[_img_left setImage:[UIImage imageNamed:@"symbol_pending"]];
        }
        _txt_email.text = invitee.email_address;
    }
}
@end
