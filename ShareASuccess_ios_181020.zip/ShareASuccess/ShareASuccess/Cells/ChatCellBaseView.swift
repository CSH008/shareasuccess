//
//  ChatCellBaseView.swift
//  ShareASuccess
//
//  Created by BoHuang on 7/30/18.
//  Copyright © 2018 ShareASuccess. All rights reserved.
//

import UIKit

class ChatCellBaseView: UIView {

    @IBOutlet weak var user_image: UIImageView!
    
    public var constant_MsgMaxWidth:CGFloat = 184
    public let constant_TopName:CGFloat = 22
    public let constant_MsgMargin:CGFloat = 20;
    
    //public let font:UIFont = UIFont.systemFont(ofSize: 14)
    
    
    @IBOutlet weak var imgCircleContainer: UIView!
    
    @IBOutlet weak var lbl_datetime: UILabel!
    @IBOutlet weak var lbl_name: UILabel!
    @IBOutlet weak var lbl_msg: UILabel!
    @IBOutlet weak var img_bubble: UIImageView!
    
    @IBOutlet weak var constraint_H: NSLayoutConstraint!    // total height of view
    
    @IBOutlet weak var bubble_container: UIView!
    @IBOutlet weak var constraint_width_msg: NSLayoutConstraint!    // width of msg label view
    
    @IBOutlet weak var delete_view: UIView!
    
    @objc func toggleDeleteView(isEditable:Bool){
        if isEditable {
            delete_view.isHidden = false;
        }else{
            delete_view.isHidden = true;
        }
    }
    
    
    
    var cell_data:TblChat?
    var a_delegate:ViewDialogDelegate?
    
    func tapDelete(_ sender: Any) {
        if let delegate = a_delegate {
            let data = NSMutableDictionary.init()
            data["data"] = cell_data
            data["action"] = "tap_delete"
            delegate.didSubmit!(data as! [AnyHashable : Any], view: self)
        }
    }
    
    func tapEntire(_ sender: Any) {
        if let delegate = a_delegate {
            let data = NSMutableDictionary.init()
            data["data"] = cell_data
            data["action"] = "tap_entire"
            delegate.didSubmit!(data as! [AnyHashable : Any], view: self)
        }
    }
    
    
    
    @objc func setData(row:TblChat, delegate:ViewDialogDelegate,type:Int){
        
//        [CGlobal getUserImage:thisId Callback:^(UIImage *ret) {
//            if (ret!=nil) {
//            dispatch_async(dispatch_get_main_queue(), ^{
//            _user_image.image = ret;
//            });
//
//            }
//
//            }];
        
        if let image = CGlobal.localUserImage(row.user_id) {
            self.user_image.image = image
        }
        
        CGlobal.getUserImage(row.user_id) { (image) in
            if let image = image {
                DispatchQueue.main.async {
                    self.user_image.image = image;
                }
            }
        }
        
        self.backgroundColor = CGlobal.color(withHexString: "3b5d7d", alpha: 1.0)
        if type == 0 {
            //self.backgroundColor = APP_COLOR_PRIMARY;
            self.imgCircleContainer.backgroundColor = APP_COLOR_BUTTON_PRIMARY;
        }else{
            //self.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
            self.imgCircleContainer.backgroundColor = APP_COLOR_PRIMARY_SECONDARY;
        }
        
        self.cell_data = row
        self.a_delegate = delegate;
        
        lbl_name.text = row.user_name
        lbl_msg.text = row.msg
        lbl_datetime.text = row.time_val
        //lbl_msg.font = lbl_msg.font
        lbl_msg.textColor = UIColor.white
        
        self.constant_MsgMaxWidth = UIScreen.main.bounds.size.width - 8*2 - 8 - 40;
        
        let size = CGlobal.size(forView: row.msg, font: lbl_msg.font , width: self.constant_MsgMaxWidth)
        if(size.height == 21){
            self.constraint_H.constant = max(49.0,size.height + self.constant_TopName + self.constant_MsgMargin)
            //self.constraint_width_msg.constant = size.width
        }else{
            self.constraint_H.constant = max(49.0,size.height + self.constant_TopName + self.constant_MsgMargin)
            //self.constraint_width_msg.constant = size.width
        }
        debugPrint(self.constraint_H.constant,row.msg)
        
        if let time_val = row.time_val {
            let date = Date.init(timeIntervalSince1970: (time_val as NSString).doubleValue);
            let format = DateFormatter.init()
            format.dateFormat = "MM/dd HH:mm"
            lbl_datetime.text = format.string(from: date)
        }
        
//        bubble_container.setNeedsUpdateConstraints()
        lbl_msg.setNeedsUpdateConstraints()
//        img_bubble.setNeedsUpdateConstraints()
//        bubble_container.layoutIfNeeded()
        
    }
    
    func changeImage(_ name: String) {
        guard let image = UIImage(named: name) else { return }
        img_bubble.image = image
            .resizableImage(withCapInsets:
                UIEdgeInsetsMake(17, 21, 17, 21),
                            resizingMode: .stretch)
            .withRenderingMode(.alwaysTemplate)
    }

}
