//
//  MainDetailAimTableViewCell.h
//  ShareASuccess
//
//  Created by BoHuang on 1/31/17.
//  Copyright © 2017 ShareASuccess. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "TblHealthData.h"
#import "TblInvitee.h"
#import "TblChallenge.h"
#import "TblWinnerInfo.h"
#import "MyPopupDialog.h"

@interface MainDetailAimTableViewCell : UITableViewCell

@property (strong, nonatomic) id<ViewDialogDelegate> aDelegate;

@property (weak, nonatomic) IBOutlet UILabel *labelName;
@property (weak, nonatomic) IBOutlet UILabel *labelDay1;
@property (weak, nonatomic) IBOutlet UILabel *labelDay2;
@property (weak, nonatomic) IBOutlet UILabel *labelDay3;
@property (weak, nonatomic) IBOutlet UILabel *labelDay4;
@property (weak, nonatomic) IBOutlet UILabel *labelDay5;

@property (weak, nonatomic) IBOutlet UIView *viewDay1;
@property (weak, nonatomic) IBOutlet UIView *viewDay2;
@property (weak, nonatomic) IBOutlet UIView *viewDay3;
@property (weak, nonatomic) IBOutlet UIView *viewDay4;
@property (weak, nonatomic) IBOutlet UIView *viewDay5;
@property (weak, nonatomic) IBOutlet UIView *viewDay;

@property (weak, nonatomic) IBOutlet UIView *viewTotal;
@property (weak, nonatomic) IBOutlet UIView *viewTotal1;
@property (weak, nonatomic) IBOutlet UIView *viewTotal2;
@property (weak, nonatomic) IBOutlet UIView *viewTotal3;
@property (weak, nonatomic) IBOutlet UIView *viewTotal4;
@property (weak, nonatomic) IBOutlet UIView *viewTotal5;


@property (weak, nonatomic) IBOutlet UILabel *labelTotal1;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal2;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal3;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal4;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal5;
@property (weak, nonatomic) IBOutlet UILabel *labelTotal;
@property (weak, nonatomic) IBOutlet UILabel *labelDay;

@property (assign, nonatomic) CGFloat fontsize;

-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo;

@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_leading;
@property (nonatomic,weak) IBOutlet NSLayoutConstraint*constraint_trailing;

@property (nonatomic,weak) IBOutlet UIView* view_toolbar_subview;
@property (weak, nonatomic) IBOutlet UIImageView *user_image;

@property (strong, nonatomic) TblHealthData*    data;
@property (strong, nonatomic) TblInvitee*       invitee;
@property (strong, nonatomic) TblChallenge*     challenge;
@property (strong, nonatomic) TblWinnerInfo*    winnerinfo;

@property (weak, nonatomic) IBOutlet UIView *viewLineTop1;

@end
