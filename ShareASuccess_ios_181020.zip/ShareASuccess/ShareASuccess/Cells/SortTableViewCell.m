//
//  SortTableViewCell.m
//  Fit
//
//  Created by BoHuang on 5/18/16.
//
//

#import "SortTableViewCell.h"
#import "CGlobal.h"
@interface SortTableViewCell()
@property (nonatomic,strong) UIFont* font;
@property (nonatomic,assign) CGFloat labelwidth;
@end

@implementation SortTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
//    _font = [UIFont fontWithName:@"Helvetica" size:14.0];
//    _font [UIFont systemFontOfSize:14];
    [_lbl_content setFont:defaultFont];
    
    CGRect screenRect = [UIScreen mainScreen].bounds;
    
    
//    _labelwidth = screenRect.size.width - 32 - 8 - status_leading*2;
    _labelwidth = screenRect.size.width - 32 - 8 - 8*2;
    
    
//    _img_right.image = [UIImage imageNamed:@"reorder.png"];
    _img_right.alpha = 0.3;
    _img_right.hidden = true;
    
//    _constraint_leading.constant = -28 + status_leading;
//    _constraint_trailing.constant = status_leading;
    
//    _constraint_leading.constant = -12;
//    _constraint_trailing.constant = 0;
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    
    // Configure the view for the selected state
}
-(void)setData:(NSString*)data{
    _lbl_content.text = data;
    
}
@end
