//
//  CellGeneral.m
//  EFT
//
//  Created by Twinklestar on 12/11/15.
//  Copyright © 2015 Twinklestar. All rights reserved.
//

#import "CellGeneral.h"
#import "CGlobal.h"
@implementation CellGeneral

- (void)awakeFromNib {
    // Initialization code
    _lbl_email.textColor = [CGlobal colorWithHexString:@"#878787" Alpha:1.0f];
    _lbl_content.textColor = [CGlobal colorWithHexString:@"#878787" Alpha:1.0f];
    
    _view_leftbar.hidden = true;
    _view_rightbar.hidden = true;
    _view_bottombar.hidden = true;
    
    UIFont* cellcontent_font1 = [UIFont systemFontOfSize:15];
    
    [_lbl_content setFont:cellcontent_font1];
    [_lbl_email setFont:cellcontent_font1];
}
-(void)setData:(NSMutableDictionary*)dict IndexPath:(NSIndexPath*)indexPath Size:(long)size{
    _lbl_content.text = dict[@"name"];
    _lbl_email.text = dict[@"email"];
    
    int row = (int)indexPath.row;
    if (row == size - 1) {
        _view_bottombar.hidden = true;
    }else{
        _view_bottombar.hidden = false;
    }
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}
@end
