//
//  ChallengeAimDetailTableViewCell.m
//  Fit
//
//  Create by Denis on 2/24/16.
//
//

#import "ChallengeAimDetailTableViewCell.h"
#import "CGlobal.h"
#import "ChallengeViewController.h"

@implementation ChallengeAimDetailTableViewCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    NSMutableArray *myArray = [[NSMutableArray alloc] initWithObjects:_labelDay1,_labelDay2,_labelDay3,_labelDay4,_labelDay5,_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5,nil];
    
    
    CGRect rect = [[UIScreen mainScreen] bounds];
    if (rect.size.width<=320) {
        
        _fontsize = 11.0;
    }else{
        _fontsize = 12.0;
    }
    UIFont* font = [UIFont systemFontOfSize:_fontsize];
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        [label setFont:font];
    }
    
    myArray = [[NSMutableArray alloc] initWithObjects:_labelDay,_labelTotal, nil];
    
    for (int i=0; i<[myArray count]; i++) {
        UILabel* label = [myArray objectAtIndex:i];
        [label setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        [label setFont:font];
    }
    
    _constraint_trailing.constant = status_trailing;
    _constraint_leading.constant = status_leading;
    
    [_labelName setFont:defaultFont];
    
}
-(NSString *)commonValue :(NSString *)value
{
    
    if (value)
    {
        if ([value isEqualToString:@"-"])
        {
            return @"-";
        }
        else
        {
            return [NSString stringWithFormat:@"%d",[value intValue]];
        }
    }
    
    return @"";
    
}
-(void)setData:(TblHealthData*)data Invitee:(TblInvitee*)invitee Challenge:(TblChallenge*)challenge
    WinnerInfo:(TblWinnerInfo*)winnerinfo{
    //    EnvVar*env = [CGlobal sharedId].env;
    if (invitee == nil) {
        _labelName.text = [[NSBundle mainBundle] localizedStringForKey:@"Myself" value:@"" table:nil];
    }else{
        
        if (invitee.fname == nil || [invitee.fname isEqualToString:@""]) {
            _labelName.text = invitee.email_address;
        }else{
            _labelName.text = invitee.fname;
        }
    }
    
    NSMutableArray* dayLabelArray = [[NSMutableArray alloc] initWithArray:@[_labelDay1,_labelDay2,_labelDay3,_labelDay4,_labelDay5]];
    NSMutableArray* totalLabelArray = [[NSMutableArray alloc] initWithArray:@[_labelTotal1,_labelTotal2,_labelTotal3,_labelTotal4,_labelTotal5]];
    for (UILabel* label in dayLabelArray) {
        label.text = @"";
    }
    for (UILabel* label in totalLabelArray) {
        label.text = @"";
    }
    
    NSArray* dayValues_Series = [data getHealthStrValues];
    NSArray* totalValues_Series = [data getTotalHealthStrValues];
    //NSArray* aimValues_Series = @[challenge.aim_steps,challenge.aim_walking_running,challenge.aim_cycling_distance,challenge.aim_stand_hours,challenge.aim_flights_climbed,challenge.aim_active_energy,challenge.aim_swim];
    
    
    NSArray* totalValues = [data getTotalHealthValues];
    NSArray* aimValues = [challenge getAimValues];

    if ([challenge.aim_type intValue] == 0) {
        //daily
        int nCount = 0;
        for (int i=0; i<aimValues.count; i++) {
            float aimVal = [aimValues[i] floatValue];
            if (aimVal > 0) {
                // this item is activated
                UILabel* label = dayLabelArray[nCount];
                UILabel* total = totalLabelArray[nCount];
                label.text = dayValues_Series[i];
                total.text = totalValues_Series[i];
                
                nCount++;
            }
            if (nCount == 5) {
                break;
            }
        }
    }else{
        NSArray* colorValues = [ChallengeViewController calculateColorForAim:totalValues Aim:aimValues];
        NSArray* colorApp = @[APP_COLOR_RED,APP_COLOR_GREEN,APP_COLOR_BLUE,APP_COLOR_YELLOW,[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
        
        int nCount = 0;
        for (int i=0; i<aimValues.count; i++) {
            float aimVal = [aimValues[i] floatValue];
            if (aimVal > 0) {
                // this item is activated
                UILabel* label = dayLabelArray[nCount];
                UILabel* total = totalLabelArray[nCount];
                label.text = dayValues_Series[i];
                total.text = totalValues_Series[i];
                
                int color = [colorValues[i] intValue];
                if (color>=0 && color< colorApp.count) {
                    [total setTextColor:colorApp[color]];
                }else{
                    [total setTextColor:[CGlobal colorWithHexString:@"#777776" Alpha:1.0f]];
                    NSLog(@"err color ");
                }
                nCount++;
            }
            if (nCount == 5) {
                break;
            }
        }
    }
}
@end
