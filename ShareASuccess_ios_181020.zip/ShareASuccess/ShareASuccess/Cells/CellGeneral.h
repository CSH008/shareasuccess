//
//  CellGeneral.h
//  EFT
//
//  Created by Twinklestar on 12/11/15.
//  Copyright © 2015 Twinklestar. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CellGeneral : UITableViewCell

@property (weak,nonatomic) IBOutlet UILabel *lbl_content;
@property (weak,nonatomic) IBOutlet UILabel *lbl_email;
@property (weak,nonatomic) IBOutlet UIView *view_leftbar;
@property (weak,nonatomic) IBOutlet UIView *view_rightbar;
@property (weak,nonatomic) IBOutlet UIView *view_bottombar;

-(void)setData:(NSMutableDictionary*)dict IndexPath:(NSIndexPath*)indexPath Size:(long)size;
@end
